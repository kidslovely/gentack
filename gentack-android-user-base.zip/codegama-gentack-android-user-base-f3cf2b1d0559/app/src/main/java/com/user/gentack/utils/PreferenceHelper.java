package com.user.gentack.utils;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.os.SystemClock;

import java.util.TimeZone;


public class PreferenceHelper {

    public static final String PROPERTY_REG_ID = "registration_id";
    public static final String PROPERTY_APP_VERSION = "appVersion";
    private static final String PRE_LOAD = "preLoad";
    private static PreferenceHelper preferenceHelper;
    private final String USER_ID = "user_id";
    private final String PATIENT_ID = "patient_id";
    private final String EMAIL = "email";
    private final String PASSWORD = "password";
    private final String PICTURE = "picture";
    private final String DEVICE_TOKEN = "device_token";
    private final String SESSION_TOKEN = "session_token";
    private final String LOGIN_BY = "login_by";
    private final String SOCIAL_ID = "social_id";
    private final String REQUEST_ID = "request_id";
    private final String NAME = "name";
    private final String REQ_TIME = "req_time";
    private final String ACCEPT_TIME = "accept_time";
    private final String CURRENT_TIME = "current_time";
    private final String CURRENCY = "currency";
    private final String FIRST_TIME_LOGIN = "first_time_login";
    private SharedPreferences shared_prefs;
    private Context context;


    private PreferenceHelper(Context context) {
        shared_prefs = context.getSharedPreferences(Const.PREF_NAME,
                Context.MODE_PRIVATE);
        this.context = context;
    }

    public static void initPreferenceHelper(Context context) {
        if (preferenceHelper == null) {
            preferenceHelper = new PreferenceHelper(context);
        }
    }

    public static PreferenceHelper getInstance() {
        return preferenceHelper;
    }


    public void putUserId(String userId) {
        Editor edit = shared_prefs.edit();
        edit.putString(USER_ID, userId);
        edit.commit();
    }

    public void putLoginBy(String loginBy) {
        Editor edit = shared_prefs.edit();
        edit.putString(LOGIN_BY, loginBy);
        edit.commit();
    }

    public String getLoginBy() {
        return shared_prefs.getString(LOGIN_BY, null);
    }

    public String getUserId() {
        return shared_prefs.getString(USER_ID, null);
    }

    public void putSessionToken(String sessionToken) {
        Editor edit = shared_prefs.edit();
        edit.putString(SESSION_TOKEN, sessionToken);
        edit.commit();
    }

    public String getSessionToken() {
        return shared_prefs.getString(SESSION_TOKEN, null);

    }


    public void putFirstTimeLogin(boolean firstTime) {
        Editor edit = shared_prefs.edit();
        edit.putBoolean(FIRST_TIME_LOGIN, firstTime);
        edit.commit();
    }

    public boolean getFirstTimeLogin() {
        return shared_prefs.getBoolean(FIRST_TIME_LOGIN, false);
    }

    public String getUser_name() {
        return shared_prefs.getString(NAME, "");
    }


    public void putEmail(String email) {
        Editor edit = shared_prefs.edit();
        edit.putString(EMAIL, email);
        edit.commit();
    }

    public String getEmail() {
        return shared_prefs.getString(EMAIL, null);
    }

    public void putPicture(String picture) {
        Editor edit = shared_prefs.edit();
        edit.putString(PICTURE, picture);
        edit.commit();
    }

    public void putRequestId(int reqId) {
        Editor edit = shared_prefs.edit();
        edit.putInt(REQUEST_ID, reqId);
        edit.commit();
    }

    public int getRequestId() {
        return shared_prefs.getInt(REQUEST_ID, Const.NO_REQUEST);
    }


    public String getPicture() {
        return shared_prefs.getString(PICTURE, null);
    }

    public void putPassword(String password) {
        Editor edit = shared_prefs.edit();
        edit.putString(PASSWORD, password);
        edit.commit();
    }

    public String getPassword() {
        return shared_prefs.getString(PASSWORD, null);
    }

    public void putSocialId(String id) {
        Editor edit = shared_prefs.edit();
        edit.putString(SOCIAL_ID, id);
        edit.commit();
    }

    public String getSocialId() {
        return shared_prefs.getString(SOCIAL_ID, null);
    }


    public void putUser_name(String name) {
        Editor edit = shared_prefs.edit();
        edit.putString(NAME, name);
        edit.commit();
    }

    public void putDeviceToken(String deviceToken) {
        Editor edit = shared_prefs.edit();
        edit.putString(DEVICE_TOKEN, deviceToken);
        edit.commit();
    }

    public String getDeviceToken() {
        return shared_prefs.getString(DEVICE_TOKEN, null);

    }


    public void putReq_time(long req_time) {
        Editor edit = shared_prefs.edit();
        edit.putLong(REQ_TIME, req_time);
        edit.commit();
    }

    public long getReq_time() {
        return shared_prefs.getLong(REQ_TIME, SystemClock.uptimeMillis());

    }


    public void putPatient_id(String patient_id) {
        Editor edit = shared_prefs.edit();
        edit.putString(PATIENT_ID, patient_id);
        edit.commit();
    }

    public String getPatient_id() {
        return shared_prefs.getString(PATIENT_ID, "");

    }


    public void putAccept_time(long accept_time) {
        Editor edit = shared_prefs.edit();
        edit.putLong(ACCEPT_TIME, accept_time);
        edit.commit();
    }

    public long getAccept_time() {
        return shared_prefs.getLong(ACCEPT_TIME, 0L);

    }


    public void putRegisterationID(String RegID) {
        Editor edit = shared_prefs.edit();
        edit.putString(PROPERTY_REG_ID, RegID);
        edit.apply();
    }

    public String getRegistrationID() {
        return shared_prefs.getString(PROPERTY_REG_ID, "");
    }


    public void putAppVersion(int version) {
        Editor edit = shared_prefs.edit();
        edit.putInt(PROPERTY_APP_VERSION, version);
        edit.apply();
    }

    public int getAppVersion() {
        return shared_prefs.getInt(PROPERTY_APP_VERSION, Integer.MIN_VALUE);
    }


    public void clearRequestData() {
        putRequestId(Const.NO_REQUEST);
        putReq_time(SystemClock.uptimeMillis());
        putAccept_time(0L);
        putPatient_id("");

    }

    public void Logout() {
        putUserId(null);
        putSessionToken(null);
        putRequestId(Const.NO_REQUEST);
    }

    public String getTimeZone(){
        TimeZone timeZone = TimeZone.getDefault();
        return timeZone.getID();
    }

}


