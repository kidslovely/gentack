package com.user.gentack.activity;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;

import com.user.gentack.R;
import com.user.gentack.gcm.GCMRegisterHandler;
import com.user.gentack.gcm.GcmBroadcastReceiver;
import com.user.gentack.utils.Const;
import com.user.gentack.utils.PreferenceHelper;

public class SplashActivity extends Activity implements View.OnClickListener {

    private Button loginButton, signupButton;

    private static final String[] PERMISSIONS = {
            Manifest.permission.ACCESS_COARSE_LOCATION,
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.READ_PHONE_STATE,
            Manifest.permission.WRITE_EXTERNAL_STORAGE,
            Manifest.permission.CALL_PHONE
    };

    public static final int REQUEST_PERMISSION = 100;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (!hasPermissionsGranted(PERMISSIONS)){
            checkPermission();
        }
        if (PreferenceHelper.getInstance().getFirstTimeLogin()) {
            Intent intent = new Intent(SplashActivity.this, MainActivity.class);
            startActivity(intent);
            finish();
        } else {
            setContentView(R.layout.activity_splash);
            loginButton = (Button) findViewById(R.id.bn_splash_login);
            signupButton = (Button) findViewById(R.id.bn_splash_signup);
            loginButton.setOnClickListener(this);
            signupButton.setOnClickListener(this);

            if (TextUtils.isEmpty(PreferenceHelper.getInstance().getDeviceToken())) {
                registerGcmReceiver(new GcmBroadcastReceiver());
                Log.d("SplashActivity", "FirstTime");

            }

        }

    }

    public void registerGcmReceiver(BroadcastReceiver mHandleMessageReceiver) {
        if (mHandleMessageReceiver != null) {
            new GCMRegisterHandler(this, mHandleMessageReceiver);
        }
    }

    public void unregisterGcmReceiver(BroadcastReceiver mHandleMessageReceiver) {


        try {
            if (mHandleMessageReceiver != null) {
                unregisterReceiver(mHandleMessageReceiver);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    @Override
    public void onClick(View view) {
        Intent intent = new Intent(this, LoginRegisterActivity.class);
        switch (view.getId()) {
            case R.id.bn_splash_login:
                intent.putExtra(Const.Params.SINGIN_SIGNUP, Const.Params.LOGIN_FRAGMENT);
                startActivity(intent);
                break;
            case R.id.bn_splash_signup:
                intent.putExtra(Const.Params.SINGIN_SIGNUP, Const.Params.SIGNUP_FRAGMENT);
                startActivity(intent);
                break;

        }
    }

    private boolean shouldShowRequestPermissionRationale(String[] permissions) {
        for (String permission : permissions) {
            if (ActivityCompat.shouldShowRequestPermissionRationale(this, permission)) {
                return true;
            }
        }
        return false;
    }

    private boolean hasPermissionsGranted(String[] permissions){
        for (String permission : permissions) {
            if (ActivityCompat.checkSelfPermission(this, permission)
                    != PackageManager.PERMISSION_GRANTED) {
                return false;
            }
        }
        return true;
    }

    private void checkPermission(){
        if (shouldShowRequestPermissionRationale(PERMISSIONS)){
            new android.support.v7.app.AlertDialog.Builder(this)
                    .setMessage(R.string.permission_request)
                    .setPositiveButton(android.R.string.ok, new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            ActivityCompat.requestPermissions(SplashActivity.this, PERMISSIONS,
                                    REQUEST_PERMISSION);
                        }
                    })
                    .setNegativeButton(android.R.string.cancel,
                            new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    finish();
                                }
                            })
                    .create().show();
        }
        else{
            ActivityCompat.requestPermissions(this, PERMISSIONS, REQUEST_PERMISSION);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        if (requestCode == REQUEST_PERMISSION){
            if (grantResults.length > 0){
                if (grantResults[0] != PackageManager.PERMISSION_GRANTED){
                    new android.support.v7.app.AlertDialog.Builder(this)
                            .setMessage(getString(R.string.permission_error))
                            .setPositiveButton(android.R.string.ok, new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                   checkPermission();
                                }
                            })
                            .create().show();
                }
            }
            else{
                new android.support.v7.app.AlertDialog.Builder(this)
                        .setMessage(getString(R.string.permission_error))
                        .setPositiveButton(android.R.string.ok, new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                checkPermission();
                            }
                        })
                        .create().show();
            }
        }
        else{
            super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        }
    }

}

