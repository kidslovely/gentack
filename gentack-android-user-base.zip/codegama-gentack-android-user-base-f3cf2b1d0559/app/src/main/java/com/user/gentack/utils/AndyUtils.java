package com.user.gentack.utils;

import android.app.Activity;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.Signature;
import android.location.Address;
import android.location.Geocoder;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.util.Base64;
import android.util.Log;
import android.view.inputmethod.InputMethodManager;
import android.widget.Toast;

import com.google.android.gms.maps.model.LatLng;

import java.io.IOException;
import java.net.URLEncoder;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


/**
 * Created by getit on 8/5/2016.
 */
public class AndyUtils {
    public static Dialog mDialog;
    public static ProgressDialog mProgressDialog;

    public static void appLog(String msg1, String msg2) {
        Log.d(msg1, msg2);
    }

    public static void showLongToast(String msg, Context context) {
        Toast.makeText(context, msg, Toast.LENGTH_LONG).show();
    }

    public static void showShortToast(String msg, Context context) {
        Toast.makeText(context, msg, Toast.LENGTH_SHORT).show();
    }

    public static boolean isNetworkAvailable(Context context) {
        ConnectivityManager connectivity = (ConnectivityManager) context
                .getSystemService(Context.CONNECTIVITY_SERVICE);
        if (connectivity == null) {
            return false;
        } else {
            NetworkInfo[] info = connectivity.getAllNetworkInfo();
            if (info != null) {
                for (int i = 0; i < info.length; i++) {
                    if (info[i].getState() == NetworkInfo.State.CONNECTED) {
                        return true;
                    }
                }
            }
        }
        return false;
    }

    public static boolean eMailValidation(String emailstring) {
        if (null == emailstring || emailstring.length() == 0) {
            return false;
        }
        Pattern emailPattern = Pattern
                .compile("^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@"
                        + "[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$");
        Matcher emailMatcher = emailPattern.matcher(emailstring);
        return emailMatcher.matches();
    }

    public static void generateKeyHAsh(Context con) {

        try {
            PackageInfo info = con.getPackageManager().getPackageInfo(
                    con.getPackageName(),
                    PackageManager.GET_SIGNATURES);
            for (Signature signature : info.signatures) {
                MessageDigest md = MessageDigest.getInstance("SHA");
                md.update(signature.toByteArray());
                Log.d("KeyHash:", Base64.encodeToString(md.digest(), Base64.DEFAULT));
            }
        } catch (PackageManager.NameNotFoundException e) {

            e.printStackTrace();

        } catch (NoSuchAlgorithmException e) {

            e.printStackTrace();
        }
    }


    public static LatLng getLatLngFromAddress(String strAddress, Context context) {
        Geocoder coder = new Geocoder(context);
        List<Address> address;
        LatLng p1 = null;

        try {
            // May throw an IOException
            address = coder.getFromLocationName(strAddress, 3);

            if (address == null) {
                Log.d("LOCATION", strAddress  + "NULL");
                return null;
            }
            Log.d("LOCATION", strAddress  + address.toString());
            if (address.size() > 0) {
                Address location = address.get(0);
                location.getLatitude();
                location.getLongitude();

                p1 = new LatLng(location.getLatitude(), location.getLongitude());
            }

        } catch (IOException ex) {

            ex.printStackTrace();
        }
        return p1;
    }


    public static String getPlaceAutoCompleteUrl(String input) {

        StringBuilder sb = null;
        try {
            sb = new StringBuilder(Const.PLACES_API_BASE
                    + Const.TYPE_AUTOCOMPLETE + Const.OUT_JSON);
            sb.append("?sensor=false&key=" + Const.PLACES_AUTOCOMPLETE_API_KEY);

            sb.append("&radius=500");
            sb.append("&input=" + URLEncoder.encode(input, "utf8"));
        } catch (Exception e) {
            e.printStackTrace();
        }
        Log.d("FINAL URL:::   ", sb.toString());
        return sb.toString();
    }


    public static void showSimpleProgressDialog(Context context, String msg, boolean isCancelable) {
        mProgressDialog = new ProgressDialog(context);
        mProgressDialog.setCancelable(false);
        mProgressDialog.setMessage(msg);
        mProgressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
        if (!mProgressDialog.isShowing()) {
            mProgressDialog.show();
        }
    }


    public static void removeProgressDialog() {
        mProgressDialog.dismiss();
    }


    public static void hideKeyBoard(Context con) {

        InputMethodManager imm = (InputMethodManager) con.getSystemService(Activity.INPUT_METHOD_SERVICE);
        // if (!imm.isAcceptingText())
        imm.toggleSoftInput(InputMethodManager.HIDE_IMPLICIT_ONLY, 0);
    }

    public static String getCompleteAddressString(double LATITUDE, double LONGITUDE, Context activity) {
        String strAdd = "";
        Geocoder geocoder = new Geocoder(activity, Locale.getDefault());
        try {
            List<Address> addresses = geocoder.getFromLocation(LATITUDE, LONGITUDE, 5);
            if (addresses != null) {
                Address returnedAddress = addresses.get(0);
                StringBuilder strReturnedAddress = new StringBuilder("");
                if (returnedAddress.getMaxAddressLineIndex() > 0) {
                    for (int i = 0; i < returnedAddress.getMaxAddressLineIndex(); i++) {
                        strReturnedAddress.append(returnedAddress.getAddressLine(i)).append(",");
                    }
                }
                else {
                    try {
                        strReturnedAddress.append(returnedAddress.getAddressLine(0));
                    }
                    catch (Exception e){
                        e.printStackTrace();
                    }
                }
                strAdd = strReturnedAddress.toString();
                Log.w("CurrentLocationAddress", "" + strReturnedAddress.toString());
            } else {
                strAdd = "No Address returned!,";
                Log.w("CurrentLocationAddress", "No Address returned!");
            }
        } catch (Exception e) {
            e.printStackTrace();
            strAdd = "Cannot get Address!,";
            Log.w("CurrentLocationAddress", "Cannot get Address!");
        }
        return strAdd;
    }

//    public static LatLng getLatLngFromAddress(String strAddress,Context context)
//    {
//        Geocoder coder = new Geocoder(context);
//        List<Address> address;
//        LatLng p1 = null;
//
//        try {
//            // May throw an IOException
//            address = coder.getFromLocationName(strAddress, 5);
//            if (address == null) {
//                return null;
//            }
//            Address location = address.get(0);
//            location.getLatitude();
//            location.getLongitude();
//
//            p1 = new LatLng(location.getLatitude(), location.getLongitude() );
//
//        } catch (IOException ex) {
//
//            ex.printStackTrace();
//        }
//
//        return p1;
//    }


//    public static String getPlaceAutoCompleteUrl(String input) {
//
//        StringBuilder sb = null;
//        try {
//            sb = new StringBuilder(Const.PLACES_API_BASE
//                    + Const.TYPE_AUTOCOMPLETE + Const.OUT_JSON);
//            sb.append("?sensor=false&key=" + Const.PLACES_AUTOCOMPLETE_API_KEY);
//
//            sb.append("&radius=500");
//            sb.append("&input=" + URLEncoder.encode(input, "utf8"));
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//        Log.d("FINAL URL:::   ", sb.toString());
//        return sb.toString();
//    }


}
