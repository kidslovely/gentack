package com.user.gentack.activity;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.user.gentack.R;
import com.user.gentack.adapter.ProviderUserRatingAdapter;
import com.user.gentack.custom_interface.AsyncTaskCompleteListener;
import com.user.gentack.model.ProviderRating;
import com.user.gentack.networking.HttpRequester;
import com.user.gentack.utils.AndyUtils;
import com.user.gentack.utils.Const;
import com.user.gentack.utils.PreferenceHelper;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import de.hdodenhof.circleimageview.CircleImageView;

public class DetailProfileActivity extends AppCompatActivity implements AsyncTaskCompleteListener {
    private String provider_id;
    private ImageView btn_back_profile;
    private CircleImageView iv_profile;
    private Toolbar chatToolbar;
    private RecyclerView ratingView;
    ProviderUserRatingAdapter adapter;
    List<ProviderRating> providerRatingList = new ArrayList<>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail_profile);
        chatToolbar = (Toolbar) findViewById(R.id.toolbar_chat);
        setSupportActionBar(chatToolbar);
        getSupportActionBar().setTitle(null);
        btn_back_profile = (ImageView) findViewById(R.id.btn_back_chat);
        iv_profile = (CircleImageView) findViewById(R.id.iv_profile);
        ratingView = (RecyclerView) findViewById(R.id.ratingView);
        provider_id = getIntent().getStringExtra(Const.Params.PROVIDER_ID);
        getProviderInfo();
        adapter = new ProviderUserRatingAdapter(this, providerRatingList);
        ratingView.setHasFixedSize(true);
        ratingView.setLayoutManager(new LinearLayoutManager(this));
        ratingView.setAdapter(adapter);
        btn_back_profile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });
    }

    private void getProviderInfo(){
        if (provider_id != null){
            HashMap<String, String> map = new HashMap<>();
            map.put(Const.Params.URL, Const.ServiceType.POST_PROVIDER_DETAIL_URL);
            map.put(Const.Params.ID, PreferenceHelper.getInstance().getUserId());
            map.put(Const.Params.TOKEN, PreferenceHelper.getInstance().getSessionToken());
            map.put(Const.Params.PROVIDER_ID, provider_id);
            AndyUtils.showSimpleProgressDialog(this, "Loading", false);
            new HttpRequester(this, Const.POST, map, Const.ServiceCode.POST_PROVIDER_DETAIL, this);
        }
    }

    @Override
    public void onTaskCompleted(String response, int serviceCode) {
        switch (serviceCode){
            case Const.ServiceCode.POST_PROVIDER_DETAIL:
                try {
                    JSONObject object = new JSONObject(response);
                    if (object.optString("success").equals("true")){
                        JSONObject data = object.getJSONObject("data");
                        ((TextView) findViewById(R.id.tv_provider_name)).setText(data.optString("provider_name"));
                        ((TextView) findViewById(R.id.tv_provider_mobile)).setText(data.optString("provider_mobile"));
                        if (data.optString("provider_picture") != null) {
                            Glide.with(this).load(data.optString("provider_picture")).into(iv_profile);
                        } else {
                            iv_profile.setImageResource(R.drawable.default_user);
                        }
                        JSONArray ratings = data.getJSONArray("ratings");
                        if (ratings.length() > 0){
                            for (int i = 0; i < ratings.length(); i++){
                                JSONObject rating = ratings.getJSONObject(i);
                                ProviderRating rat = new ProviderRating();
                                rat.setUserName(rating.optString("user_name"));
                                rat.setUserPicture(rating.optString("user_picture"));
                                rat.setComments(rating.optString("comment"));
                                rat.setRating(rating.optString("rating"));
                                providerRatingList.add(rat);
                            }
                        }
                        adapter.notifyDataSetChanged();
                        AndyUtils.removeProgressDialog();
                    }
                }
                catch (JSONException e){
                    e.printStackTrace();
                }
                break;
        }
    }
}
