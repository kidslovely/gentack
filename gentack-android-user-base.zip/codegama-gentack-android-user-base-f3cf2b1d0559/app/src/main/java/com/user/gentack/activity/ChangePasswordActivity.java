package com.user.gentack.activity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;

import com.user.gentack.R;
import com.user.gentack.custom_interface.AsyncTaskCompleteListener;
import com.user.gentack.networking.HttpRequester;
import com.user.gentack.utils.AndyUtils;
import com.user.gentack.utils.Const;
import com.user.gentack.utils.PreferenceHelper;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;


/**
 * Created by Mahesh on 3/13/2017.
 */

public class ChangePasswordActivity extends Activity implements View.OnClickListener, AsyncTaskCompleteListener {
    private ImageView btn_back_password;
    private EditText oldPasswordEdit, newPasswordEdit, confirmPasswordEdit;
    private Button changePasswordButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
        setContentView(R.layout.change_password);
        btn_back_password = (ImageView) findViewById(R.id.btn_back_password);
        oldPasswordEdit = (EditText) findViewById(R.id.et_old_pass);
        newPasswordEdit = (EditText) findViewById(R.id.et_new_pass);
        confirmPasswordEdit = (EditText) findViewById(R.id.et_confirm_pass);
        changePasswordButton = (Button) findViewById(R.id.btn_change_password);
        changePasswordButton.setOnClickListener(this);
        btn_back_password.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.btn_back_password:
                onBackPressed();
                break;
            case R.id.btn_change_password:
                if (oldPasswordEdit.getText().toString().length() == 0) {
                    AndyUtils.showShortToast("Please enter old password", this);
                } else if (newPasswordEdit.getText().toString().length() == 0) {
                    AndyUtils.showShortToast("Please enter new  password", this);
                } else if (newPasswordEdit.getText().toString().length() < 6) {
                    AndyUtils.showShortToast("New Password must have 6 characters", this);
                } else if (confirmPasswordEdit.getText().toString().length() == 0) {
                    AndyUtils.showShortToast("Please enter confirm password", this);
                } else if (confirmPasswordEdit.getText().toString().length() < 6) {
                    AndyUtils.showShortToast("Confirm Password must have 6 characters", this);
                } else if (!newPasswordEdit.getText().toString().equals(confirmPasswordEdit.getText().toString())) {
                    AndyUtils.showShortToast("New and Confirm password doesnot match", this);

                } else {
                    changePasswordRequest(oldPasswordEdit.getText().toString(), newPasswordEdit.getText().toString(), confirmPasswordEdit.getText().toString());
                }


            default:
                break;
        }

    }


    @Override
    public void onBackPressed() {
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
        finish();
    }

    private void changePasswordRequest(String oldPassword, String newPassword, String confirmPassword) {
        if (!AndyUtils.isNetworkAvailable(this)) {
            AndyUtils.showShortToast(getString(R.string.no_internet), this);
            return;
        }
        AndyUtils.showSimpleProgressDialog(this, getString(R.string.please_wait), false);
        HashMap<String, String> map = new HashMap<String, String>();
        map.put(Const.Params.URL, Const.ServiceType.POST_CHANGE_PASSWORD_URL);
        map.put(Const.Params.ID, PreferenceHelper.getInstance().getUserId());
        map.put(Const.Params.TOKEN, PreferenceHelper.getInstance().getSessionToken());
        map.put(Const.Params.OLD_PASSWORD, oldPassword);
        map.put(Const.Params.PASSWORD, newPassword);
        map.put(Const.Params.PASSWORD_CONFIRMATION, confirmPassword);


        AndyUtils.appLog("ChangePassword", "ChangePasswordMap" + map);

        new HttpRequester(this, Const.POST, map, Const.ServiceCode.POST_CHANGE_PASSWORD, this);
    }


    @Override
    public void onTaskCompleted(String response, int serviceCode) {
        switch (serviceCode) {
            case Const.ServiceCode.POST_CHANGE_PASSWORD:
                AndyUtils.removeProgressDialog();
                AndyUtils.appLog("ChangePassword", "ChangePAssowrdresponse" + response);
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    if (jsonObject.optString(Const.SUCCESS).equals(Const.TRUE)) {
                        AndyUtils.showLongToast(jsonObject.optString("message"), this);
                        PreferenceHelper.getInstance().putFirstTimeLogin(false);
                        Intent intent = new Intent(this, LoginRegisterActivity.class);
                        intent.putExtra(Const.Params.SINGIN_SIGNUP, Const.Params.LOGIN_FRAGMENT);
                        startActivity(intent);
                        finish();

                    } else {
                        AndyUtils.showLongToast(jsonObject.optString("error"), this);
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
        }
    }
}
