package com.user.gentack.fragment;

import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.app.Fragment;
import android.support.v7.app.AlertDialog;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.aurelhubert.simpleratingbar.SimpleRatingBar;
import com.bumptech.glide.Glide;
import com.user.gentack.R;
import com.user.gentack.activity.DetailProfileActivity;
import com.user.gentack.activity.InfoActivity;
import com.user.gentack.activity.JobActivity;
import com.user.gentack.activity.JobMapLaterActivity;
import com.user.gentack.adapter.JobAdapter;
import com.user.gentack.adapter.JobBidAdapter;
import com.user.gentack.custom_interface.AsyncTaskCompleteListener;
import com.user.gentack.model.BiddingProviderDetails;
import com.user.gentack.model.BiddingRequestDetails;
import com.user.gentack.model.ProviderRating;
import com.user.gentack.networking.HttpRequester;
import com.user.gentack.utils.AndyUtils;
import com.user.gentack.utils.Const;
import com.user.gentack.utils.ParseContent;
import com.user.gentack.utils.PreferenceHelper;
import com.user.gentack.utils.RecyclerViewItemClickListener;
import com.user.gentack.utils.VerticalSpaceItemDecoration;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/**
 * Created by user on 4/4/2017.
 */

public class JobFragment extends Fragment implements AsyncTaskCompleteListener {
    private RecyclerView recyclerView;
    private ProgressBar progressBar;
    private TextView noJob;
    private Bundle bundle;
    private String jobType = "", requestId = "";
    private JobActivity activity;
    private List<BiddingRequestDetails> biddingRequestDetailsList;
    private Dialog providerBidDialog;
    private ArrayList<ProviderRating> providerRatingArrayList;
    private JobAdapter jobAdapter;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        activity = (JobActivity) getActivity();
        bundle = getArguments();
        biddingRequestDetailsList = new ArrayList<>();
        if (bundle != null) {
            if (bundle.getBoolean("fromPush")) {
                requestId = bundle.getString(Const.Params.REQUEST_ID);
                String pageType = bundle.getString(Const.Params.JOB_TYPE);
                if (pageType != null) {
                    switch (pageType) {
                        case "1":
                            jobType = Const.POSTED;
                            break;
                        case "2":
                            jobType = Const.CONFIRMED;
                            break;
                    }
                }
            }
            else{
                jobType = bundle.getString(Const.Params.JOB_TYPE);
            }
        }
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_job_bidding_layout, container, false);
        recyclerView = (RecyclerView) view.findViewById(R.id.rv_bidding_job);
        progressBar = (ProgressBar) view.findViewById(R.id.bidding_progressbar);
        noJob = (TextView) view.findViewById(R.id.tv_noJob);

        if (bundle.getBoolean("fromPush")) {
            requestId = bundle.getString(Const.Params.REQUEST_ID);
            String pageType = bundle.getString(Const.Params.JOB_TYPE);
            Log.d("GCMfromPush", "TRUE JOB FRAGMENT" + requestId + pageType);
            if (pageType != null) {
                Log.d("GCMBidPageType", pageType);
                switch (pageType) {
                    case "1":
                        jobType = Const.POSTED;
                        Log.d("GCMBid", "Calling POSted");
                        getBidRequestDetails(requestId);
                        break;
                    case "2":
                        jobType = Const.CONFIRMED;
                        Log.d("GCMBid", "Calling confirmed");
                        getSingleRequestDetails(requestId);
                        break;
                }
            }
        }

        recyclerView.addOnItemTouchListener(new RecyclerViewItemClickListener(activity, new RecyclerViewItemClickListener.OnItemClickListener() {
            @Override
            public void onItemClick(View view, int position) {
                requestId = biddingRequestDetailsList.get(position).getRequestId();
                if (jobType.equals(Const.POSTED)) {
                    getBidRequestDetails(requestId);
                } else if (jobType.equals(Const.ONGOING)) {
                    Intent intent = new Intent(activity, JobMapLaterActivity.class);
                    intent.putExtra(Const.Params.REQUEST_ID, requestId);
                    startActivity(intent);
//                    showOnGoingDialog(biddingRequestDetailsList.get(position));
                } else if (jobType.equals(Const.CONFIRMED)) {
                    getSingleRequestDetails(requestId);
                }
            }
        }));


        return view;
    }

    @Override
    public void onResume() {
        super.onResume();

        if (jobType.equals(Const.POSTED)) {
            jobPostedRequest();
        } else if (jobType.equals(Const.ONGOING)) {
            jobOngoingRequest();

        } else if (jobType.equals(Const.CONFIRMED)) {
            jobConfirmedRequest();
        }

    }

    private void getSingleRequestDetails(String reqId) {
        if (!AndyUtils.isNetworkAvailable(activity)) {
            AndyUtils.showShortToast(getString(R.string.no_internet), activity);
            return;
        }

        if (jobType.equals(Const.CONFIRMED)) {
            AndyUtils.showSimpleProgressDialog(activity, getString(R.string.please_wait), false);
        }
        Log.d("GCMBid", reqId);
        HashMap<String, String> map = new HashMap<String, String>();
        map.put(Const.Params.URL, Const.ServiceType.POST_SINGLE_REQUEST_DETAIL_URL);
        map.put(Const.Params.ID, PreferenceHelper.getInstance().getUserId());
        map.put(Const.Params.TOKEN, PreferenceHelper.getInstance().getSessionToken());
        map.put(Const.Params.REQUEST_ID, String.valueOf(reqId));


        AndyUtils.appLog("Ashutosh", "SingleRequestMap" + map);
        new HttpRequester(activity, Const.POST, map, Const.ServiceCode.POST_SINGLE_REQUEST_DETAIL, this);
    }

    private void getBidRequestDetails(String reqId) {
        if (!AndyUtils.isNetworkAvailable(activity)) {
            AndyUtils.showShortToast(getString(R.string.no_internet), activity);
            return;
        }
        Log.d("GCMBid", reqId);
        AndyUtils.showSimpleProgressDialog(activity, getString(R.string.please_wait), false);
        HashMap<String, String> map = new HashMap<String, String>();
        map.put(Const.Params.URL, Const.ServiceType.POST_BIDS_DETAIL_URL);
        map.put(Const.Params.ID, PreferenceHelper.getInstance().getUserId());
        map.put(Const.Params.TOKEN, PreferenceHelper.getInstance().getSessionToken());
        map.put(Const.Params.REQUEST_ID, String.valueOf(reqId));


        AndyUtils.appLog("Ashutosh", "BidRequestMap" + map);
        new HttpRequester(activity, Const.POST, map, Const.ServiceCode.POST_BIDS_DETAIL, this);
    }


    private void jobPostedRequest() {
        if (!AndyUtils.isNetworkAvailable(activity)) {
            AndyUtils.showShortToast(getString(R.string.no_internet), activity);
            return;
        }
        if (biddingRequestDetailsList != null)
            biddingRequestDetailsList.clear();
        progressBar.setVisibility(View.VISIBLE);
        HashMap<String, String> map = new HashMap<String, String>();
        map.put(Const.Params.URL, Const.ServiceType.POST_POSTED_REQUESTED_URL);
        map.put(Const.Params.ID, PreferenceHelper.getInstance().getUserId());
        map.put(Const.Params.TOKEN, PreferenceHelper.getInstance().getSessionToken());


        AndyUtils.appLog("Ashutosh", "PostedRequestMap" + map);
        new HttpRequester(activity, Const.POST, map, Const.ServiceCode.POST_POSTED_REQUESTED, this);
    }


    private void jobConfirmedRequest() {
        if (!AndyUtils.isNetworkAvailable(activity)) {
            AndyUtils.showShortToast(getString(R.string.no_internet), activity);
            return;
        }
        if (biddingRequestDetailsList != null)
            biddingRequestDetailsList.clear();
        progressBar.setVisibility(View.VISIBLE);
        HashMap<String, String> map = new HashMap<String, String>();
        map.put(Const.Params.URL, Const.ServiceType.POST_CONFIRMED_REQUESTED_URL);
        map.put(Const.Params.ID, PreferenceHelper.getInstance().getUserId());
        map.put(Const.Params.TOKEN, PreferenceHelper.getInstance().getSessionToken());


        AndyUtils.appLog("Ashutosh", "PostedRequestMap" + map);
        new HttpRequester(activity, Const.POST, map, Const.ServiceCode.POST_CONFIRMED_REQUESTED, this);
    }


    private void jobOngoingRequest() {
        if (!AndyUtils.isNetworkAvailable(activity)) {
            AndyUtils.showShortToast(getString(R.string.no_internet), activity);

        }
        if (biddingRequestDetailsList != null)
            biddingRequestDetailsList.clear();
        progressBar.setVisibility(View.VISIBLE);
        HashMap<String, String> map = new HashMap<String, String>();
        map.put(Const.Params.URL, Const.ServiceType.POST_ONGOING_REQUESTED_URL);
        map.put(Const.Params.ID, PreferenceHelper.getInstance().getUserId());
        map.put(Const.Params.TOKEN, PreferenceHelper.getInstance().getSessionToken());


        AndyUtils.appLog("Ashutosh", "PostedRequestMap" + map);
        new HttpRequester(activity, Const.POST, map, Const.ServiceCode.POST_ONGOING_REQUESTED, this);
    }


    @Override
    public void onTaskCompleted(String response, int serviceCode) {

        switch (serviceCode) {
            case Const.ServiceCode.POST_POSTED_REQUESTED:
                progressBar.setVisibility(View.GONE);
                AndyUtils.appLog("JobActivity", "PostedRequestResponse" + response);
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    if (jsonObject.optString("success").equals("true")) {
                        biddingRequestDetailsList = ParseContent.getInstance().parsingBiddingDetails(response);
                        if (biddingRequestDetailsList != null && biddingRequestDetailsList.size() > 0) {
                            LinearLayoutManager layoutManager = new LinearLayoutManager(activity);
                            recyclerView.setLayoutManager(layoutManager);
                            jobAdapter = new JobAdapter(activity, biddingRequestDetailsList, jobType);
                            recyclerView.setItemAnimator(new DefaultItemAnimator());
                            recyclerView.setAdapter(jobAdapter);
                            jobAdapter.notifyDataSetChanged();

                        } else {
                            noJob.setVisibility(View.VISIBLE);
                        }
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                break;
            case Const.ServiceCode.POST_ONGOING_REQUESTED:
                progressBar.setVisibility(View.GONE);
                AndyUtils.appLog("JobActivity", "OngoingRequestResponse" + response);
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    if (jsonObject.optString("success").equals("true")) {
                        biddingRequestDetailsList = ParseContent.getInstance().parsingBiddingConfirmedDetails(response);
                        if (biddingRequestDetailsList != null && biddingRequestDetailsList.size() > 0) {
                            LinearLayoutManager layoutManager = new LinearLayoutManager(activity);
                            recyclerView.setLayoutManager(layoutManager);
                            jobAdapter = new JobAdapter(activity, biddingRequestDetailsList, jobType);
                            recyclerView.setItemAnimator(new DefaultItemAnimator());
                            recyclerView.setAdapter(jobAdapter);
                            jobAdapter.notifyDataSetChanged();
                        } else {
                            noJob.setVisibility(View.VISIBLE);
                        }
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                break;

            case Const.ServiceCode.POST_CONFIRMED_REQUESTED:
                progressBar.setVisibility(View.GONE);
                AndyUtils.appLog("JobActivity", "ConfirmedRequestResponse" + response);
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    if (jsonObject.optString("success").equals("true")) {
                        biddingRequestDetailsList = ParseContent.getInstance().parsingBiddingConfirmedDetails(response);
                        if (biddingRequestDetailsList != null && biddingRequestDetailsList.size() > 0) {
                            LinearLayoutManager layoutManager = new LinearLayoutManager(activity);
                            recyclerView.setLayoutManager(layoutManager);
                            jobAdapter = new JobAdapter(activity, biddingRequestDetailsList, jobType);
                            recyclerView.setItemAnimator(new DefaultItemAnimator());
                            recyclerView.setAdapter(jobAdapter);
                            jobAdapter.notifyDataSetChanged();
                        } else {
                            noJob.setVisibility(View.VISIBLE);
                        }
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                break;
            case Const.ServiceCode.POST_BIDS_DETAIL:
                AndyUtils.appLog("JobActivity", "BidDetailsResponse" + response);
                providerRatingArrayList = ParseContent.getInstance().parsingProviderBidList(response);
                getSingleRequestDetails(requestId);
                break;
            case Const.ServiceCode.POST_SINGLE_REQUEST_DETAIL:
                AndyUtils.removeProgressDialog();
                AndyUtils.appLog("JobActivity", "SingleRequestResponse" + response);
                BiddingProviderDetails biddingProviderDetails = ParseContent.getInstance().parsingSingleRequestDetails(response);
                if (biddingProviderDetails != null) {
                    if (jobType.equals(Const.POSTED)) {
                        showProviderDetailsDialog(biddingProviderDetails);
                    } else if (jobType.equals(Const.CONFIRMED)) {
                        showProviderConfirmedDetailsDialog(biddingProviderDetails);
                    }
                }
                break;
            case Const.ServiceCode.POST_CANCEL_REQUEST:
                AndyUtils.removeProgressDialog();
                AndyUtils.appLog("JobActivity", "CancelRequest" + response);
                if (providerBidDialog != null && providerBidDialog.isShowing()) {
                    providerBidDialog.dismiss();
                    if (jobType.equals(Const.POSTED)) {
                        biddingRequestDetailsList.clear();
                        jobAdapter.notifyDataSetChanged();
                        onResume();
                        jobPostedRequest();
                    }
                    else if(jobType.equals(Const.CONFIRMED)) {
                        biddingRequestDetailsList.clear();
                        jobAdapter.notifyDataSetChanged();
                        onResume();
                        jobConfirmedRequest();
                    }
                }
        }
    }

    private void cancelRequest(String requestId){
        HashMap<String, String> map = new HashMap<String, String>();
        map.put(Const.Params.URL, Const.ServiceType.POST_CANCEL_REQUEST_URL);
        map.put(Const.Params.ID, PreferenceHelper.getInstance().getUserId());
        map.put(Const.Params.TOKEN, PreferenceHelper.getInstance().getSessionToken());
        map.put(Const.Params.REQUEST_ID, requestId);
        AndyUtils.showSimpleProgressDialog(activity, getResources().getString(R.string.canceldialog), false);

        AndyUtils.appLog("Ashutosh", "CancelRequest" + map);
        new HttpRequester(activity, Const.POST, map, Const.ServiceCode.POST_CANCEL_REQUEST, this);
    }

    private void showOnGoingDialog(BiddingRequestDetails biddingRequestDetails) {
        Dialog dialog = new Dialog(activity);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.dialog_ongoing_request_layout);

        ImageView providerIcon = (ImageView) dialog.findViewById(R.id.iv_providerIcon);
        TextView providerName = (TextView) dialog.findViewById(R.id.tv_provider_name);
        TextView providerCharges = (TextView) dialog.findViewById(R.id.tv_provider_charge);
        Button status = (Button) dialog.findViewById(R.id.bn_status);
        TextView totalPrice = (TextView) dialog.findViewById(R.id.tv_totalPrice);
        TextView taxPrice = (TextView) dialog.findViewById(R.id.tv_taxPrice);
        TextView totalTime = (TextView) dialog.findViewById(R.id.tv_toatTime);
        TextView basePrice = (TextView) dialog.findViewById(R.id.tv_basePrice);
        TextView paymentMode = (TextView) dialog.findViewById(R.id.tv_payment_mode);
        LinearLayout invoiceLayout = (LinearLayout) dialog.findViewById(R.id.ll_invoice);
        Glide.with(activity).load(biddingRequestDetails.getProviderPicture()).into(providerIcon);
        providerName.setText(biddingRequestDetails.getProviderName());
        providerCharges.setText(biddingRequestDetails.getJobTitle() + "/" + biddingRequestDetails.getCurrency() + biddingRequestDetails.getPrice());

//        totalPrice.setText(" $" + biddingRequestDetails.getTotalPrice());
//        taxPrice.setText("$" + biddingRequestDetails.getTaxPrice());
//        basePrice.setText("$" + biddingRequestDetails.getBasePrice());
//        totalTime.setText(biddingRequestDetails.getExtraPrice() + "hrs");
//        paymentMode.setText(biddingRequestDetails.getPaymentMode());


        int providerStatus = Integer.parseInt(biddingRequestDetails.getProviderStatus());

        switch (providerStatus) {
            case 3:
                status.setText(getString(R.string.provider_started_1));
                break;
            case 4:
                status.setText(getString(R.string.provider_arrived_1));
                break;
            case 5:
                status.setText(getString(R.string.provider_service_start_1));
                break;
            case 6:
                status.setText(getString(R.string.provider_service_completed_1));
                break;


        }
        dialog.show();
    }


    private void showProviderDetailsDialog(final BiddingProviderDetails biddingProviderDetails) {
        providerBidDialog = new Dialog(activity, R.style.DialogThemeforview);
        providerBidDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        providerBidDialog.setContentView(R.layout.dialog_job_detailed_screen);
        ImageView providerIcon = (ImageView) providerBidDialog.findViewById(R.id.iv_userIcon);
        TextView providerName = (TextView) providerBidDialog.findViewById(R.id.tv_user_name);
        TextView providerCharge = (TextView) providerBidDialog.findViewById(R.id.tv_service_requested);
        SimpleRatingBar ratingBar = (SimpleRatingBar) providerBidDialog.findViewById(R.id.rating);
        TextView noRequestDate = (TextView) providerBidDialog.findViewById(R.id.tv_date);
        RecyclerView ratingRecyclerView = (RecyclerView) providerBidDialog.findViewById(R.id.rv_job);
        TextView headerText = (TextView) providerBidDialog.findViewById(R.id.tb_dialog_header_job);
        TextView noBid = (TextView) providerBidDialog.findViewById(R.id.tv_noBid);
        headerText.setText(biddingProviderDetails.getServiceType());
        FloatingActionButton info = (FloatingActionButton) providerBidDialog.findViewById(R.id.btn_floating_info);
        final FloatingActionButton cancel = (FloatingActionButton) providerBidDialog.findViewById(R.id.btn_floating_cancel);
        ImageView backButton = (ImageView) providerBidDialog.findViewById(R.id.btn_dialog_back_job);
        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                providerBidDialog.cancel();
            }
        });

        noRequestDate.setText(biddingProviderDetails.getRequestDate());
        if (biddingProviderDetails.getProviderPicture() != null && !biddingProviderDetails.getProviderPicture().equals("")) {
            Glide.with(activity).load(biddingProviderDetails.getProviderPicture()).into(providerIcon);
        } else {
            providerIcon.setImageResource(R.drawable.default_user);
        }
        providerName.setText(biddingProviderDetails.getServiceType());

        providerCharge.setText("$" + biddingProviderDetails.getCharge());
        if (providerRatingArrayList != null && providerRatingArrayList.size() > 0) {
            LinearLayoutManager layoutManager = new LinearLayoutManager(activity);
            ratingRecyclerView.setLayoutManager(layoutManager);
            JobBidAdapter ratingAdapter = new JobBidAdapter(activity, providerRatingArrayList);
            ratingRecyclerView.addItemDecoration(new VerticalSpaceItemDecoration(12));
            ratingRecyclerView.setAdapter(ratingAdapter);
        } else {
            noBid.setVisibility(View.VISIBLE);
        }
        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                new AlertDialog.Builder(activity)
                        .setTitle(getResources().getString(R.string.cancelrequest))
                        .setMessage(getResources().getString(R.string.cancelmessage))
                        .setPositiveButton(getResources().getString(R.string.ok), new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                cancelRequest(biddingProviderDetails.getRequestId());
                            }
                        })
                        .setNegativeButton(getResources().getString(R.string.cancel), new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                dialogInterface.cancel();
                            }
                        })
                        .create().show();
            }
        });

        info.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(activity, InfoActivity.class);
                intent.putExtra(Const.Params.REQUEST_ID, requestId);
                startActivity(intent);
            }
        });

        try {

            if (biddingProviderDetails.getRating().equals("0")) {
                ratingBar.setRating(0);
            } else {
                ratingBar.setRating(Integer.parseInt(String.valueOf((biddingProviderDetails.getRating().charAt(0)))));
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        providerBidDialog.setCancelable(true);
        providerBidDialog.show();

//        ratingRecyclerView.addOnItemTouchListener(new RecyclerViewItemClickListener(activity, new RecyclerViewItemClickListener.OnItemClickListener() {
//            @Override
//            public void onItemClick(View view, int position) {
//                ProviderRating providerDetails = providerRatingArrayList.get(position);
//                Bundle bundle = new Bundle();
//                bundle.putString(Const.Params.REQUEST_ID, providerDetails.getRequestId());
//                bundle.putString(Const.Params.PROVIDER_ID, providerDetails.getProviderId());
//                bundle.putString(Const.Params.NAME, providerDetails.getUserName());
//                bundle.putString(Const.Params.REQUEST_META_ID, providerDetails.getRequestMetaId());
//                bundle.putString(Const.Params.BID_STATUS, providerDetails.getBidStatus());
//                Intent intent = new Intent(activity, ChatActivity.class);
//                intent.putExtras(bundle);
//                startActivity(intent);
//
//            }
//        }));

    }

    private void showProviderConfirmedDetailsDialog(final BiddingProviderDetails biddingProviderDetails) {
        providerBidDialog = new Dialog(activity, R.style.DialogThemeforview);
        providerBidDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        providerBidDialog.setContentView(R.layout.dialog_job_detailed_screen);
        ImageView providerIcon = (ImageView) providerBidDialog.findViewById(R.id.iv_userIcon);
        TextView providerName = (TextView) providerBidDialog.findViewById(R.id.tv_user_name);
        TextView providerCharge = (TextView) providerBidDialog.findViewById(R.id.tv_service_requested);
        SimpleRatingBar ratingBar = (SimpleRatingBar) providerBidDialog.findViewById(R.id.rating);
        TextView noRequestDate = (TextView) providerBidDialog.findViewById(R.id.tv_date);
        RecyclerView ratingRecyclerView = (RecyclerView) providerBidDialog.findViewById(R.id.rv_job);
        TextView headerText = (TextView) providerBidDialog.findViewById(R.id.tb_dialog_header_job);
        FloatingActionButton info = (FloatingActionButton) providerBidDialog.findViewById(R.id.btn_floating_info);
        FloatingActionButton prov = (FloatingActionButton) providerBidDialog.findViewById(R.id.btn_floating_provider);
        final FloatingActionButton cancel = (FloatingActionButton) providerBidDialog.findViewById(R.id.btn_floating_cancel);
        TextView noBid = (TextView) providerBidDialog.findViewById(R.id.tv_noBid);
        TextView headerBid = (TextView) providerBidDialog.findViewById(R.id.tv_header);
        TextView jobDescription = (TextView) providerBidDialog.findViewById(R.id.tv_jobDescription);
        jobDescription.setVisibility(View.VISIBLE);
        jobDescription.setText("Job Description:" + " " + biddingProviderDetails.getJobDesc());
        headerBid.setVisibility(View.GONE);
        headerText.setText(biddingProviderDetails.getServiceType());

        ImageView backButton = (ImageView) providerBidDialog.findViewById(R.id.btn_dialog_back_job);
        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                providerBidDialog.cancel();
            }
        });
        prov.setVisibility(View.VISIBLE);

        prov.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(activity, DetailProfileActivity.class);
                intent.putExtra(Const.Params.PROVIDER_ID, biddingProviderDetails.getProviderId());
                Log.d("PROVIDERID", ""+biddingProviderDetails.getProviderId());
                startActivity(intent);
            }
        });
        noRequestDate.setText(biddingProviderDetails.getRequestDate());
        if (biddingProviderDetails.getProviderPicture() != null && !biddingProviderDetails.getProviderPicture().equals("")) {
            Glide.with(activity).load(biddingProviderDetails.getProviderPicture()).into(providerIcon);
        } else {
            providerIcon.setImageResource(R.drawable.default_user);
        }
        providerName.setText(biddingProviderDetails.getServiceType());

        providerCharge.setText("$" + biddingProviderDetails.getBidAmount());

        info.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(activity, InfoActivity.class);
                intent.putExtra(Const.Params.REQUEST_ID, requestId);
                startActivity(intent);
            }
        });

        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                new AlertDialog.Builder(activity)
                        .setTitle(getResources().getString(R.string.cancelrequest))
                        .setMessage(getResources().getString(R.string.cancelmessage))
                        .setPositiveButton(getResources().getString(R.string.ok), new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                cancelRequest(biddingProviderDetails.getRequestId());
                            }
                        })
                        .setNegativeButton(getResources().getString(R.string.cancel), new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                dialogInterface.cancel();
                            }
                        })
                        .create().show();
            }
        });

        try {

            if (biddingProviderDetails.getRating().equals("0")) {
                ratingBar.setRating(0);
            } else {
                ratingBar.setRating(Integer.parseInt(String.valueOf((biddingProviderDetails.getRating().charAt(0)))));
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        providerBidDialog.setCancelable(true);
        providerBidDialog.show();

        ratingRecyclerView.setVisibility(View.GONE);

    }
}
