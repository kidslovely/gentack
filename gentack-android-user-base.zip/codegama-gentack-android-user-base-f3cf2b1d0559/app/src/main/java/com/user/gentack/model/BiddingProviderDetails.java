package com.user.gentack.model;

import java.util.ArrayList;

/**
 * Created by user on 4/9/2017.
 */

public class BiddingProviderDetails {
    private String providerId;
    private String providerName;
    private String providerPicture;
    private String serviceType;
    private String rating;
    private String charge;
    private String providerNumber;
    private String requestId;
    private String currency;
    private String requestDate;
    private String bidAmount;
    private String jobDesc;

    public String getJobDesc() {
        return jobDesc;
    }

    public void setJobDesc(String jobDesc) {
        this.jobDesc = jobDesc;
    }

    public String getBidAmount() {
        return bidAmount;
    }

    public void setBidAmount(String bidAmount) {
        this.bidAmount = bidAmount;
    }

    public String getRequestDate() {
        return requestDate;
    }

    public void setRequestDate(String requestDate) {
        this.requestDate = requestDate;
    }

    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }

    private ArrayList<ProviderRating> providerRatingsArrayList;

    public String getRequestId() {
        return requestId;
    }

    public void setRequestId(String requestId) {
        this.requestId = requestId;
    }

    public String getProviderId() {
        return providerId;
    }

    public void setProviderId(String providerId) {
        this.providerId = providerId;
    }

    public String getProviderName() {
        return providerName;
    }

    public void setProviderName(String providerName) {
        this.providerName = providerName;
    }

    public String getProviderPicture() {
        return providerPicture;
    }

    public void setProviderPicture(String providerPicture) {
        this.providerPicture = providerPicture;
    }

    public String getServiceType() {
        return serviceType;
    }

    public void setServiceType(String serviceType) {
        this.serviceType = serviceType;
    }

    public String getRating() {
        return rating;
    }

    public void setRating(String rating) {
        this.rating = rating;
    }

    public String getCharge() {
        return charge;
    }

    public void setCharge(String charge) {
        this.charge = charge;
    }

    public String getProviderNumber() {
        return providerNumber;
    }

    public void setProviderNumber(String providerNumber) {
        this.providerNumber = providerNumber;
    }

    public ArrayList<ProviderRating> getProviderRatingsArrayList() {
        return providerRatingsArrayList;
    }

    public void setProviderRatingsArrayList(ArrayList<ProviderRating> providerRatingsArrayList) {
        this.providerRatingsArrayList = providerRatingsArrayList;
    }

}

