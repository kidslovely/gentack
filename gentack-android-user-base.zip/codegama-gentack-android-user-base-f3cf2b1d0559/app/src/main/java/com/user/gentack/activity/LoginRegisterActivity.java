package com.user.gentack.activity;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.user.gentack.R;
import com.user.gentack.fragment.LoginFragment;
import com.user.gentack.fragment.SignUpFragment;
import com.user.gentack.utils.Const;

public class LoginRegisterActivity extends AppCompatActivity {

    public ImageView backButton;
    private Toolbar toolbar;
    private Intent intent;
    private TextView headerText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_register);
        toolbar = (Toolbar) findViewById(R.id.tb_login_register);
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle("");
        headerText = (TextView) findViewById(R.id.toolbar_header);
        backButton = (ImageView) findViewById(R.id.iv_back);
        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });

        try {
            intent = getIntent();
            if (intent != null) {
                if (intent.getStringExtra(Const.Params.SINGIN_SIGNUP).equals(Const.Params.LOGIN_FRAGMENT)) {
                    addFragment(new LoginFragment(), false, Const.Params.LOGIN_FRAGMENT, "");
                } else if (intent.getStringExtra(Const.Params.SINGIN_SIGNUP).equals(Const.Params.SIGNUP_FRAGMENT)) {
                    addFragment(new SignUpFragment(), false, Const.Params.SIGNUP_FRAGMENT, "");
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

    }


    public void addFragment(Fragment fragment, boolean addToBackStack, String fragmentTitle,
                            String tag) {
        FragmentManager manager = getSupportFragmentManager();
        FragmentTransaction ft = manager.beginTransaction();
        if (fragmentTitle.equals(Const.Params.LOGIN_FRAGMENT)) {
            headerText.setText(getString(R.string.login));
        } else if (fragmentTitle.equals(Const.Params.SIGNUP_FRAGMENT)) {
            headerText.setText(getString(R.string.signup));
        }
        if (addToBackStack) {
            ft.addToBackStack(tag);
        }
        ft.replace(R.id.fl_container, fragment, tag);
        ft.commit();
    }


    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }
}
