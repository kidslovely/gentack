package com.user.gentack.adapter;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.aurelhubert.simpleratingbar.SimpleRatingBar;
import com.bumptech.glide.Glide;
import com.user.gentack.R;
import com.user.gentack.model.ProviderRating;

import java.util.List;

/**
 * Created by user on 4/8/2017.
 */

public class ProviderUserRatingAdapter extends RecyclerView.Adapter<ProviderUserRatingAdapter.CustomViewHolder> {


    private Context mContext;
    private List<ProviderRating> requestDetailsList;

    public ProviderUserRatingAdapter(Context context, List<ProviderRating> requestDetailsList) {
        mContext = context;
        this.requestDetailsList = requestDetailsList;
    }

    @Override
    public CustomViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(mContext).inflate(R.layout.adapter_provider_rating_layout, null);

        return new CustomViewHolder(view);
    }

    @Override
    public void onBindViewHolder(CustomViewHolder holder, int position) {
        ProviderRating requestDetails = requestDetailsList.get(position);
        if (requestDetails.getUserPicture() != null && !requestDetails.getUserPicture().equals("")) {
            Glide.with(mContext).load(requestDetails.getUserPicture()).into(holder.userIcon);
        } else {
            holder.userIcon.setImageResource(R.drawable.default_user);
        }


        holder.userName.setText(requestDetails.getUserName());
        holder.comments.setText(requestDetails.getComments());


        try {

            if (requestDetails.getRating().equals("0")) {
                holder.ratingBar.setRating(0);
            } else {
                holder.ratingBar.setRating(Integer.parseInt(String.valueOf((requestDetails.getRating().charAt(0)))));
            }


        } catch (Exception e) {
            e.printStackTrace();
        }


    }

    @Override
    public int getItemCount() {
        return requestDetailsList.size();
    }

    public class CustomViewHolder extends RecyclerView.ViewHolder {
        private ImageView userIcon;
        private TextView comments, userName;
        private SimpleRatingBar ratingBar;


        public CustomViewHolder(View itemView) {
            super(itemView);
            userIcon = (ImageView) itemView.findViewById(R.id.iv_user_rating);
            userName = (TextView) itemView.findViewById(R.id.tv_rating_name);
            ratingBar = (SimpleRatingBar) itemView.findViewById(R.id.user_rating);
            comments = (TextView) itemView.findViewById(R.id.tv_rating_comments);

        }
    }
}