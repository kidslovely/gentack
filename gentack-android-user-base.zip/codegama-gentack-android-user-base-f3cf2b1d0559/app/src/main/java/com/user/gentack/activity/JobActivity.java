package com.user.gentack.activity;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.user.gentack.R;
import com.user.gentack.fragment.JobFragment;
import com.user.gentack.utils.Const;

public class JobActivity extends AppCompatActivity implements View.OnClickListener {


    private Toolbar jobToolBar;
    private ImageView backButton;
    private TextView noJob, headerText, postedText, ongoingText, confirmedText;
    JobFragment jobFragment;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_job);
        jobToolBar = (Toolbar) findViewById(R.id.tb_job);
        setSupportActionBar(jobToolBar);
        getSupportActionBar().setTitle("");
        backButton = (ImageView) findViewById(R.id.btn_back_job);
        noJob = (TextView) findViewById(R.id.tv_noJob);
        headerText = (TextView) findViewById(R.id.tb_header_job);
        headerText.setText("Jobs");
        postedText = (TextView) findViewById(R.id.tv_job_posted);
        ongoingText = (TextView) findViewById(R.id.tv_job_ongoing);
        confirmedText = (TextView) findViewById(R.id.tv_job_confirmed);

        postedText.setBackgroundResource(R.color.dark_grey);
        backButton.setOnClickListener(this);
        postedText.setOnClickListener(this);
        ongoingText.setOnClickListener(this);
        confirmedText.setOnClickListener(this);

        if (getIntent().hasExtra("fromPush")){
            Bundle bundle = new Bundle();
            bundle.putString(Const.Params.REQUEST_ID, getIntent().getStringExtra(Const.Params.REQUEST_ID));
            bundle.putString(Const.Params.JOB_TYPE, getIntent().getStringExtra(Const.Params.JOB_TYPE));
            bundle.putBoolean("fromPush", true);
            jobFragment = new JobFragment();
            jobFragment.setArguments(bundle);
        }
        else {
            Bundle bundle = new Bundle();
            bundle.putString(Const.Params.JOB_TYPE, Const.POSTED);
            bundle.putBoolean("fromPush", false);
            jobFragment = new JobFragment();
            jobFragment.setArguments(bundle);
        }
        addFragment(jobFragment, false, "", "");

    }


    public void addFragment(Fragment fragment, boolean addToBackStack, String fragmentTitle,
                            String tag) {
        FragmentManager manager = getSupportFragmentManager();
        FragmentTransaction ft = manager.beginTransaction();
//        if (fragmentTitle.equals(Const.Params.SIGNIN_FRAGMENT)) {
//        } else if (fragmentTitle.equals(Const.Params.SIGNUP_FRAGMENT)) {
//        }
        if (addToBackStack) {
            ft.addToBackStack(tag);
        }
        ft.replace(R.id.fl_job, fragment, tag);
        ft.commit();
    }

    @Override
    public void onClick(View view) {

        switch (view.getId()) {
            case R.id.btn_back_job:
                onBackPressed();
                break;
            case R.id.tv_job_posted:
                postedText.setBackgroundResource(R.color.dark_grey);
                ongoingText.setBackgroundResource(R.color.background_color);
                confirmedText.setBackgroundResource(R.color.background_color);
                Bundle bundle = new Bundle();
                bundle.putString(Const.Params.JOB_TYPE, Const.POSTED);
                JobFragment jobFragment = new JobFragment();
                jobFragment.setArguments(bundle);
                addFragment(jobFragment, false, "", "");

                break;
            case R.id.tv_job_ongoing:
                postedText.setBackgroundResource(R.color.background_color);
                ongoingText.setBackgroundResource(R.color.dark_grey);
                confirmedText.setBackgroundResource(R.color.background_color);
                Bundle ongoingBundle = new Bundle();
                ongoingBundle.putString(Const.Params.JOB_TYPE, Const.ONGOING);
                JobFragment ongoingFragment = new JobFragment();
                ongoingFragment.setArguments(ongoingBundle);
                addFragment(ongoingFragment, false, "", "");

                break;
            case R.id.tv_job_confirmed:
                postedText.setBackgroundResource(R.color.background_color);
                ongoingText.setBackgroundResource(R.color.background_color);
                confirmedText.setBackgroundResource(R.color.dark_grey);

                Bundle confirmedBundle = new Bundle();
                confirmedBundle.putString(Const.Params.JOB_TYPE, Const.CONFIRMED);
                JobFragment confirmedFragment = new JobFragment();
                confirmedFragment.setArguments(confirmedBundle);
                addFragment(confirmedFragment, false, "", "");

                break;

        }

    }


    @Override
    public void onBackPressed() {
        Intent intent = new Intent(this, MainActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
        finish();
    }
}
