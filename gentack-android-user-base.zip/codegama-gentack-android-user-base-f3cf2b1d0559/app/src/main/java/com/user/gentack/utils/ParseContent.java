package com.user.gentack.utils;


import com.user.gentack.model.BiddingProviderDetails;
import com.user.gentack.model.BiddingRequestDetails;
import com.user.gentack.model.CategoryDetails;
import com.user.gentack.model.ProviderRating;
import com.user.gentack.model.RequestDetails;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by user on 2/1/2017.
 */

public class ParseContent {
    private static ParseContent parseContent = new ParseContent();

    private ParseContent() {

    }

    public static ParseContent getInstance() {
        return parseContent;
    }


    //    public int getStatusCode(String response) {
//        try {
//            JSONObject jsonObject = new JSONObject(response);
//            if (jsonObject.optInt(Const.Params.STATUS_CODE) == 200) {
//                return 200;
//            } else if (jsonObject.optInt(Const.Params.STATUS_CODE) == 500) {
//                return 500;
//            }
//        } catch (JSONException e) {
//            e.printStackTrace();
//        }
//        return 500;
//    }
//
//    public ParkingDetails parsingQrCode(String response) {
//        ParkingDetails parkingDetails = null;
//        try {
//            JSONObject jsonObject = new JSONObject(response);
//            JSONObject responseObject = jsonObject.optJSONObject(Const.Params.RESPONSE);
//            JSONObject orderObject = responseObject.optJSONObject("order");
//            if (orderObject != null) {
//                parkingDetails = new ParkingDetails();
//                parkingDetails.setQrCode(orderObject.optString("qr_code"));
//                parkingDetails.setOrderId(orderObject.optString(Const.Params.ID));
//            }
//        } catch (JSONException e) {
//            e.printStackTrace();
//        }
//
//        return parkingDetails;
//
//    }
//
//
//    public String parsingAccessToken(String response) {
//        JSONObject jsonObject = null;
//        String accessToken = "";
//        try {
//            jsonObject = new JSONObject(response);
//            if (jsonObject.optInt(Const.Params.STATUS_CODE) == 200) {
//                JSONObject responseObject = jsonObject.getJSONObject(Const.Params.RESPONSE);
//                accessToken = responseObject.optString("access_token");
//            }
//        } catch (JSONException e) {
//            e.printStackTrace();
//        }
//
//        return accessToken;
//    }
//
//    public String getErrorMessage(String response) {
//        try {
//            JSONObject jsonObject = new JSONObject(response);
//            if (jsonObject.optInt(Const.Params.STATUS_CODE) == 200) {
//                return null;
//            } else if (jsonObject.optInt(Const.Params.STATUS_CODE) == 500) {
//                return jsonObject.optString(Const.STATUS_MESSAGE);
//            }
//        } catch (JSONException e) {
//            e.printStackTrace();
//        }
//        return null;
//    }
//
//
    public void saveIdAndToken(String response) {
        try {
            JSONObject jsonObject = new JSONObject(response);
            if (jsonObject.optString(Const.SUCCESS).equals(Const.TRUE)) {
                JSONObject dataObject = jsonObject.optJSONObject("data");
                if (dataObject != null) {
                    PreferenceHelper.getInstance().putUserId(dataObject.optString("user_id"));
                    PreferenceHelper.getInstance().putSessionToken(dataObject.optString(Const.Params.TOKEN));
                    PreferenceHelper.getInstance().putUser_name(dataObject.optString("user_name"));
                    PreferenceHelper.getInstance().putEmail(dataObject.optString(Const.Params.EMAIL));
                    PreferenceHelper.getInstance().putPicture(dataObject.optString("user_picture"));
                    PreferenceHelper.getInstance().putLoginBy(dataObject.optString("login_by"));
                }
            }

        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    public RequestDetails parsingRequestInProgress(String response) {
        RequestDetails requestDetails = null;
        try {
            JSONObject jsonObject = new JSONObject(response);
            if (jsonObject.getString(Const.SUCCESS).equals(Const.TRUE)) {
                JSONArray dataArray = jsonObject.optJSONArray("data");
                if (dataArray != null && dataArray.length() > 0) {
                    JSONObject dataObject = dataArray.optJSONObject(0);
                    if (dataObject != null) {
                        requestDetails = new RequestDetails();
                        requestDetails.setRequestId(dataObject.optString(Const.Params.REQUEST_ID));
                        requestDetails.setCurrency(dataObject.optString("currency"));
                        requestDetails.setCharges(dataObject.optString(Const.Params.USER_PRICE));
                        requestDetails.setsLatitude(dataObject.optString("s_latitude"));
                        requestDetails.setsLongitude(dataObject.optString("s_longitude"));
                        requestDetails.setProviderLatitude(dataObject.optString("d_latitude"));
                        requestDetails.setProviderLongitude(dataObject.optString("d_longitude"));
                        requestDetails.setJobTitle(dataObject.optString("sub_category_name"));
                        requestDetails.setProviderId(dataObject.optString(Const.Params.PROVIDER_ID));
                        requestDetails.setProviderStatus(dataObject.optString("provider_status"));
                        requestDetails.setProviderName(dataObject.optString("provider_name"));
                        requestDetails.setProviderPicture(dataObject.optString("provider_picture"));
                        requestDetails.setProviderRating(dataObject.optString("provder_rating"));
                        requestDetails.setProviderLatitude(dataObject.optString("provider_lat"));
                        requestDetails.setProviderLongitude(dataObject.optString("provider_long"));
                        requestDetails.setStatus(dataObject.optString("status"));
                        requestDetails.setBeforeImage(dataObject.optString("before_image"));
                        requestDetails.setAfterImage(dataObject.optString("after_image"));
                        requestDetails.setProviderPhone(dataObject.optString("provider_mobile"));
                    }
                }
                JSONArray invoiceArray = jsonObject.optJSONArray("invoice");
                if (invoiceArray != null && invoiceArray.length() > 0) {
                    JSONObject invoiceObject = invoiceArray.getJSONObject(0);
                    requestDetails.setTotalPrice(invoiceObject.optString("total"));
                    requestDetails.setBasePrice(invoiceObject.optString("price_per_hour"));
                    requestDetails.setTaxPrice(invoiceObject.optString("tax_price"));
                    requestDetails.setExtraPrice(invoiceObject.optString("total_time"));
                    requestDetails.setPaymentMode(invoiceObject.optString("payment_mode"));
                }


                return requestDetails;

            }

        } catch (JSONException e) {
            e.printStackTrace();
        }

        return requestDetails;
    }

    public boolean isSuccess(String response){
        try {
            JSONObject dataObject = new JSONObject(response);
            if (dataObject.getString(Const.SUCCESS).equals(Const.TRUE)){
                return true;
            }
        }
        catch (JSONException e){
            e.printStackTrace();
        }
        return false;
    }


    public RequestDetails parsingRequestInLaterProgress(String response) {
        RequestDetails requestDetails = null;
        try {
            JSONObject jsonObject = new JSONObject(response);
            if (jsonObject.getString(Const.SUCCESS).equals(Const.TRUE)) {
                JSONArray dataArray = jsonObject.optJSONArray("data");
                if (dataArray != null && dataArray.length() > 0) {
                    JSONObject dataObject = dataArray.optJSONObject(0);
                    if (dataObject != null) {
                        if (dataObject.optString("status").equals("8")) {
                            return null;
                        }
                        requestDetails = new RequestDetails();
                        requestDetails.setRequestId(dataObject.optString(Const.Params.REQUEST_ID));
                        requestDetails.setCurrency(dataObject.optString("currency"));
                        requestDetails.setCharges(dataObject.optString(Const.Params.USER_PRICE));
                        requestDetails.setProviderLatitude(dataObject.optString("d_latitude"));
                        requestDetails.setProviderLongitude(dataObject.optString("d_longitude"));
                        requestDetails.setJobTitle(dataObject.optString("sub_category_name"));
                        requestDetails.setProviderStatus(dataObject.optString("provider_status"));
                        requestDetails.setProviderName(dataObject.optString("provider_name"));
                        requestDetails.setProviderId(dataObject.optString(Const.Params.PROVIDER_ID));
                        requestDetails.setProviderPicture(dataObject.optString("provider_picture"));
                        requestDetails.setProviderRating(dataObject.optString("provder_rating"));
                        requestDetails.setProviderLatitude(dataObject.optString("provider_lat"));
                        requestDetails.setProviderLongitude(dataObject.optString("provider_long"));
                        requestDetails.setsLatitude(dataObject.optString("s_latitude"));
                        requestDetails.setsLongitude(dataObject.optString("s_longitude"));
                        requestDetails.setStatus(dataObject.optString("status"));
                        requestDetails.setBeforeImage(dataObject.optString("before_image"));
                        requestDetails.setAfterImage(dataObject.optString("after_image"));
                        requestDetails.setProviderPhone(dataObject.optString("provider_mobile"));
                        JSONArray invoiceArray = dataObject.optJSONArray("invoice");
                        if (invoiceArray != null && invoiceArray.length() > 0) {
                            JSONObject invoiceObject = invoiceArray.getJSONObject(0);
                            requestDetails.setTotalPrice(invoiceObject.optString("total"));
                            requestDetails.setBasePrice(invoiceObject.optString("price_per_hour"));
                            requestDetails.setTaxPrice(invoiceObject.optString("tax_price"));
                            requestDetails.setExtraPrice(invoiceObject.optString("total_time"));
                            requestDetails.setPaymentMode(invoiceObject.optString("payment_mode"));
                        }
                    }
                }

                return requestDetails;

            }

        } catch (JSONException e) {
            e.printStackTrace();
        }

        return requestDetails;
    }

    //
    public List<CategoryDetails> parsingCategoryListResponse(String response) {
        List<CategoryDetails> categoryDetailsList = null;
        try {
            JSONObject jsonObject = new JSONObject(response);
            categoryDetailsList = new ArrayList<>();
            if (jsonObject.getString(Const.SUCCESS).equals(Const.TRUE)) {
                JSONArray jsonArray = jsonObject.optJSONArray("data");
                if (jsonArray != null && jsonArray.length() > 0) {
                    for (int i = 0; i < jsonArray.length(); i++) {
                        JSONObject categoryJsonObject = jsonArray.getJSONObject(i);
                        CategoryDetails categoryDetails = new CategoryDetails();
                        categoryDetails.setCategoryId(categoryJsonObject.optString("category_id"));
                        categoryDetails.setCategory(categoryJsonObject.optString("category_name"));
                        categoryDetails.setPictureUrl(categoryJsonObject.optString("category_picture"));
                        categoryDetailsList.add(categoryDetails);
                    }
                }
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }

        return categoryDetailsList;
    }


    public List<CategoryDetails> parsingSubCategoryListResponse(String response) {
        List<CategoryDetails> categoryDetailsList = null;
        try {
            JSONObject jsonObject = new JSONObject(response);
            categoryDetailsList = new ArrayList<>();
            if (jsonObject.getString(Const.SUCCESS).equals(Const.TRUE)) {
                JSONArray jsonArray = jsonObject.optJSONArray("data");
                if (jsonArray != null && jsonArray.length() > 0) {
                    for (int i = 0; i < jsonArray.length(); i++) {
                        JSONObject categoryJsonObject = jsonArray.getJSONObject(i);
                        CategoryDetails categoryDetails = new CategoryDetails();
                        categoryDetails.setCategoryId(categoryJsonObject.optString("sub_category_id"));
                        categoryDetails.setCategory(categoryJsonObject.optString("sub_category_name"));
                        categoryDetails.setPictureUrl(categoryJsonObject.optString("sub_category_picture"));
                        categoryDetails.setPrice(categoryJsonObject.optString("price"));
                        categoryDetailsList.add(categoryDetails);
                    }
                }
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }

        return categoryDetailsList;
    }

    public List<RequestDetails> parsingHistoryResponse(String response) {
        List<RequestDetails> requestDetailsList = null;
        try {
            JSONObject jsonObject = new JSONObject(response);
            requestDetailsList = new ArrayList<>();
            if (jsonObject.getString(Const.SUCCESS).equals(Const.TRUE)) {
                JSONArray jsonArray = jsonObject.optJSONArray("data");
                if (jsonArray != null && jsonArray.length() > 0) {
                    for (int i = 0; i < jsonArray.length(); i++) {
                        JSONObject requestJsonObject = jsonArray.getJSONObject(i);
                        RequestDetails requestDetails = new RequestDetails();
                        requestDetails.setProviderName(requestJsonObject.optString("provider_name"));
                        requestDetails.setProviderPicture(requestJsonObject.optString("provider_picture"));
                        requestDetails.setJobTitle(requestJsonObject.optString("sub_category_name"));
                        requestDetails.setCharges(requestJsonObject.optString("total"));
                        requestDetails.setCurrency(requestJsonObject.optString("currency"));
                        requestDetails.setRequestedDate(requestJsonObject.optString("request_date"));
                        requestDetails.setProviderAddress(requestJsonObject.optString("s_address"));
                        requestDetails.setRequestId(requestJsonObject.optString(Const.Params.REQUEST_ID));
                        requestDetailsList.add(requestDetails);
                    }
                }
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }

        return requestDetailsList;
    }


    public List<BiddingRequestDetails> parsingBiddingDetails(String response) {
        List<BiddingRequestDetails> requestDetailsList = null;
        try {
            JSONObject jsonObject = new JSONObject(response);
            requestDetailsList = new ArrayList<>();
            if (jsonObject.getString(Const.SUCCESS).equals(Const.TRUE)) {
                JSONArray jsonArray = jsonObject.optJSONArray("data");
                if (jsonArray != null && jsonArray.length() > 0) {
                    for (int i = 0; i < jsonArray.length(); i++) {
                        JSONObject requestJsonObject = jsonArray.getJSONObject(i);
                        BiddingRequestDetails requestDetails = new BiddingRequestDetails();
                        requestDetails.setRequestId(requestJsonObject.optString("request_id"));
                        requestDetails.setServicePicture(requestJsonObject.optString("service_picture"));
                        requestDetails.setJobTitle(requestJsonObject.optString("name"));
                        requestDetails.setPrice(requestJsonObject.optString("user_price"));
                        requestDetails.setCurrency(requestJsonObject.optString("currency"));
                        requestDetails.setDescription(requestJsonObject.optString("description"));
                        requestDetails.setServiceType(requestJsonObject.optString("sub_category_name"));
                        requestDetails.setPricePerHour(requestJsonObject.optString(Const.Params.PRICE_PER_HOUR));


                        requestDetailsList.add(requestDetails);
                    }
                }
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }

        return requestDetailsList;
    }


    public List<BiddingRequestDetails> parsingBiddingConfirmedDetails(String response) {
        List<BiddingRequestDetails> requestDetailsList = null;
        try {
            JSONObject jsonObject = new JSONObject(response);
            requestDetailsList = new ArrayList<>();
            if (jsonObject.getString(Const.SUCCESS).equals(Const.TRUE)) {
                JSONArray jsonArray = jsonObject.optJSONArray("data");
                if (jsonArray != null && jsonArray.length() > 0) {
                    for (int i = 0; i < jsonArray.length(); i++) {
                        JSONObject requestJsonObject = jsonArray.getJSONObject(i);
                        BiddingRequestDetails requestDetails = new BiddingRequestDetails();
                        requestDetails.setRequestId(requestJsonObject.optString("request_id"));
                        requestDetails.setServicePicture(requestJsonObject.optString("service_picture"));
                        requestDetails.setJobTitle(requestJsonObject.optString("name"));
                        requestDetails.setPrice(requestJsonObject.optString(Const.Params.PRICE_PER_HOUR));
                        requestDetails.setCurrency(requestJsonObject.optString("currency"));
                        requestDetails.setDescription(requestJsonObject.optString("description"));
                        requestDetails.setServiceType(requestJsonObject.optString("sub_category_name"));
                        requestDetails.setProviderStatus(requestJsonObject.optString("provider_status"));
                        requestDetails.setStatus(requestJsonObject.optString("status"));
                        requestDetails.setProviderName(requestJsonObject.optString("provider_name"));
                        requestDetails.setProviderPicture(requestJsonObject.optString("provider_picture"));
                        requestDetailsList.add(requestDetails);
                    }
                }
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }

        return requestDetailsList;
    }

    public BiddingProviderDetails parsingBiddingProviderDetails(String response) {
        BiddingProviderDetails requestDetails = null;
        try {
            JSONObject jsonObject = new JSONObject(response);

            if (jsonObject.getString(Const.SUCCESS).equals(Const.TRUE)) {

                JSONObject dataObject = jsonObject.getJSONObject("data");
                requestDetails = new BiddingProviderDetails();
                requestDetails.setProviderId(dataObject.optString("provider_id"));
                requestDetails.setProviderName(dataObject.optString("provider_name"));
                requestDetails.setProviderPicture(dataObject.optString("provider_picture"));
                requestDetails.setProviderNumber(dataObject.optString("provider_mobile"));
                requestDetails.setServiceType(dataObject.optString("service_name"));
                requestDetails.setRating(dataObject.optString("rating"));
                requestDetails.setCharge(dataObject.optString("price_per_hour"));


                JSONArray jsonArray = dataObject.optJSONArray("ratings");
                if (jsonArray != null && jsonArray.length() > 0) {
                    ArrayList<ProviderRating> providerRatingsList = new ArrayList<>();
                    for (int i = 0; i < jsonArray.length(); i++) {
                        JSONObject ratingObject = jsonArray.getJSONObject(i);
                        ProviderRating providerRating = new ProviderRating();
                        providerRating.setRating(ratingObject.optString("rating"));
                        providerRating.setComments(ratingObject.optString("comment"));
                        providerRating.setUserName(ratingObject.optString("user_name"));
                        providerRating.setUserPicture(ratingObject.optString("user_picture"));
                        providerRatingsList.add(providerRating);
                    }
                    requestDetails.setProviderRatingsArrayList(providerRatingsList);
                }
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }

        return requestDetails;
    }


    public BiddingProviderDetails parsingSingleRequestDetails(String response) {
        BiddingProviderDetails requestDetails = null;
        try {
            JSONObject jsonObject = new JSONObject(response);

            if (jsonObject.getString(Const.SUCCESS).equals(Const.TRUE)) {

                JSONObject dataObject = jsonObject.getJSONObject("data");
                requestDetails = new BiddingProviderDetails();
                requestDetails.setRequestId(dataObject.optString("request_id"));
                requestDetails.setProviderPicture(dataObject.optString("sub_category_picture"));
                requestDetails.setServiceType(dataObject.optString("sub_category_name"));
                requestDetails.setRating(dataObject.optString("user_rating"));
                requestDetails.setCharge(dataObject.optString("user_price"));
                requestDetails.setProviderId(dataObject.optString("provider_id"));
                requestDetails.setCurrency(dataObject.optString("currency"));
                requestDetails.setRequestDate(dataObject.optString("request_date"));
                requestDetails.setBidAmount(dataObject.optString("price_per_hour"));
                requestDetails.setJobDesc(dataObject.optString("description"));


            }
        } catch (JSONException e) {
            e.printStackTrace();
        }

        return requestDetails;
    }

    public ArrayList<ProviderRating> parsingProviderBidList(String response) {

        ArrayList<ProviderRating> providerRatingsList = null;

        try {
            JSONObject jsonObject = new JSONObject(response);
            providerRatingsList = new ArrayList<>();
            if (jsonObject.getString(Const.SUCCESS).equals(Const.TRUE)) {
                JSONArray jsonArray = jsonObject.optJSONArray("data");

                if (jsonArray != null && jsonArray.length() > 0) {
                    for (int i = 0; i < jsonArray.length(); i++) {
                        JSONObject ratingObject = jsonArray.getJSONObject(i);
                        ProviderRating providerRating = new ProviderRating();
                        providerRating.setRating(ratingObject.optString("rating"));
                        providerRating.setUserName(ratingObject.optString("provider_name"));
                        providerRating.setUserPicture(ratingObject.optString("provider_picture"));
                        providerRating.setRequestId(ratingObject.optString("request_id"));
                        providerRating.setRequestMetaId(ratingObject.optString("request_meta_id"));
                        providerRating.setProviderId(ratingObject.optString("provider_id"));
                        providerRating.setBidAmount(ratingObject.optString("bid_amount"));
                        providerRating.setBidStatus(ratingObject.optString("bid_status"));
                        providerRatingsList.add(providerRating);

                    }
                }
            }


        } catch (JSONException e) {
            e.printStackTrace();
        }
        return providerRatingsList;


    }

    public int getErrorCode(String response){
        try {
            JSONObject error = new JSONObject(response);
            return error.optInt("error_code");
        }
        catch (JSONException e){
            e.printStackTrace();
        }
        return -1;
    }
}

