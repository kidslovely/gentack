package com.user.gentack.adapter;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.user.gentack.R;
import com.user.gentack.model.CategoryDetails;

import java.util.List;

/**
 * Created by user on 3/3/2017.
 */

public class CategoryAdapter extends RecyclerView.Adapter<CategoryAdapter.CustomHolder> {

    private Context mContext;
    private List<CategoryDetails> categoryDetailsList;

    public CategoryAdapter(Context context, List<CategoryDetails> categoryDetailsList) {
        mContext = context;
        this.categoryDetailsList = categoryDetailsList;
    }

    @Override
    public CategoryAdapter.CustomHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(mContext).inflate(R.layout.adapter_category_item_layout, null);
        return new CustomHolder(view);
    }

    @Override
    public void onBindViewHolder(CategoryAdapter.CustomHolder holder, int position) {
        CategoryDetails categoryDetails = categoryDetailsList.get(position);
        Glide.with(mContext).load(categoryDetails.getPictureUrl()).into(holder.categoryIcon);
        holder.categoryType.setText(categoryDetails.getCategory());

    }

    @Override
    public int getItemCount() {
        return categoryDetailsList.size();
    }

    public class CustomHolder extends RecyclerView.ViewHolder {
        private ImageView categoryIcon;
        private TextView categoryType;

        public CustomHolder(View itemView) {
            super(itemView);
            categoryIcon = (ImageView) itemView.findViewById(R.id.iv_category);
            categoryType = (TextView) itemView.findViewById(R.id.tv_category_type);
        }
    }
}
