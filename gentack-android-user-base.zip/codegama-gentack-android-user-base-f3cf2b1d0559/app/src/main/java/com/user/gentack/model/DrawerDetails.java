package com.user.gentack.model;

/**
 * Created by user on 2/9/2017.
 */

public class DrawerDetails
{
    private int imageRes;
    private String title;

    public DrawerDetails(int imageRes, String title) {
        this.imageRes = imageRes;
        this.title = title;
    }

    public int getImageRes() {

        return imageRes;
    }

    public void setImageRes(int imageRes) {
        this.imageRes = imageRes;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }
}
