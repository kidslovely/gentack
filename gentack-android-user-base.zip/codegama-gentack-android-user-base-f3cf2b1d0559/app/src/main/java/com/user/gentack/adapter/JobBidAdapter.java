package com.user.gentack.adapter;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.aurelhubert.simpleratingbar.SimpleRatingBar;
import com.bumptech.glide.Glide;
import com.user.gentack.R;
import com.user.gentack.activity.ChatActivity;
import com.user.gentack.activity.DetailProfileActivity;
import com.user.gentack.model.ProviderRating;
import com.user.gentack.utils.Const;

import java.util.List;

/**
 * Created by user on 4/8/2017.
 */

public class JobBidAdapter extends RecyclerView.Adapter<JobBidAdapter.CustomViewHolder> {


    private Context mContext;
    private List<ProviderRating> requestDetailsList;

    public JobBidAdapter(Context context, List<ProviderRating> requestDetailsList) {
        mContext = context;
        this.requestDetailsList = requestDetailsList;
    }

    @Override
    public CustomViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(mContext).inflate(R.layout.adapter_bid_amount_layout, null);

        return new CustomViewHolder(view);
    }

    @Override
    public void onBindViewHolder(CustomViewHolder holder, int position) {
        final ProviderRating requestDetails = requestDetailsList.get(position);
        if (requestDetails.getUserPicture() != null && !requestDetails.getUserPicture().equals("")) {
            Glide.with(mContext).load(requestDetails.getUserPicture()).into(holder.providerIcon);
        } else {
            holder.providerIcon.setImageResource(R.drawable.default_user);
        }
//        holder.jobService.setText(requestDetails.getServiceType());


        holder.providerName.setText(requestDetails.getUserName());
        holder.bidAmount.setText("Bid Amount:" + " $" + requestDetails.getBidAmount());
        holder.providerIcon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(mContext, DetailProfileActivity.class);
                intent.putExtra(Const.Params.PROVIDER_ID, requestDetails.getProviderId());
                mContext.startActivity(intent);
            }
        });

        holder.cardView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Bundle bundle = new Bundle();
                bundle.putString(Const.Params.REQUEST_ID, requestDetails.getRequestId());
                bundle.putString(Const.Params.PROVIDER_ID, requestDetails.getProviderId());
                bundle.putString(Const.Params.NAME, requestDetails.getUserName());
                bundle.putString(Const.Params.REQUEST_META_ID, requestDetails.getRequestMetaId());
                bundle.putString(Const.Params.BID_STATUS, requestDetails.getBidStatus());
                Intent intent = new Intent(mContext, ChatActivity.class);
                intent.putExtras(bundle);
                mContext.startActivity(intent);
            }
        });

        try {

            if (requestDetails.getRating().equals("0")) {
                holder.ratingBar.setRating(0);
            } else {
                holder.ratingBar.setRating(Integer.parseInt(String.valueOf((requestDetails.getRating().charAt(0)))));
            }


        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    @Override
    public int getItemCount() {
        return requestDetailsList.size();
    }

    public class CustomViewHolder extends RecyclerView.ViewHolder {
        private ImageView providerIcon;
        private TextView jobService, providerName, bidAmount, jobDesc;
        private SimpleRatingBar ratingBar;
        private CardView cardView;

        public CustomViewHolder(View itemView) {
            super(itemView);
            cardView = (CardView) itemView.findViewById(R.id.cardView);
            providerIcon = (ImageView) itemView.findViewById(R.id.iv_bidding);
            jobService = (TextView) itemView.findViewById(R.id.tv_bid_service);
            providerName = (TextView) itemView.findViewById(R.id.tv_bid_name);
            bidAmount = (TextView) itemView.findViewById(R.id.tv_bid_charge);
            ratingBar = (SimpleRatingBar) itemView.findViewById(R.id.bid_rating);


        }
    }
}