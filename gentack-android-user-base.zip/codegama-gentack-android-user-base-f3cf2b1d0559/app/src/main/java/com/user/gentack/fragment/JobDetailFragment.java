package com.user.gentack.fragment;

import android.app.DatePickerDialog;
import android.app.Dialog;
import android.app.TimePickerDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.Nullable;
import android.support.design.widget.TextInputLayout;
import android.support.v4.app.DialogFragment;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.TimePicker;

import com.user.gentack.utils.GPSTracker;
import com.google.android.gms.maps.model.LatLng;
import com.user.gentack.R;
import com.user.gentack.activity.AddCardActivity;
import com.user.gentack.activity.MainActivity;
import com.user.gentack.adapter.GetCardsAdapter;
import com.user.gentack.adapter.SearchPlaceAdapter;
import com.user.gentack.custom_interface.AsyncTaskCompleteListener;
import com.user.gentack.model.BiddingRequestDetails;
import com.user.gentack.model.CardDetails;
import com.user.gentack.model.CategoryDetails;
import com.user.gentack.model.RequestDetails;
import com.user.gentack.networking.HttpRequester;
import com.user.gentack.utils.AndyUtils;
import com.user.gentack.utils.Const;
import com.user.gentack.utils.ParseContent;
import com.user.gentack.utils.PreferenceHelper;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;

/**
 * Created by user on 3/11/2017.
 */

public class JobDetailFragment extends Fragment implements View.OnClickListener, AsyncTaskCompleteListener {
    public static int currentDay, selectedDay, currentMonth, selectedMonth;
    private static EditText dateEdit, timeEdit;
    private static String selectedTime = "", selectedDate = "", reuestDateTime = "";
    private static SimpleDateFormat dateFormatter = new SimpleDateFormat("yyyy-mm-dd HH:mm:ss", Locale.ENGLISH);
    private static BiddingRequestDetails biddingRequestDetails;

    private EditText taskLocationEdit, jobTitleEdit, descriptionEdit, whenEdit, noteEdit;
    private String sTaskLocation = "", sJobTitle = "", sDate = "", sTime = "", sDescription = "", sNote = "";
    private Button requestButton;
    private CategoryDetails subCategoryDetails;
    private Bundle bundle;
    private MainActivity activity;
    private ListView searchListView;
    private LatLng searchLatLng;
    private ArrayList<String> resultList;
    private SearchPlaceAdapter searchAdapter;
    private String currentAddress = "";
    private TextInputLayout dateLayout, timeLayout;
    private String jobType = "", tempRequestId = "", categoryId = "";
    private Dialog waitingDialog, paymentDialog;
    private String paymentType = "";
    private List<CardDetails> cardDetailsList;
    private Handler reqhandler;

    Runnable runnable = new Runnable() {
        public void run() {
            getIncomingRequestsInProgress();
            reqhandler.postDelayed(this, 4000);
        }
    };

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        activity = (MainActivity) getActivity();
        reqhandler = new Handler();
        bundle = getArguments();
        if (bundle != null) {
            subCategoryDetails = (CategoryDetails) bundle.getSerializable(Const.Params.SUB_CATEGORY_FRAGMENT);
            categoryId = bundle.getString(Const.Params.CATEGORY_ID);
            activity.headerText.setText(subCategoryDetails.getCategory());
        }
        biddingRequestDetails = new BiddingRequestDetails();
        biddingRequestDetails.setPrice(subCategoryDetails.getPrice());
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_job_details_layout, container, false);
        taskLocationEdit = (EditText) view.findViewById(R.id.input_task_location);
        jobTitleEdit = (EditText) view.findViewById(R.id.input_jobTitle);
        dateEdit = (EditText) view.findViewById(R.id.input_date);
        whenEdit = (EditText) view.findViewById(R.id.input_when);
        timeEdit = (EditText) view.findViewById(R.id.input_time);
        dateLayout = (TextInputLayout) view.findViewById(R.id.input_layout_date);
        timeLayout = (TextInputLayout) view.findViewById(R.id.input_layout_time);
        descriptionEdit = (EditText) view.findViewById(R.id.input_description);
        noteEdit = (EditText) view.findViewById(R.id.input_note);
        requestButton = (Button) view.findViewById(R.id.bn_request);
        requestButton.setOnClickListener(this);
        dateEdit.setOnClickListener(this);
        timeEdit.setOnClickListener(this);
        taskLocationEdit.setOnClickListener(this);
        whenEdit.setOnClickListener(this);

        return view;
    }


    public void getIncomingRequestsInProgress() {
        if (!AndyUtils.isNetworkAvailable(activity)) {

            return;
        }
        HashMap<String, String> map = new HashMap<String, String>();
        map.put(Const.Params.URL, Const.ServiceType.POST_REQUEST_STATUS_CHECK_NOW_URL);
        map.put(Const.Params.ID, PreferenceHelper.getInstance().getUserId());
        map.put(Const.Params.TOKEN, PreferenceHelper.getInstance().getSessionToken());

        new HttpRequester(activity, Const.POST, map, Const.ServiceCode.POST_REQUEST_STATUS_CHECK_NOW, this);

    }

    private void getTempRequestId(String jobType) {
        HashMap<String, String> map = new HashMap<>();
        map.put(Const.Params.URL, Const.ServiceType.POST_DRAFTS_REQUEST_URL);
        map.put(Const.Params.ID, PreferenceHelper.getInstance().getUserId());
        map.put(Const.Params.TOKEN, PreferenceHelper.getInstance().getSessionToken());
        map.put(Const.Params.JOB_TYPE, String.valueOf(jobType));
        map.put(Const.Params.SUB_CATEGORY_ID, subCategoryDetails.getCategoryId());
        map.put(Const.Params.REQUEST_TYPE, "");
        map.put(Const.Params.CATEGORY_ID, categoryId);

        AndyUtils.appLog("Ashutosh", "DraftsMap" + map);

        new HttpRequester(activity, Const.POST, map, Const.ServiceCode.POST_DRAFTS_REQUEST, this);
    }

    private void startCheckingUpcomingRequests() {
        startCheckRegTimer();
    }

    public void startCheckRegTimer() {
        reqhandler.postDelayed(runnable, 6000);
    }


    private void stopCheckingUpcomingRequests() {
        if (reqhandler != null) {
            reqhandler.removeCallbacks(runnable);

            Log.d("mahi", "stop handler");
        }
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.input_date:
                SelectDateFragment dateFragment = new SelectDateFragment();
                dateFragment.show(getChildFragmentManager(), "date_fragment");
                break;
            case R.id.input_time:
                SelectTimeFragment timeFragment = new SelectTimeFragment();
                timeFragment.show(getChildFragmentManager(), "time_fragment");
                break;
            case R.id.bn_request:
                getJobDetails();
                if(isValidateData()) {
                    getAddedCard();
                }
                break;
            case R.id.input_task_location:
                showDistanceDialog();
                break;
            case R.id.input_when:
                showJobChooseDialog();
                break;
        }
    }


    private void getAddedCard() {
        if (!AndyUtils.isNetworkAvailable(activity)) {
            AndyUtils.showLongToast(getString(R.string.no_internet), activity);
            return;
        }
        AndyUtils.showSimpleProgressDialog(activity, getString(R.string.please_wait), false);
        HashMap<String, String> map = new HashMap<>();
        map.put(Const.Params.URL, Const.ServiceType.GET_ADDED_CARDS_URL);
        map.put(Const.Params.ID, PreferenceHelper.getInstance().getUserId());
        map.put(Const.Params.TOKEN, PreferenceHelper.getInstance().getSessionToken());

        AndyUtils.appLog("Ashutosh", "GetAddedCardMap" + map);

        new HttpRequester(activity, Const.POST, map, Const.ServiceCode.GET_ADDED_CARDS, this);


    }

    private void paymentModeUpdate(String pType) {
        if (!AndyUtils.isNetworkAvailable(activity)) {
            AndyUtils.showLongToast(getString(R.string.no_internet), activity);
            return;
        }
        AndyUtils.showSimpleProgressDialog(activity, getString(R.string.please_wait), false);
        HashMap<String, String> map = new HashMap<>();
        map.put(Const.Params.URL, Const.ServiceType.POST_PAYMENT_MODE_UPDATE_URL);
        map.put(Const.Params.ID, PreferenceHelper.getInstance().getUserId());
        map.put(Const.Params.TOKEN, PreferenceHelper.getInstance().getSessionToken());
        map.put(Const.Params.PAYMENT_MODE, pType);

        AndyUtils.appLog("Ashutosh", "PaymentModeMap" + map);

        new HttpRequester(activity, Const.POST, map, Const.ServiceCode.POST_PAYMENT_MODE_UPDATE, this);


    }

    private void getJobDetails() {
        sTaskLocation = taskLocationEdit.getText().toString();
        sJobTitle = jobTitleEdit.getText().toString();
        sDate = dateEdit.getText().toString();
        sTime = timeEdit.getText().toString();
        sDescription = descriptionEdit.getText().toString();
        sNote = noteEdit.getText().toString();
        biddingRequestDetails.setAddress(sTaskLocation);
        biddingRequestDetails.setJobTitle(sJobTitle);
        biddingRequestDetails.setDescription(sDescription);
        biddingRequestDetails.setNote(sNote);
    }

    private void createJobRequestNow() {
        if (!AndyUtils.isNetworkAvailable(activity)) {
            AndyUtils.showShortToast(getString(R.string.no_internet), activity);
            return;
        }
        showWaitingDialog();
        HashMap<String, String> map = new HashMap<>();
        map.put(Const.Params.URL, Const.ServiceType.POST_REQUEST_NOW_URL);
        map.put(Const.Params.ID, PreferenceHelper.getInstance().getUserId());
        map.put(Const.Params.TOKEN, PreferenceHelper.getInstance().getSessionToken());
        map.put(Const.Params.S_ADDRESS, currentAddress);
        map.put(Const.Params.S_LATITUDE, String.valueOf(searchLatLng.latitude));
        map.put(Const.Params.S_LONGITUDE, String.valueOf(searchLatLng.longitude));
        map.put(Const.Params.NAME, sJobTitle);
        map.put(Const.Params.DESCRIPTION, sDescription);
        map.put(Const.Params.NOTE, sNote);
        map.put(Const.Params.USER_PRICE, subCategoryDetails.getPrice());
        map.put(Const.Params.TEMP_REQUEST_ID, tempRequestId);

        AndyUtils.appLog("Ashutosh", "JobRequestMap" + map);

        new HttpRequester(activity, Const.POST, map, Const.ServiceCode.POST_REQUEST_NOW, this);

    }


    private void showWaitingDialog() {
        waitingDialog = new Dialog(activity, R.style.DialogThemeforview);
        waitingDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        waitingDialog.setContentView(R.layout.dialog_waiting_screen);

        Button cancelButton = (Button) waitingDialog.findViewById(R.id.bn_waiting_cancel);
        cancelButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                cancelRequest();
            }
        });

        waitingDialog.setCancelable(false);
        waitingDialog.show();
    }

    private void cancelRequest() {
        if (!AndyUtils.isNetworkAvailable(activity)) {

            return;
        }

        AndyUtils.showSimpleProgressDialog(activity, getString(R.string.please_wait), false);
        HashMap<String, String> map = new HashMap<String, String>();
        map.put(Const.Params.URL, Const.ServiceType.POST_WAITING_REQUEST_CANCEL_URL);
        map.put(Const.Params.ID, PreferenceHelper.getInstance().getUserId());
        map.put(Const.Params.TOKEN, PreferenceHelper.getInstance().getSessionToken());
        new HttpRequester(activity, Const.POST, map, Const.ServiceCode.POST_WAITING_REQUEST_CANCEL, this);
    }


    private void saveDraftRequest() {
        HashMap<String, String> map = new HashMap<>();
        map.put(Const.Params.URL, Const.ServiceType.POST_DRAFTS_REQUEST_URL);
        map.put(Const.Params.ID, PreferenceHelper.getInstance().getUserId());
        map.put(Const.Params.TOKEN, PreferenceHelper.getInstance().getSessionToken());
        map.put(Const.Params.JOB_TYPE, String.valueOf("1"));
        map.put(Const.Params.SUB_CATEGORY_ID, subCategoryDetails.getCategoryId());
        map.put(Const.Params.REQUEST_TYPE, "");
        map.put(Const.Params.CATEGORY_ID, categoryId);
        map.put(Const.Params.S_ADDRESS, currentAddress);
        map.put(Const.Params.S_LATITUDE, String.valueOf(searchLatLng.latitude));
        map.put(Const.Params.S_LONGITUDE, String.valueOf(searchLatLng.longitude));
        map.put(Const.Params.NAME, sJobTitle);
        map.put(Const.Params.DESCRIPTION, sDescription);
        map.put(Const.Params.NOTE, sNote);
        map.put(Const.Params.USER_PRICE, subCategoryDetails.getPrice());
        map.put(Const.Params.TEMP_REQUEST_ID, tempRequestId);
        AndyUtils.appLog("Ashutosh", "DraftsMap" + map);

        new HttpRequester(activity, Const.POST, map, Const.ServiceCode.POST_DRAFTS_REQUEST, this);
    }


    private boolean isValidateData() {
        if (sTaskLocation.equals("")) {
            AndyUtils.showShortToast("Please enter location", activity);
            return false;
        } else if (sJobTitle.equals("")) {
            AndyUtils.showShortToast("Please enter job title", activity);
            return false;
        } else if (jobType.equals("")) {
            AndyUtils.showShortToast("Please select when you want the task", activity);
            return false;
        } else if (jobType.equals("later") && (sDate.length() <= 0 || sDate.equals(""))) {
            AndyUtils.showShortToast("Please select the Date", activity);
            return false;
        }
        else if (jobType.equals("later") && (sTime.length() <= 0 || sTime.equals(""))) {
            AndyUtils.showShortToast("Please select the Time", activity);
            return false;
        } else if (sDescription.equals("")) {
            AndyUtils.showShortToast("Please enter description", activity);
            return false;
        } else {
            return true;
        }
    }

    private void showJobChooseDialog() {
        final Dialog dialog = new Dialog(activity, R.style.DialogTheme);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.dialog_choose_job_layout);
        final CheckBox nowRadio = (CheckBox) dialog.findViewById(R.id.rb_now);
        final CheckBox laterRadio = (CheckBox) dialog.findViewById(R.id.rb_later);
        TextView now = (TextView) dialog.findViewById(R.id.tv_now);
        TextView later = (TextView) dialog.findViewById(R.id.tv_later);

        now.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                nowRadio.setChecked(true);
                whenEdit.setText("Now");
                jobType = "now";
                dateLayout.setVisibility(View.GONE);
                timeLayout.setVisibility(View.GONE);
                getTempRequestId("1");
                dialog.cancel();
            }
        });
        later.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                laterRadio.setChecked(true);
                whenEdit.setText("Later");
                jobType = "later";
                getTempRequestId("2");
                dateLayout.setVisibility(View.VISIBLE);
                timeLayout.setVisibility(View.VISIBLE);
                dialog.cancel();
            }
        });

        dialog.show();
    }

    @Override
    public void onResume() {
        super.onResume();
        activity.currentFragment = Const.Params.JOB_DETAIL_FRAGMENT;
    }

    private void showDistanceDialog() {
        final Dialog dialog = new Dialog(activity, R.style.DialogThemeforview);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.dialog_distance_search);
        ImageView backButton = (ImageView) dialog.findViewById(R.id.iv_back);
        TextView current_location = (TextView) dialog.findViewById(R.id.current_location);
        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dialog.cancel();
                searchAdapter = null;
            }
        });
        current_location.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                GPSTracker tracker = new GPSTracker(activity);
                if (tracker.isCanGetLocation()){
                    double latitude = tracker.getLatitude();
                    double longitude = tracker.getLongitude();
                    searchLatLng = new LatLng(latitude, longitude);
                    currentAddress = AndyUtils.getCompleteAddressString(latitude, longitude, activity);
                    currentAddress = currentAddress.substring(0, currentAddress.lastIndexOf(","));
                    taskLocationEdit.setText(currentAddress);
                    searchAdapter = null;
                    dialog.cancel();
                    biddingRequestDetails.setLatitude(latitude);
                    biddingRequestDetails.setLongitude(longitude);
                }
                else {
                    tracker.showSettingsAlert();
                }
            }
        });
        final EditText autoCompleteTextView = (EditText) dialog.findViewById(R.id.auto_search);
        searchListView = (ListView) dialog.findViewById(R.id.lv_search);
        resultList = new ArrayList<>();

        autoCompleteTextView.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                String text = autoCompleteTextView.getText().toString().toLowerCase(Locale.getDefault());
                getRunnableAddress(text);
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
        searchListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> arg0, View arg1, int arg2,
                                    long arg3) {
                currentAddress = (String) searchAdapter.getItem(arg2);
                autoCompleteTextView.setSelection(0);
                Handler handler = new Handler();
                handler.post(new Runnable() {
                    @Override
                    public void run() {
                        searchLatLng = AndyUtils.getLatLngFromAddress(currentAddress, activity);
                        if (searchLatLng != null) {
                            taskLocationEdit.setText(currentAddress);
                            searchAdapter = null;
                            dialog.cancel();
                            biddingRequestDetails.setLatitude(searchLatLng.latitude);
                            biddingRequestDetails.setLongitude(searchLatLng.longitude);
                        } else {
                            AndyUtils.showShortToast("Please choose once again address", activity);
                        }

                    }
                });
            }
        });
        dialog.show();
    }


    private void getRunnableAddress(final String text) {
        Handler handler = null;
        Runnable run = new Runnable() {
            @Override
            public void run() {
                getAddress(text);
            }
        };

        // only canceling the network calls will not help, you need to remove all callbacks as well
        // otherwise the pending callbacks and messages will again invoke the handler and will send the request
        if (handler != null) {
            handler.removeCallbacksAndMessages(null);
        } else {
            handler = new Handler();
        }
        handler.postDelayed(run, 1000);
    }

    private void getAddress(String text) {
        HashMap<String, String> map = new HashMap<>();
        map.put(Const.Params.URL, AndyUtils.getPlaceAutoCompleteUrl(text));
        AndyUtils.appLog("Ashutosh", "AddressMap" + map);
        new HttpRequester(activity, Const.GET, map, 205, this);
    }

    @Override
    public void onTaskCompleted(String response, int serviceCode) {

        switch (serviceCode) {
            case 205:

                AndyUtils.appLog("Ashutosh", "GetAddress" + response);

                try {
                    JSONObject jsonObj = new JSONObject(response);
                    JSONArray predsJsonArray = jsonObj.getJSONArray("predictions");

                    // Extract the Place descriptions from the results
                    if (predsJsonArray.length() > 0) {
                        resultList.clear();
                        for (int i = 0; i < predsJsonArray.length(); i++) {
                            resultList.add(predsJsonArray.getJSONObject(i).getString(
                                    "description"));
                        }
                    } else {
                        resultList.clear();
                    }
                    if (searchAdapter == null) {
                        searchAdapter = new SearchPlaceAdapter(activity, resultList);
                        searchListView.setAdapter(searchAdapter);
                    } else {
                        searchAdapter.notifyDataSetChanged();
                    }

                } catch (JSONException e) {
                    Log.e("", "Cannot process JSON results", e);
                }

                break;
            case Const.ServiceCode.POST_DRAFTS_REQUEST:
                AndyUtils.appLog("Ashutosh", "DraftResponse" + response);
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    if (jsonObject.optString(Const.SUCCESS).equals("true")) {
                        JSONObject dataObject = jsonObject.optJSONObject("data");
                        tempRequestId = dataObject.optString(Const.Params.TEMP_REQUEST_ID);
                        PreferenceHelper.getInstance().putRegisterationID(tempRequestId);
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                break;
            case Const.ServiceCode.POST_REQUEST_NOW:
                AndyUtils.appLog("Ashutosh", "PostRequestNowresponse" + response);
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    if (jsonObject.optString(Const.SUCCESS).equals("true")) {
                        startCheckingUpcomingRequests();
                    } else if (jsonObject.optString(Const.SUCCESS).equals("false")) {
                        AndyUtils.showShortToast(jsonObject.optString("error"), activity);
                        if (waitingDialog != null && waitingDialog.isShowing()) {
                            waitingDialog.cancel();
                        }
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                break;

            case Const.ServiceCode.POST_REQUEST_STATUS_CHECK_NOW:
                AndyUtils.appLog("Ashutosh", "IncomingRequestResponse" + response);
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    if (jsonObject.optString(Const.SUCCESS).equals("true")) {
                        RequestDetails requestDetails = ParseContent.getInstance().parsingRequestInProgress(response);
                        if (requestDetails != null && requestDetails.getProviderStatus().equals("2")) {
                            if (waitingDialog != null && waitingDialog.isShowing()) {
                                waitingDialog.cancel();
                            }
                            Bundle bundle = new Bundle();
                            bundle.putSerializable(Const.REQUEST_BUNDLE_DETAIL, requestDetails);
                            JobMapFragment jobMapFragment = new JobMapFragment();
                            jobMapFragment.setArguments(bundle);
                            PreferenceHelper.getInstance().putRequestId(Integer.parseInt(requestDetails.getRequestId()));
                            activity.addFragment(jobMapFragment, false, "", "");
                            stopCheckingUpcomingRequests();

                        } else if (requestDetails == null) {
                            PreferenceHelper.getInstance().putRequestId(Const.NO_REQUEST);
                            stopCheckingUpcomingRequests();
                            AndyUtils.showLongToast("Request rejected by provider", activity);
                            if (waitingDialog != null && waitingDialog.isShowing()) {
                                waitingDialog.cancel();
                            }
                            activity.headerText.setText("Category");
                            activity.addFragment(new CategoryFragment(), false, "", "");
                        }
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                break;
            case Const.ServiceCode.POST_WAITING_REQUEST_CANCEL:
                AndyUtils.removeProgressDialog();
                AndyUtils.appLog("Ashutosh", "WaitingCancelresponse" + response);
                try {
                    PreferenceHelper.getInstance().putRequestId(Const.NO_REQUEST);
                    JSONObject jsonObject = new JSONObject(response);
                    if (jsonObject.optString(Const.SUCCESS).equals("true")) {
                        if (waitingDialog != null && waitingDialog.isShowing()) {
                            waitingDialog.cancel();
                        }
                        activity.headerText.setText("Category");
                        activity.addFragment(new CategoryFragment(), false, "", "");
                        AndyUtils.showShortToast(jsonObject.optString("message"), activity);
                        stopCheckingUpcomingRequests();
                    } else {
                        if (waitingDialog != null && waitingDialog.isShowing()) {
                            waitingDialog.cancel();
                        }
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }

                break;
            case Const.ServiceCode.GET_ADDED_CARDS:
                AndyUtils.removeProgressDialog();
                AndyUtils.appLog("Ashutosh", "GetAddedCardResponse" + response);
                try {
                    cardDetailsList = new ArrayList<>();
                    JSONObject jsonObject = new JSONObject(response);
                    if (jsonObject.getString("success").equals("true")) {
                        JSONArray jsonArray = jsonObject.optJSONArray("card");
                        if (jsonArray != null && jsonArray.length() > 0) {

                            for (int i = 0; i < jsonArray.length(); i++) {
                                JSONObject cardObject = jsonArray.getJSONObject(i);
                                CardDetails cardDetails = new CardDetails();
                                cardDetails.setCardId(cardObject.optString("id"));
                                cardDetails.setCardNumber(cardObject.optString("last_four"));
                                cardDetails.setIsDefault(cardObject.optString("is_default"));
                                cardDetails.setType(cardObject.optString("card_type"));
                                cardDetails.setCustomerId(cardObject.optString("customer_id"));
                                cardDetailsList.add(cardDetails);
                            }
                            showPaymentDialog(cardDetailsList);
                        } else {
                            showPaymentDialog(cardDetailsList);
                        }
                    } else {
                        showPaymentDialog(cardDetailsList);
                    }


                } catch (JSONException e) {
                    e.printStackTrace();
                }
                break;
            case Const.ServiceCode.POST_PAYMENT_MODE_UPDATE:
                AndyUtils.removeProgressDialog();
                AndyUtils.appLog("Ashutosh", "PaymentModeResponse" + response);
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    if (jsonObject.optString(Const.SUCCESS).equals("true")) {
                        if (jobType.equals("now")) {
                            saveDraftRequest();
                            createJobRequestNow();

                        } else if (jobType.equals("later")) {
//                            saveDraftRequest();
                            Bundle bundle = new Bundle();
                            biddingRequestDetails.setSubCategoryId(subCategoryDetails.getCategoryId());
                            biddingRequestDetails.setCategoryId(categoryId);
                            bundle.putSerializable(Const.REQUEST_BUNDLE_DETAIL, biddingRequestDetails);
                            LaterBiddingFragment biddingFragment = new LaterBiddingFragment();
                            biddingFragment.setArguments(bundle);
                            activity.addFragment(biddingFragment, false, "", "");
                        }
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                break;
        }

    }

    private void showPaymentDialog(final List<CardDetails> cardList) {
        paymentType = "";
        paymentDialog = new Dialog(getActivity(), R.style.DialogDocotrTheme);
        paymentDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        paymentDialog.setContentView(R.layout.dialog_payment_mode_layout);
        final RecyclerView paymentRecyclerView = (RecyclerView) paymentDialog.findViewById(R.id.rv_card_details);
        paymentRecyclerView.setVisibility(View.GONE);
        final LinearLayout paymentLinearLayout = (LinearLayout) paymentDialog.findViewById(R.id.ll_no_card_added);
        paymentLinearLayout.setVisibility(View.GONE);
        final Button addCardButton = (Button) paymentDialog.findViewById(R.id.bn_payment_add_card);
        addCardButton.setVisibility(View.GONE);
        final ImageButton cashButton = (ImageButton) paymentDialog.findViewById(R.id.ib_payment_cash);
        final ImageButton cardButton = (ImageButton) paymentDialog.findViewById(R.id.ib_payment_card);
        final Button paymentButton = (Button) paymentDialog.findViewById(R.id.bn_payment_confirm);
        paymentDialog.show();

        paymentButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (paymentType.equals("")) {
                    AndyUtils.showShortToast(getString(R.string.please_choose_payment_mode), getActivity());
                } else {
                    paymentDialog.cancel();
                    paymentModeUpdate(paymentType);
                }
            }
        });
        cardButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                paymentType = Const.CARD;
                cardButton.setBackgroundDrawable(getResources().getDrawable(R.drawable.doctor_booked_bg));
                cashButton.setBackgroundDrawable(getResources().getDrawable(R.drawable.doctor_available_bg));
                LinearLayoutManager layoutManager = new LinearLayoutManager(getActivity());
                paymentRecyclerView.setLayoutManager(layoutManager);

                if (cardList.size() > 0) {
                    paymentRecyclerView.setVisibility(View.VISIBLE);
                    GetCardsAdapter adapter = new GetCardsAdapter(getActivity(), cardList);
                    paymentRecyclerView.setAdapter(adapter);
                } else {
                    paymentRecyclerView.setVisibility(View.GONE);
                    paymentLinearLayout.setVisibility(View.VISIBLE);
                    addCardButton.setVisibility(View.VISIBLE);
                    addCardButton.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            Intent intent = new Intent(getActivity(), AddCardActivity.class);
                            startActivity(intent);
                            paymentDialog.cancel();
                        }
                    });
                    paymentButton.setEnabled(false);
                    paymentButton.setBackgroundDrawable(getResources().getDrawable(R.drawable.disable_book_consult_bg));

                }

            }
        });
        cashButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                paymentType = Const.CASH;
                paymentRecyclerView.setVisibility(View.GONE);
                cardButton.setBackgroundDrawable(getResources().getDrawable(R.drawable.doctor_available_bg));
                cashButton.setBackgroundDrawable(getResources().getDrawable(R.drawable.doctor_booked_bg));
                paymentLinearLayout.setVisibility(View.GONE);
                addCardButton.setVisibility(View.GONE);
                paymentButton.setEnabled(true);
                paymentButton.setBackgroundDrawable(getResources().getDrawable(R.drawable.book_consult_bg));
            }
        });

    }

    public static class SelectDateFragment extends DialogFragment implements DatePickerDialog.OnDateSetListener {

        private DatePickerDialog pickerDialog;

        public Dialog onCreateDialog(Bundle savedInstanceState) {
            final Calendar calendar = Calendar.getInstance();
            final int yy = calendar.get(Calendar.YEAR);
            final int mm = calendar.get(Calendar.MONTH);
            final int dd = calendar.get(Calendar.DAY_OF_MONTH);

            currentDay = dd;
            currentMonth = mm;

            pickerDialog = new DatePickerDialog(getActivity(), R.style.DialogTheme, this, yy, mm, dd);
            pickerDialog.getDatePicker().setMinDate(calendar.getTimeInMillis());

            pickerDialog.setButton(DialogInterface.BUTTON_POSITIVE, "OK", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    if (which == DialogInterface.BUTTON_POSITIVE) {

                        selectedDay = pickerDialog.getDatePicker().getDayOfMonth();
                        selectedMonth = pickerDialog.getDatePicker().getMonth() + 1;
                        if (pickerDialog.getDatePicker().getMonth() < 9) {
                            selectedDate = pickerDialog.getDatePicker().getDayOfMonth() + "-" + "0" + selectedMonth + "-" + pickerDialog.getDatePicker().getYear();
                        } else {
                            selectedDate = pickerDialog.getDatePicker().getDayOfMonth() + "-" + selectedMonth + "-" + pickerDialog.getDatePicker().getYear();
                        }

                        dateEdit.setText(selectedDate);
                        AndyUtils.appLog("OnClick  Date", selectedDate);

                        // TODO Auto-generated method stub
                    }
                }
            });
            return pickerDialog;
        }

        @Override
        public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
            AndyUtils.appLog("CarSelectionFragment", "OnDateSet");
        }

    }

    public static class SelectTimeFragment extends DialogFragment implements TimePickerDialog.OnTimeSetListener {


        Calendar mCurrentTime;
        private TimePickerDialog timePickerDialog;
        private int minHour = -1, minMinute = -1, maxHour = 100, maxMinute = 100;
        private int currentHour, currentMinute;

        public Dialog onCreateDialog(Bundle savedInstanceState) {
            mCurrentTime = Calendar.getInstance();
            currentHour = mCurrentTime.get(Calendar.HOUR_OF_DAY);
            currentMinute = mCurrentTime.get(Calendar.MINUTE);

            timePickerDialog = new TimePickerDialog(getActivity(), R.style.DialogTheme, this, currentHour, currentMinute, false);

            return timePickerDialog;
        }


        @Override
        public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
            SimpleDateFormat sdf1 = new SimpleDateFormat("HH:mm:ss", Locale.ENGLISH);
            SimpleDateFormat sdf = new SimpleDateFormat("hh:mm a", Locale.ENGLISH);
            Calendar calendar = Calendar.getInstance();
            calendar.set(Calendar.HOUR_OF_DAY, hourOfDay);
            calendar.set(Calendar.MINUTE, minute);
            selectedTime = sdf.format(calendar.getTime());
            String selectTime = sdf1.format(calendar.getTime());

            Log.d("SELECTED TIME", selectTime);
            if (selectedDay > currentDay || selectedMonth > currentMonth) {

                reuestDateTime = selectedDate + " " + selectTime;
                timeEdit.setText(selectedTime);
                AndyUtils.appLog("ReuestedDtaetTime", reuestDateTime);
                biddingRequestDetails.setRequestDateTime(reuestDateTime);

            } else if (mCurrentTime.get(Calendar.HOUR_OF_DAY) == hourOfDay && minute > mCurrentTime.get(Calendar.MINUTE)) {
                reuestDateTime = selectedDate + " " + selectTime;
                timeEdit.setText(selectedTime);
                AndyUtils.appLog("ReuestedDtaetTime", reuestDateTime);
                biddingRequestDetails.setRequestDateTime(reuestDateTime);
            } else if (hourOfDay > mCurrentTime.get(Calendar.HOUR_OF_DAY)) {
                reuestDateTime = selectedDate + " " + selectTime;
                timeEdit.setText(selectedTime);
                AndyUtils.appLog("ReuestedDtaetTime", reuestDateTime);
                biddingRequestDetails.setRequestDateTime(reuestDateTime);
            } else {
                AndyUtils.showShortToast("Please select the later time", getActivity());
                return;
            }


        }

    }


}
