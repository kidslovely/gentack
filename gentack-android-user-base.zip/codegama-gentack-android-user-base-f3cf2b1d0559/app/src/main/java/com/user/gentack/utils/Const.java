package com.user.gentack.utils;

/**
 * Created by user on 2/28/2017.
 */

public class Const {


    public static final String PLACES_AUTOCOMPLETE_API_KEY = "AIzaSyAqlXdrsrvF11YEHMwBAsixEDFt4LYzaHw";
    public static final String PLACES_API_BASE = "https://maps.googleapis.com/maps/api/place";


    public static final String PREF_NAME = "JobRabbit_User";
    public static final String ANDROID = "android";
    public static final String MANUAL = "manual";
    public static final String FACEBOOK = "facebook";
    public static final String GOOGLE = "google";
    public static final String SUCCESS = "success";
    public static final String TRUE = "true";
    public static final String TYPE_AUTOCOMPLETE = "/autocomplete";
    public static final String TYPE_NEAR_BY = "/nearbysearch";
    public static final String OUT_JSON = "/json";
    public static final String FIRST_TIME = "first_time";
    public static final String PARKING_TYPE = "parking_type";
    public static final int TIMEOUT = 20000;
    public static final int MAX_RETRY = 3;
    public static final float DEFAULT_BACKOFF_MULT = 1f;
    public static final int CHOOSE_PHOTO = 151;
    public static final int TAKE_PHOTO = 152;
    public static final String ORIGIN = "origin";
    public static final String DESTINATION = "destination";
    public static final String EXTANCTION = "sensor=false&mode=driving&alternatives=true&key=AIzaSyDoujGbr86VY2F6vhh-bzZjsebCFoRn0ik";
    public static final String CARD = "card";
    public static final String CASH = "cod";
    public static int GET = 0;
    public static int POST = 1;
    public static int NO_REQUEST = -1;
    public static String REQUEST_BUNDLE_DETAIL = "request_bundle_detail";
    public static String POSTED = "posted";
    public static String ONGOING = "ongoing";
    public static String CONFIRMED = "confirmed";

    public class Params {

        public static final String CATEGORY_FRAGMENT = "category_fragment";
        public static final String SUB_CATEGORY_FRAGMENT = "sub_category_fragment";
        public static final String PICTURE = "picture";
        public static final String URL = "url";
        public static final String SINGIN_SIGNUP = "signin_signup";
        public static final String LOGIN_FRAGMENT = "login_fragment";
        public static final String SIGNUP_FRAGMENT = "signup_fragment";
        public static final String JOB_DETAIL_FRAGMENT = "jobdetail_fragment";
        public static final String JOB_MAP_FRAGMENT = "jobmap_fragment";
        public static final String DEVICE_TYPE = "device_type";
        public static final String DEVICE_TOKEN = "device_token";
        public static final String SOCIAL_UNIQUE_ID = "social_unique_id";
        public static final String LOGIN_BY = "login_by";
        public static final String EMAIL = "email";
        public static final String PASSWORD = "password";
        public static final String USER_ID = "user_id";
        public static final String TIMEZONE = "timezone";
        public static final String ID = "id";
        public static final String NAME = "name";
        public static final String MOBILE = "mobile";
        public static final String TOKEN = "token";
        public static final String GATEWAY = "gateway";
        public static final String ACCESS_TOKEN = "access_token";
        public static final String ADDRESS = "address";
        public static final String FROM = "from";
        public static final String LATITUDE = "lat";
        public static final String LIMIT = "limit";
        public static final String LONGITUDE = "long";
        public static final String CATEGORY_ID = "category_id";
        public static final String TEMP_REQUEST_ID = "temp_request_id";
        public static final String S_LATITUDE = "s_latitude";
        public static final String S_LONGITUDE = "s_longitude";
        public static final String S_ADDRESS = "s_address";
        public static final String DESCRIPTION = "description";
        public static final String NOTE = "note";
        public static final String JOB_TYPE = "job_type";
        public static final String SUB_CATEGORY_ID = "sub_category_id";
        public static final String USER_PRICE = "user_price";
        public static final String REQUEST_TYPE = "request_type";
        public static final String REQUEST_ID = "request_id";
        public static final String USER_REASON = "user_reason";
        public static final String PAYMENT_MODE = "payment_mode";
        public static final String IS_PAID = "is_paid";
        public static final String RATING = "rating";
        public static final String COMMENT = "comment";
        public static final String BID_STATUS = "biud_status";

        public static final String PAYMENT_METHOD_NONCE = "payment_method_nonce";
        public static final String LAST_FOUR = "last_four";
        public static final String CARD_TOKEN = "card_token";
        public static final String CARD_ID = "card_id";
        public static final String REQUEST_DATE = "request_date";
        public static final String PROVIDER_ID = "provider_id";
        public static final String PRICE_PER_HOUR = "price_per_hour";
        public static final String REQUEST_META_ID = "request_meta_id";
        public static final String OLD_PASSWORD = "old_password";
        public static final String PASSWORD_CONFIRMATION = "password_confirmation";


    }

    public class ServiceType {

        public static final String SOCKET_URL = "http://gentack.info:3001";
        public static final String HOST_URL = "http://gentack.info";
        public static final String BASE_URL = HOST_URL + "/api/user/";
        public static final String POST_REGISTRATION_URL = BASE_URL + "register";
        public static final String POST_LOGIN_URL = BASE_URL + "login";
        public static final String POST_SOCIAL_LOGIN_URL = BASE_URL + "login/social";
        public static final String POST_CATEGORIES_URL = HOST_URL + "/categories";
        public static final String POST_SUB_CATEGORIES_URL = HOST_URL + "/sub_categories";
        public static final String POST_DRAFTS_REQUEST_URL = BASE_URL + "request_draft";
        public static final String POST_REQUEST_NOW_URL = BASE_URL + "request_now";
        public static final String POST_REQUEST_LATER_URL = BASE_URL + "request_later";
        public static final String POST_REQUEST_STATUS_CHECK_NOW_URL = BASE_URL + "request_status_check_now";
        public static final String POST_CANCEL_REQUEST_URL = BASE_URL + "cancel_request";
        public static final String POST_WAITING_REQUEST_CANCEL_URL = BASE_URL + "waiting_request_cancel";
        public static final String POST_PAY_NOW_URL = BASE_URL + "paynow";
        public static final String GET_PROFILE_URL = BASE_URL + "profile";
        public static final String POST_UPDATE_PROFILE_URL = BASE_URL + "update_profile";
        public static final String POST_REQUEST_RATING_URL = BASE_URL + "request_rating";
        public static final String POST_HISTORY_URL = BASE_URL + "history";
        public static final String GET_BRAIN_TREE_TOKEN_URL = BASE_URL + "getbraintreetoken";
        public static final String CREATE_ADD_CARD_URL = BASE_URL + "card_add";
        public static final String GET_ADDED_CARDS_URL = BASE_URL + "payment_modes";
        public static final String CREATE_SELECT_CARD_URL = BASE_URL + "card_default";
        public static final String POST_PAYMENT_MODE_UPDATE_URL = BASE_URL + "payment_mode_update";
        public static final String POST_GET_ALL_PROVIDERS_URL = BASE_URL + "request_providers";
        public static final String POST_POSTED_REQUESTED_URL = BASE_URL + "posted_requests";
        public static final String POST_CONFIRMED_REQUESTED_URL = BASE_URL + "confirmed_requests";
        public static final String POST_ONGOING_REQUESTED_URL = BASE_URL + "ongoing_requests";
        public static final String POST_PROVIDER_DETAIL_URL = BASE_URL + "provider/profile";
        public static final String POST_SINGLE_REQUEST_DETAIL_URL = BASE_URL + "single_request";
        public static final String POST_BIDS_DETAIL_URL = BASE_URL + "bids";
        public static final String POST_ASSIGN_REQUEST_URL = BASE_URL + "assign_request";
        public static final String POST_CARD_DELETE_URL = BASE_URL + "card_delete";
        public static final String POST_FORGOT_PASSWORD_URL = BASE_URL + "forgot_password";
        public static final String POST_CHANGE_PASSWORD_URL = BASE_URL + "change_password";
        public static final String POST_REQUEST_STATUS_CHECK_LATER_URL = BASE_URL + "request_later_details";
        public static final String POST_SINGLE_HISTORY_DETAILS_URL = BASE_URL + "single_request";
        public static final String GET_MESSAGES = BASE_URL + "message/get?id=1&token=test&request_id=1";
        public static final String LOGOUT = BASE_URL + "logout";
    }


    public class ServiceCode {
        public static final int POST_REGISTRATION = 1;
        public static final int POST_LOGIN = 2;
        public static final int POST_SOCIAL_LOGIN = 3;
        public static final int POST_CATEGORIES = 5;
        public static final int POST_SUB_CATEGORIES = 6;
        public static final int POST_DRAFTS_REQUEST = 7;
        public static final int POST_REQUEST_NOW = 8;
        public static final int POST_REQUEST_STATUS_CHECK_NOW = 9;
        public static final int POST_CANCEL_REQUEST = 10;
        public static final int POST_WAITING_REQUEST_CANCEL = 11;
        public static final int POST_PAY_NOW = 12;
        public static final int GET_PROFILE = 13;
        public static final int POST_UPDATE_PROFILE = 14;
        public static final int POST_REQUEST_RATING = 15;
        public static final int POST_HISTORY = 16;
        public static final int GET_BRAIN_TREE_TOKEN = 17;
        public static final int CREATE_ADD_CARD = 18;
        public static final int GET_ADDED_CARDS = 19;
        public static final int CREATE_SELECT_CARD = 20;
        public static final int POST_PAYMENT_MODE_UPDATE = 21;

        public static final int POST_GET_ALL_PROVIDERS = 22;
        public static final int POST_POSTED_REQUESTED = 23;
        public static final int POST_CONFIRMED_REQUESTED = 24;
        public static final int POST_ONGOING_REQUESTED = 25;
        public static final int POST_REQUEST_LATER = 26;
        public static final int POST_PROVIDER_DETAIL = 27;
        public static final int POST_SINGLE_REQUEST_DETAIL = 28;
        public static final int POST_BIDS_DETAIL = 29;
        public static final int POST_ASSIGN_REQUEST = 30;
        public static final int POST_CARD_DELETE = 31;
        public static final int POST_FORGOT_PASSWORD = 32;
        public static final int POST_CHANGE_PASSWORD = 33;
        public static final int POST_REQUEST_STATUS_CHECK_LATER = 34;
        public static final int POST_SINGLE_HISTORY_DETAILS = 35;
        public static final int GET_MESSAGES_CODE = 36;
        public static final int LOGOUT_CODE = 37;

    }


}
