package com.user.gentack.fragment;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.app.AlertDialog;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.user.gentack.R;
import com.user.gentack.activity.AddCardActivity;
import com.user.gentack.activity.ChangePasswordActivity;
import com.user.gentack.activity.HelpActivity;
import com.user.gentack.activity.HistoryActivity;
import com.user.gentack.activity.JobActivity;
import com.user.gentack.activity.MainActivity;
import com.user.gentack.activity.ProfileActivity;
import com.user.gentack.activity.SplashActivity;
import com.user.gentack.adapter.NavigationDrawerItemAdapter;
import com.user.gentack.model.DrawerDetails;
import com.user.gentack.model.ResponseHandler;
import com.user.gentack.utils.Const;
import com.user.gentack.utils.PreferenceHelper;
import com.user.gentack.utils.RecyclerViewItemClickListener;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by user on 12/28/2016.
 */
public class NavigationDrawerFragment extends Fragment {

    private RecyclerView drawerRecyclerView;
    private MainActivity activity;
    private ImageView userIcon;
    private TextView userName, emailId;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.navigation_drawer_layout, container, false);
        activity = (MainActivity) getActivity();
        drawerRecyclerView = (RecyclerView) view.findViewById(R.id.rv_drawer);
        userIcon = (ImageView) view.findViewById(R.id.iv_profile);
        userName = (TextView) view.findViewById(R.id.tv_user_name);
        emailId = (TextView) view.findViewById(R.id.tv_user_emailId);
        LinearLayoutManager layoutManager = new LinearLayoutManager(activity);
        drawerRecyclerView.setLayoutManager(layoutManager);
        final NavigationDrawerItemAdapter adapter = new NavigationDrawerItemAdapter(activity, getDrawerList());
        drawerRecyclerView.setAdapter(adapter);


        userName.setText(PreferenceHelper.getInstance().getUser_name());
        emailId.setText(PreferenceHelper.getInstance().getEmail());
        if (PreferenceHelper.getInstance().getPicture() != null) {
            Glide.with(activity).load(PreferenceHelper.getInstance().getPicture()).into(userIcon);
        } else {
            userIcon.setImageResource(R.drawable.default_user);
        }


        drawerRecyclerView.addOnItemTouchListener(new RecyclerViewItemClickListener(activity, new RecyclerViewItemClickListener.OnItemClickListener() {
            @Override
            public void onItemClick(View view, int position) {
                activity.closeDrawer();

                if (PreferenceHelper.getInstance().getLoginBy().equals(Const.MANUAL)) {
                    switch (position) {
                        case 0:
                            Intent mainIntent = new Intent(activity, MainActivity.class);
                            startActivity(mainIntent);
                            activity.finish();
                            break;
                        case 1:
                            Intent intent = new Intent(activity, ProfileActivity.class);
                            startActivity(intent);
                            break;
                        case 2:
                            Intent cardIntent = new Intent(activity, AddCardActivity.class);
                            startActivity(cardIntent);
                            break;
                        case 3:
                            Intent jobIntent = new Intent(activity, JobActivity.class);
                            startActivity(jobIntent);
                            break;
                        case 4:
                            Intent hisIntent = new Intent(activity, HistoryActivity.class);
                            startActivity(hisIntent);
                            break;
                        case 5:
                            Intent changeIntent = new Intent(activity, ChangePasswordActivity.class);
                            startActivity(changeIntent);
                            break;
                        case 6:
                            Intent helpIntent = new Intent(activity, HelpActivity.class);
                            startActivity(helpIntent);
                            break;
                        case 7:
                            showLogoutDialog();
                            break;

                    }
                } else {
                    switch (position) {
                        case 0:
                            Intent mainIntent = new Intent(activity, MainActivity.class);
                            startActivity(mainIntent);
                            activity.finish();
                            break;
                        case 1:
                            Intent intent = new Intent(activity, ProfileActivity.class);
                            startActivity(intent);
                            break;
                        case 2:
                            Intent cardIntent = new Intent(activity, AddCardActivity.class);
                            startActivity(cardIntent);
                            break;
                        case 3:
                            Intent jobIntent = new Intent(activity, JobActivity.class);
                            startActivity(jobIntent);
                            break;
                        case 4:
                            Intent hisIntent = new Intent(activity, HistoryActivity.class);
                            startActivity(hisIntent);
                            break;
                        case 5:
                            Intent helpIntent = new Intent(activity, HelpActivity.class);
                            startActivity(helpIntent);
                            break;
                        case 6:
                            showLogoutDialog();
                            break;

                    }
                }

            }
        }));


        return view;
    }


    private List<DrawerDetails> getDrawerList() {
        List<DrawerDetails> drawerList = new ArrayList<>();
//        drawerList.add(new DrawerDetails(R.drawable.user_selected, getString(R.string.profile)));
//        drawerList.add(new DrawerDetails(R.drawable.ic_front_car,getString(R.string.my_parking)));
        drawerList.add(new DrawerDetails(R.drawable.user_selected, "HOME"));
        drawerList.add(new DrawerDetails(R.drawable.user_selected, getString(R.string.profile)));
        drawerList.add(new DrawerDetails(R.drawable.user_selected, "CARDS"));
        drawerList.add(new DrawerDetails(R.drawable.user_selected, getString(R.string.jobs)));
        drawerList.add(new DrawerDetails(R.drawable.user_selected, getString(R.string.history)));
        if (PreferenceHelper.getInstance().getLoginBy().equals(Const.MANUAL)) {
            drawerList.add(new DrawerDetails(R.drawable.user_selected, getString(R.string.change_password)));
        }
        drawerList.add(new DrawerDetails(R.drawable.user_selected, getString(R.string.help)));
        drawerList.add(new DrawerDetails(R.drawable.sign_out, getString(R.string.sign_out)));


        return drawerList;
    }

    @Override
    public void onResume() {
        super.onResume();
//        activity.currentFragment = Const.UserSettingsFragment;
    }


    private void showLogoutDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(activity);
        builder.setTitle(getString(R.string.logout));
        String message = getString(R.string.logout_text);
        builder.setMessage(message);
        builder.setPositiveButton(getString(R.string.ok), new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                onDestroyView();
                activity.onEvent(new ResponseHandler(false, null));
                PreferenceHelper.getInstance().putFirstTimeLogin(false);
                PreferenceHelper.getInstance().putRequestId(Const.NO_REQUEST);
                Intent intent = new Intent(getActivity(), SplashActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                activity.startActivity(intent);
                activity.finish();
            }
        });

        builder.setNegativeButton(getString(R.string.cancel), new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
            }
        });
        builder.show();
    }
}
