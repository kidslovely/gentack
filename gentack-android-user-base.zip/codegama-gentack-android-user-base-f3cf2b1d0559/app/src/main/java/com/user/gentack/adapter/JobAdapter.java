package com.user.gentack.adapter;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.user.gentack.R;
import com.user.gentack.model.BiddingRequestDetails;
import com.user.gentack.utils.Const;

import java.util.List;

/**
 * Created by user on 4/8/2017.
 */

public class JobAdapter extends RecyclerView.Adapter<JobAdapter.CustomViewHolder> {


    private Context mContext;
    private List<BiddingRequestDetails> requestDetailsList;
    private String jobType;

    public JobAdapter(Context context, List<BiddingRequestDetails> requestDetailsList, String jobType) {
        mContext = context;
        this.requestDetailsList = requestDetailsList;
        this.jobType = jobType;
    }

    @Override
    public CustomViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(mContext).inflate(R.layout.adapter_job_bidding_layout, null);

        return new CustomViewHolder(view);
    }

    @Override
    public void onBindViewHolder(CustomViewHolder holder, int position) {
        final BiddingRequestDetails requestDetails = requestDetailsList.get(position);
        if (requestDetails.getServicePicture() != null && !requestDetails.getServicePicture().equals("")) {
            Glide.with(mContext).load(requestDetails.getServicePicture()).into(holder.providerIcon);
        } else {
            holder.providerIcon.setImageResource(R.drawable.default_user);
        }
        holder.jobService.setText(requestDetails.getServiceType());
        holder.jobTitle.setText(requestDetails.getJobTitle());
        holder.jobCharge.setText(requestDetails.getCurrency() + requestDetails.getPrice() + "/hr");
        holder.jobDesc.setText(requestDetails.getDescription());

        if (jobType.equals(Const.ONGOING) && (requestDetails.getProviderStatus() != null || !requestDetails.getProviderStatus().equals(""))) {

            int providerStatus = Integer.parseInt(requestDetails.getProviderStatus());
            holder.status.setVisibility(View.VISIBLE);
            switch (providerStatus) {
                case 3:
                    holder.status.setText(mContext.getString(R.string.provider_started_1));
                    break;
                case 4:
                    holder.status.setText(mContext.getString(R.string.provider_arrived_1));
                    break;
                case 5:
                    holder.status.setText(mContext.getString(R.string.provider_service_start_1));
                    break;
                case 6:
                    holder.status.setText(mContext.getString(R.string.pay_now));
                    break;
            }

        }


    }

    @Override
    public int getItemCount() {
        return requestDetailsList.size();
    }

    public class CustomViewHolder extends RecyclerView.ViewHolder {
        private ImageView providerIcon;
        private TextView jobService, jobTitle, jobCharge, jobDesc, status;


        public CustomViewHolder(View itemView) {
            super(itemView);
            providerIcon = (ImageView) itemView.findViewById(R.id.iv_bidding);
            jobService = (TextView) itemView.findViewById(R.id.tv_job_serviceType);
            jobTitle = (TextView) itemView.findViewById(R.id.tv_job_title);
            jobCharge = (TextView) itemView.findViewById(R.id.tv_job_charges);
            jobDesc = (TextView) itemView.findViewById(R.id.tv_job_desc);
            status = (TextView) itemView.findViewById(R.id.tv_jobStatus);

        }
    }
}