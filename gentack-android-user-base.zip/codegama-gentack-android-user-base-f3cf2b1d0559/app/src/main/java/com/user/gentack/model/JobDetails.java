package com.user.gentack.model;

import java.io.Serializable;

/**
 * Created by user on 3/11/2017.
 */

public class JobDetails implements Serializable {
    private String sAddress;
    private Double latitude;
    private Double longitude;
    private String date;
    private String time;
    private String description;
    private String jobTitle;
    private String approxHour;
    private String charges;

    public String getsAddress() {
        return sAddress;
    }

    public void setsAddress(String sAddress) {
        this.sAddress = sAddress;
    }

    public Double getLatitude() {
        return latitude;
    }

    public void setLatitude(Double latitude) {
        this.latitude = latitude;
    }

    public Double getLongitude() {
        return longitude;
    }

    public void setLongitude(Double longitude) {
        this.longitude = longitude;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getJobTitle() {
        return jobTitle;
    }

    public void setJobTitle(String jobTitle) {
        this.jobTitle = jobTitle;
    }

    public String getApproxHour() {
        return approxHour;
    }

    public void setApproxHour(String approxHour) {
        this.approxHour = approxHour;
    }

    public String getCharges() {
        return charges;
    }

    public void setCharges(String charges) {
        this.charges = charges;
    }
}
