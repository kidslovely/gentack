package com.user.gentack.model;

/**
 * Created by codegama on 24/1/18.
 */

public class ResponseHandler {

    private final boolean flag;
    private final String message;

    public ResponseHandler(boolean flag, String message) {
        this.flag = flag;
        this.message = message;
    }

    public String getMessage() {
        return message;
    }

    public boolean isFlag() {
        return flag;
    }
}
