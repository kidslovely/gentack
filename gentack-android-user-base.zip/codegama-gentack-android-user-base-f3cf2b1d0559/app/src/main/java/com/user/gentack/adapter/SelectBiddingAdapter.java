package com.user.gentack.adapter;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.aurelhubert.simpleratingbar.SimpleRatingBar;
import com.bumptech.glide.Glide;
import com.user.gentack.R;
import com.user.gentack.model.RequestDetails;

import java.util.List;

/**
 * Created by user on 4/2/2017.
 */

public class SelectBiddingAdapter extends RecyclerView.Adapter<SelectBiddingAdapter.CustomViewHolder> {


    private Context mContext;
    private List<RequestDetails> requestDetailsList;

    public SelectBiddingAdapter(Context context, List<RequestDetails> requestDetailsList) {
        mContext = context;
        this.requestDetailsList = requestDetailsList;
    }

    @Override
    public SelectBiddingAdapter.CustomViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(mContext).inflate(R.layout.adapter_bidding_layout, null);

        return new CustomViewHolder(view);
    }

    @Override
    public void onBindViewHolder(SelectBiddingAdapter.CustomViewHolder holder, int position) {
        RequestDetails requestDetails = requestDetailsList.get(position);
        if (requestDetails.getProviderPicture() != null && !requestDetails.getProviderPicture().equals("")) {
            Glide.with(mContext).load(requestDetails.getProviderPicture()).into(holder.providerIcon);
        } else {
            holder.providerIcon.setImageResource(R.drawable.default_user);
        }
        holder.providerName.setText(requestDetails.getProviderName());

        try {

            if (requestDetails.getProviderRating().equals("0")) {
                holder.ratingBar.setRating(0);
            } else {
                holder.ratingBar.setRating(Integer.parseInt(String.valueOf((requestDetails.getProviderRating().charAt(0)))));
            }


        } catch (Exception e) {
            e.printStackTrace();
        }
        holder.providerServiceType.setText(requestDetails.getJobTitle());
        holder.providerCharge.setText("$" + requestDetails.getCharges() + "/hr");


    }

    @Override
    public int getItemCount() {
        return requestDetailsList.size();
    }

    public class CustomViewHolder extends RecyclerView.ViewHolder {
        private ImageView providerIcon;
        private TextView providerName, providerServiceType, providerCharge;
        private SimpleRatingBar ratingBar;

        public CustomViewHolder(View itemView) {
            super(itemView);
            providerIcon = (ImageView) itemView.findViewById(R.id.iv_bidding);
            providerName = (TextView) itemView.findViewById(R.id.tv_bid_name);
            providerServiceType = (TextView) itemView.findViewById(R.id.tv_bid_service);
            providerCharge = (TextView) itemView.findViewById(R.id.tv_bid_charge);
            ratingBar = (SimpleRatingBar) itemView.findViewById(R.id.bid_rating);
        }
    }
}
