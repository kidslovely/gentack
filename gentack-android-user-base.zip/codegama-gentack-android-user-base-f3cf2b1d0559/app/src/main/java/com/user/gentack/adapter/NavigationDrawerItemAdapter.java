package com.user.gentack.adapter;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.user.gentack.R;
import com.user.gentack.model.DrawerDetails;

import java.util.List;

/**
 * Created by user on 2/9/2017.
 */

public class NavigationDrawerItemAdapter extends RecyclerView.Adapter<NavigationDrawerItemAdapter.CustomHolder> {

    private Context mContext;
    private List<DrawerDetails> drawerList;

    public NavigationDrawerItemAdapter(Context context, List<DrawerDetails> drawerList) {
        mContext = context;
        this.drawerList = drawerList;
    }

    @Override
    public CustomHolder onCreateViewHolder(ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(mContext).inflate(R.layout.adapter_navigation_drawer_item, null);
        return new CustomHolder(view);
    }

    @Override
    public void onBindViewHolder(CustomHolder holder, int position) {
        DrawerDetails details = drawerList.get(position);
        holder.drawerTitle.setText(details.getTitle());
    }

    @Override
    public int getItemCount() {
        return drawerList.size();
    }

    public class CustomHolder extends RecyclerView.ViewHolder {
        private ImageView drawerImage;
        private TextView drawerTitle;

        public CustomHolder(View itemView) {
            super(itemView);
            drawerImage = (ImageView) itemView.findViewById(R.id.iv_drawwer_icon);
            drawerTitle = (TextView) itemView.findViewById(R.id.tv_drawer_title);
            drawerImage.setVisibility(View.GONE);
        }
    }


}
