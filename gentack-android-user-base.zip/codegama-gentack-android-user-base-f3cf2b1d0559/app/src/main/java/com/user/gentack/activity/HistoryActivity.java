package com.user.gentack.activity;

import android.app.Activity;
import android.app.Dialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.aurelhubert.simpleratingbar.SimpleRatingBar;
import com.bumptech.glide.Glide;
import com.user.gentack.R;
import com.user.gentack.adapter.HistoryAdapter;
import com.user.gentack.custom_interface.AsyncTaskCompleteListener;
import com.user.gentack.model.RequestDetails;
import com.user.gentack.networking.HttpRequester;
import com.user.gentack.utils.AndyUtils;
import com.user.gentack.utils.Const;
import com.user.gentack.utils.ParseContent;
import com.user.gentack.utils.PreferenceHelper;
import com.user.gentack.utils.RecyclerViewItemClickListener;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.List;

public class HistoryActivity extends Activity implements AsyncTaskCompleteListener {

    private RecyclerView hisRecyclerView;
    private TextView noHisText;
    private ProgressBar hisProgressBar;
    private Toolbar hisToolbar;
    private ImageView backButton;
    private List<RequestDetails> requestDetailsList;

    public static String getGoogleMapThumbnail(double lati, double longi) {
        String staticMapUrl = "http://maps.google.com/maps/api/staticmap?center=" + lati + "," + longi + "&markers=" + lati + "," + longi + "&zoom=10&size=350x150&&sensor=false";
        return staticMapUrl;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_history);
        hisToolbar = (Toolbar) findViewById(R.id.tb_history);
        hisRecyclerView = (RecyclerView) findViewById(R.id.rv_history);
        noHisText = (TextView) findViewById(R.id.tv_noHistory);
        hisProgressBar = (ProgressBar) findViewById(R.id.historyProgressBar);
        backButton = (ImageView) findViewById(R.id.btn_back_his);
        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });
        getHistory();

        hisRecyclerView.addOnItemTouchListener(new RecyclerViewItemClickListener(this, new RecyclerViewItemClickListener.OnItemClickListener() {
            @Override
            public void onItemClick(View view, int position) {
                if (requestDetailsList != null && requestDetailsList.size() > 0)
                    getSingleHistoryDetails(requestDetailsList.get(position).getRequestId());
            }
        }));

    }

    @Override
    public void onBackPressed() {
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
        finish();
    }

    private void getHistory() {
        if (!AndyUtils.isNetworkAvailable(this)) {
            AndyUtils.showShortToast(getString(R.string.no_internet), this);
            return;
        }

        hisProgressBar.setVisibility(View.VISIBLE);
        HashMap<String, String> map = new HashMap<String, String>();
        map.put(Const.Params.URL, Const.ServiceType.POST_HISTORY_URL);
        map.put(Const.Params.ID, PreferenceHelper.getInstance().getUserId());
        map.put(Const.Params.TOKEN, PreferenceHelper.getInstance().getSessionToken());


        AndyUtils.appLog("Ashutosh", "HistoryMap" + map);
        new HttpRequester(HistoryActivity.this, Const.POST, map, Const.ServiceCode.POST_HISTORY, this);

    }

    private void getSingleHistoryDetails(String request_id) {

        if (!AndyUtils.isNetworkAvailable(this)) {

            return;
        }
        AndyUtils.showSimpleProgressDialog(this, "Loading...", false);
        HashMap<String, String> map = new HashMap<String, String>();
        map.put(Const.Params.URL, Const.ServiceType.POST_SINGLE_HISTORY_DETAILS_URL);
        map.put(Const.Params.ID, PreferenceHelper.getInstance().getUserId());
        map.put(Const.Params.TOKEN, PreferenceHelper.getInstance().getSessionToken());
        map.put(Const.Params.REQUEST_ID, String.valueOf(request_id));
        new HttpRequester(this, Const.POST, map, Const.ServiceCode.POST_SINGLE_HISTORY_DETAILS, this);
    }

    @Override
    public void onTaskCompleted(String response, int serviceCode) {
        switch (serviceCode) {
            case Const.ServiceCode.POST_HISTORY:
                hisProgressBar.setVisibility(View.GONE);
                AndyUtils.appLog("Ashutosh", "HistoryResponse" + response);
                requestDetailsList = ParseContent.getInstance().parsingHistoryResponse(response);
                if (requestDetailsList != null && requestDetailsList.size() > 0) {
                    HistoryAdapter historyAdapter = new HistoryAdapter(this, requestDetailsList);
                    LinearLayoutManager layoutManager = new LinearLayoutManager(this);
                    hisRecyclerView.setLayoutManager(layoutManager);
                    hisRecyclerView.setItemAnimator(new DefaultItemAnimator());
                    hisRecyclerView.setAdapter(historyAdapter);

                } else {
                    noHisText.setVisibility(View.VISIBLE);
                }

                break;
            case Const.ServiceCode.POST_SINGLE_HISTORY_DETAILS:
                AndyUtils.removeProgressDialog();
                Log.d("mahi", "single his response" + response);
                try {
                    JSONObject job = new JSONObject(response);
                    if (job.getString("success").equals("true")) {
                        JSONObject dataObj = job.getJSONObject("data");
                        String request_id = dataObj.optString("request_id");
                        String user_name = dataObj.optString("provider_name");
                        String user_picture = dataObj.optString("provider_picture");
                        String user_mobile = dataObj.optString("provider_mobile");
                        String description = dataObj.optString("description");
                        String note = dataObj.optString("note");
                        String request_date = dataObj.optString("request_date");
                        String category_name = dataObj.optString("sub_category_name");
                        String s_latitude = dataObj.optString("s_latitude");
                        String s_longitude = dataObj.optString("s_longitude");
                        String s_address = dataObj.optString("s_address");
                        String user_price = dataObj.optString("user_price");
                        String before_image = dataObj.optString("before_image");
                        String after_image = dataObj.optString("after_image");
                        String base_price = dataObj.optString("price_per_hour");
                        String user_rating = dataObj.optString("provider_rating");
                        JSONArray invoiceArray = dataObj.optJSONArray("invoice");
                        JSONObject jobinvoice = invoiceArray.optJSONObject(0);
                        String basePrice = jobinvoice.optString("base_price");
                        String time_price = jobinvoice.optString("time_price");
                        String tax_price = jobinvoice.optString("tax_price");
                        String total = jobinvoice.optString("total");
                        String payment_mode = jobinvoice.optString("payment_mode");
                        String provider_id = dataObj.optString("provider_id");
                        String google_img_url = getGoogleMapThumbnail(Double.valueOf(s_latitude), Double.valueOf(s_longitude));
                        showdetailedfullview(request_id, user_name, user_picture, user_mobile, description, note, request_date, category_name, s_latitude, s_longitude, s_address, user_price, user_rating, google_img_url, user_price, before_image, after_image, payment_mode, time_price, tax_price, total, payment_mode, basePrice, provider_id);
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                break;
        }
    }


    private void showdetailedfullview(final String request_id, String user_name, String user_picture, final String user_mobile, String description, String note, String request_date, String category_name, String s_latitude, String s_longitude, String s_address, String user_price, String user_rating, String google_img_url, String user_price1, String before_image, String after_image, String payment_mode, String time_price, String tax_price, String total, String paymentMode, String basePrice,final String provider_id) {

        final Dialog _dialog = new Dialog(this, R.style.DialogThemeforview);
        _dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        _dialog.setCancelable(true);
        _dialog.setContentView(R.layout.history_full_view);
        ImageView iv_userIcon = (ImageView) _dialog.findViewById(R.id.job_user_pic);
        ImageView jobdetailedMapView = (ImageView) _dialog.findViewById(R.id.jobdetailedMapView);
        TextView tv_user_name = (TextView) _dialog.findViewById(R.id.tv_job_client_name);
        TextView tv_service_requested = (TextView) _dialog.findViewById(R.id.tv_job_client_type);
        TextView headerText = (TextView) _dialog.findViewById(R.id.tv_dialog_header_history);
        ImageView backButton = (ImageView) _dialog.findViewById(R.id.btn_dialog_back_history);
        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                _dialog.cancel();
            }
        });
        headerText.setText(user_name);
        TextView tv_extra_price = (TextView) _dialog.findViewById(R.id.tv_extra_price);
        TextView tv_base_price = (TextView) _dialog.findViewById(R.id.tv_base_price);
        TextView tv_tax_price = (TextView) _dialog.findViewById(R.id.tv_tax_price);
        TextView tv_total_price = (TextView) _dialog.findViewById(R.id.tv_total_price);
        TextView tv_payment_type = (TextView) _dialog.findViewById(R.id.tv_payment_type);

        SimpleRatingBar rating = (SimpleRatingBar) _dialog.findViewById(R.id.job_rating_bar);
        FloatingActionButton btn_floating_call = (FloatingActionButton) _dialog.findViewById(R.id.btn_floating_call);
        FloatingActionButton info = (FloatingActionButton) _dialog.findViewById(R.id.btn_floating_info);
        ImageView iv_before = (ImageView) _dialog.findViewById(R.id.iv_before);
        ImageView iv_after = (ImageView) _dialog.findViewById(R.id.iv_after);
        Glide.with(this).load(before_image).into(iv_before);
        Glide.with(this).load(after_image).into(iv_after);
        tv_extra_price.setText("$" + " " + time_price);
        tv_base_price.setText("$" + " " + basePrice);
        tv_total_price.setText("$" + " " + total);
        tv_payment_type.setText("Pay Via - " + payment_mode);
        tv_tax_price.setText("$" + " " + tax_price);
        if (!user_picture.equals("")) {
            Glide.with(this).load(user_picture).error(R.drawable.default_user).into(iv_userIcon);
        }
        tv_user_name.setText(user_name);
        tv_service_requested.setText(category_name);
        Glide.with(this).load(google_img_url).into(jobdetailedMapView);
        if (!user_rating.equals("")) {
            int rate = Integer.parseInt(user_rating);
            rating.setRating(rate);
        }
        iv_userIcon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(HistoryActivity.this, DetailProfileActivity.class);
                intent.putExtra(Const.Params.PROVIDER_ID, provider_id);
                startActivity(intent);
            }
        });

        info.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(HistoryActivity.this, InfoActivity.class);
                intent.putExtra(Const.Params.REQUEST_ID, request_id);
                startActivity(intent);
            }
        });

        btn_floating_call.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Intent.ACTION_DIAL, Uri.fromParts("tel", user_mobile, null));
                startActivity(intent);
            }
        });

        _dialog.show();

    }

}
