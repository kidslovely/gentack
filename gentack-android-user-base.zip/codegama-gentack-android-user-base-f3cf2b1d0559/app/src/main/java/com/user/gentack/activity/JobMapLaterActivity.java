package com.user.gentack.activity;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.Nullable;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.aurelhubert.simpleratingbar.SimpleRatingBar;
import com.baoyachi.stepview.HorizontalStepView;
import com.baoyachi.stepview.bean.StepBean;
import com.bumptech.glide.Glide;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapView;
import com.google.android.gms.maps.MapsInitializer;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.CameraPosition;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.user.gentack.R;
import com.user.gentack.custom_interface.AsyncTaskCompleteListener;
import com.user.gentack.model.RequestDetails;
import com.user.gentack.networking.HttpRequester;
import com.user.gentack.utils.AndyUtils;
import com.user.gentack.utils.Const;
import com.user.gentack.utils.LocationHelper;
import com.user.gentack.utils.ParseContent;
import com.user.gentack.utils.PreferenceHelper;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/**
 * Created by user on 4/14/2017.
 */

public class JobMapLaterActivity extends Activity implements View.OnClickListener, AsyncTaskCompleteListener, LocationHelper.OnLocationReceived, OnMapReadyCallback {
    private MapView jobMapView;
    //    private MainActivity this;
    private Bundle mBundle;
    private GoogleMap mGoogleMap;
    private Marker currentMarker, destinationMArker;
    private HorizontalStepView horizontalStepView;
    private Button cancelButton, paynowButton, submitButton;
    private ImageView providerIcon, afterImage, beforeImage, backButton;
    private TextView providerName, providerCharge, headerText;
    private SimpleRatingBar ratingBar, feedbackRatingBar;
    private EditText reviewEdit;
    private LinearLayout ratingReviewLayout, invoiceLayout;
    private TextView basePrice, totalTime, taxPrice, totalPrice, paymentMode;
    private boolean firstStatus = false, secondStatus = false, thirdStatus = false, forthStatus = false, fifthStatus = false, afterImageStatus = false, beforeImageStatus = false;

    private RelativeLayout relLayout;
    private Bundle requestBundle;
    private RequestDetails requestDetails;
    private List<StepBean> stepsBeanList;
    private String requestId = "";
    private FloatingActionButton callButton, messageButton, infoButton;


    private Handler reqhandler;
    Runnable runnable = new Runnable() {
        public void run() {
            if (!requestId.equals("")) {
                getIncomingRequestsInProgress(requestId);
            }
            reqhandler.postDelayed(this, 4000);
        }
    };

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.fragment_job_map);

        jobMapView = (MapView) findViewById(R.id.jobMapView);
        cancelButton = (Button) findViewById(R.id.bn_cancel);
        cancelButton.setOnClickListener(this);
        headerText = (TextView) findViewById(R.id.tv_later_header);
        paynowButton = (Button) findViewById(R.id.bn_payNow);
        paynowButton.setOnClickListener(this);
        totalPrice = (TextView) findViewById(R.id.tv_totalPrice);
        taxPrice = (TextView) findViewById(R.id.tv_taxPrice);
        totalTime = (TextView) findViewById(R.id.tv_toatTime);
        basePrice = (TextView) findViewById(R.id.tv_basePrice);
        invoiceLayout = (LinearLayout) findViewById(R.id.ll_invoice);
        relLayout = (RelativeLayout) findViewById(R.id.rl_header);
        relLayout.setVisibility(View.VISIBLE);
        backButton = (ImageView) findViewById(R.id.bn_later_back);
        backButton.setVisibility(View.VISIBLE);
        backButton.setOnClickListener(this);
        callButton = (FloatingActionButton) findViewById(R.id.btn_floating_call);
        messageButton = (FloatingActionButton) findViewById(R.id.btn_floating_message);
        infoButton = (FloatingActionButton) findViewById(R.id.btn_floating_info);
        callButton.setOnClickListener(this);
        messageButton.setOnClickListener(this);
        infoButton.setOnClickListener(this);
        ratingReviewLayout = (LinearLayout) findViewById(R.id.ll_rating_review);
        providerIcon = (ImageView) findViewById(R.id.iv_providerIcon);
        providerName = (TextView) findViewById(R.id.tv_provider_name);
        providerCharge = (TextView) findViewById(R.id.tv_provider_charge);
        horizontalStepView = (HorizontalStepView) findViewById(R.id.horizontalStepVIew);
        reviewEdit = (EditText) findViewById(R.id.input_feedBack);
        feedbackRatingBar = (SimpleRatingBar) findViewById(R.id.feedback_rating);
        paymentMode = (TextView) findViewById(R.id.tv_payment_mode);
        ratingBar = (SimpleRatingBar) findViewById(R.id.rating);
        submitButton = (Button) findViewById(R.id.bn_submit);
        afterImage = (ImageView) findViewById(R.id.iv_after_image);
        beforeImage = (ImageView) findViewById(R.id.iv_before_image);
        afterImage.setVisibility(View.GONE);
        beforeImage.setVisibility(View.GONE);
        submitButton.setOnClickListener(this);
        stepsBeanList = new ArrayList<>();
        StepBean stepBean0 = new StepBean(getString(R.string.provider_accepted), -1);
        StepBean stepBean1 = new StepBean(getString(R.string.provider_started), -1);
        StepBean stepBean2 = new StepBean(getString(R.string.provider_arrived), -1);
        StepBean stepBean3 = new StepBean(getString(R.string.provider_service_start), -1);
        StepBean stepBean4 = new StepBean(getString(R.string.provider_service_completed), -1);
        stepsBeanList.add(stepBean0);
        stepsBeanList.add(stepBean1);
        stepsBeanList.add(stepBean2);
        stepsBeanList.add(stepBean3);
        stepsBeanList.add(stepBean4);
        horizontalStepView
                .setStepViewTexts(stepsBeanList)
                .setTextSize(10)//set textSize
                .setStepsViewIndicatorCompletedLineColor(ContextCompat.getColor(this, R.color.green_color))//设置StepsViewIndicator完成线的颜色
                .setStepsViewIndicatorUnCompletedLineColor(ContextCompat.getColor(this, R.color.dark_grey))//设置StepsViewIndicator未完成线的颜色
                .setStepViewComplectedTextColor(ContextCompat.getColor(this, android.R.color.black))//设置StepsView text完成线的颜色
                .setStepViewUnComplectedTextColor(ContextCompat.getColor(this, android.R.color.black))//设置StepsView text未完成线的颜色
                .setStepsViewIndicatorCompleteIcon(ContextCompat.getDrawable(this, R.drawable.selected))
                .setStepsViewIndicatorDefaultIcon(ContextCompat.getDrawable(this, R.drawable.unselected));

        LocationHelper locationHelper = new LocationHelper(this);
        locationHelper.setLocationReceivedLister(this);
        reqhandler = new Handler();
        mBundle = savedInstanceState;

        try {
            requestId = getIntent().getStringExtra(Const.Params.REQUEST_ID);
        } catch (Exception e) {
            e.printStackTrace();
        }

        startCheckingUpcomingRequests();
        try {
            MapsInitializer.initialize(this);

        } catch (Exception e) {
            e.printStackTrace();
        }

        jobMapView.onCreate(mBundle);

        setUpMap();

        providerIcon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (requestDetails != null) {
                    Intent intent = new Intent(JobMapLaterActivity.this, DetailProfileActivity.class);
                    intent.putExtra(Const.Params.PROVIDER_ID, requestDetails.getProviderId());
                    startActivity(intent);
                }
            }
        });

//            setCloseAppStatus(Integer.parseInt(requestDetails.getProviderStatus()));
//


    }

    private void setProviderMarker(RequestDetails requestDetails) {
        Log.d("MAPLATERMAP", requestDetails.getsLatitude() + "" + requestDetails.getsLongitude());
        if (requestDetails.getProviderLatitude() != null && requestDetails.getProviderLongitude() != null) {
            LatLng latLng = new LatLng(Double.valueOf(requestDetails.getProviderLatitude()), Double.valueOf(requestDetails.getProviderLongitude()));
            if (destinationMArker == null) {
                destinationMArker = mGoogleMap.addMarker(new MarkerOptions().position(latLng).title(requestDetails.getProviderName()).icon(BitmapDescriptorFactory.fromResource(R.drawable.marker_black)));
            } else {
                destinationMArker.setPosition(latLng);
            }
        }
        if (requestDetails.getsLatitude() != null && requestDetails.getsLongitude() != null){
            LatLng latLng = new LatLng(Double.valueOf(requestDetails.getsLatitude()), Double.valueOf(requestDetails.getsLongitude()));
            if (currentMarker == null){
                CameraPosition sourecCameraPosition = CameraPosition.builder()
                        .target(latLng)
                        .zoom(11)
                        .build();
                mGoogleMap.animateCamera(CameraUpdateFactory.newCameraPosition(sourecCameraPosition));
                currentMarker = mGoogleMap.addMarker(new MarkerOptions().position(latLng).title("Service Location").icon(BitmapDescriptorFactory.fromResource(R.drawable.marker_green)));
            }
            else {
                currentMarker.setPosition(latLng);
            }
        }
    }

    private void setCloseAppStatus(int status) {

        switch (status) {
            case 2:
                if (firstStatus == false) {
                    stepsBeanList.get(0).setState(1);
                    horizontalStepView.setStepViewTexts(stepsBeanList);
                    firstStatus = true;
                }
                break;
            case 3:
                if (secondStatus == false) {
                    stepsBeanList.get(0).setState(1);
                    stepsBeanList.get(1).setState(1);
                    horizontalStepView.setStepViewTexts(stepsBeanList);
                    secondStatus = true;
                }
                break;
            case 4:
                if (thirdStatus == false) {
                    cancelButton.setBackgroundResource(R.color.background_color);
                    cancelButton.setEnabled(false);
                    stepsBeanList.get(0).setState(1);
                    stepsBeanList.get(1).setState(1);
                    stepsBeanList.get(2).setState(1);

                    horizontalStepView.setStepViewTexts(stepsBeanList);
                    thirdStatus = true;
                }
                break;
            case 5:
                if (forthStatus == false) {
                    cancelButton.setBackgroundResource(R.color.background_color);
                    cancelButton.setEnabled(false);
                    stepsBeanList.get(0).setState(1);
                    stepsBeanList.get(1).setState(1);
                    stepsBeanList.get(2).setState(1);
                    stepsBeanList.get(3).setState(1);
                    horizontalStepView.setStepViewTexts(stepsBeanList);
                    forthStatus = true;
                }
                break;
            case 6:
                if (fifthStatus == false) {
                    stepsBeanList.get(0).setState(1);
                    stepsBeanList.get(1).setState(1);
                    stepsBeanList.get(2).setState(1);
                    stepsBeanList.get(3).setState(1);
                    stepsBeanList.get(4).setState(1);
                    horizontalStepView.setStepViewTexts(stepsBeanList);
                    fifthStatus = true;
                }
                break;
            default:
        }

    }


    private void setDataOnViews(RequestDetails details) {


        headerText.setText(details.getJobTitle());
        if (details.getProviderStatus().equals("5") && (details.getBeforeImage() != null || !details.getBeforeImage().equals(""))) {
            if (beforeImageStatus == false) {
                beforeImage.setVisibility(View.VISIBLE);
                if (!requestDetails.getBeforeImage().equals("")) {
                    Glide.with(this).load(requestDetails.getBeforeImage()).into(beforeImage);
                } else {
//                    beforeImage.setImageResource(R.drawable.before_img);
                }
                beforeImageStatus = true;
            }
        }
        if (details.getProviderStatus().equals("6") && (details.getAfterImage() != null || !details.getAfterImage().equals(""))) {
            if (beforeImageStatus == false) {
                beforeImage.setVisibility(View.VISIBLE);
                if (!requestDetails.getBeforeImage().equals("")) {
                    Glide.with(this).load(requestDetails.getBeforeImage()).into(beforeImage);
                } else {
//                    beforeImage.setImageResource(R.drawable.before_img);
                }
                beforeImageStatus = true;
            }
            if (afterImageStatus == false) {
                afterImage.setVisibility(View.VISIBLE);
                if (!requestDetails.getAfterImage().equals("")) {
                    Glide.with(this).load(requestDetails.getAfterImage()).into(afterImage);
                } else {
//                    afterImage.setImageResource(R.drawable.after_img);
                }
                afterImageStatus = true;
            }
        }

        if (details.getProviderPicture() != null) {
            Glide.with(this).load(details.getProviderPicture()).into(providerIcon);
        }
        if (details.getCharges() != null) {
            providerCharge.setText(details.getJobTitle() + " " + "/" + " " + details.getCurrency() + details.getCharges());
        }
        if (details.getProviderName() != null) {
            providerName.setText(details.getProviderName());
        }
        try {

            if (details.getProviderRating().equals("0") || details.getProviderRating().equals("")) {
                ratingBar.setRating(0);
            } else {
                ratingBar.setRating(Integer.parseInt(String.valueOf((requestDetails.getProviderRating().charAt(0)))));
            }


        } catch (Exception e) {
            e.printStackTrace();
        }


    }


    private void cancelRequest(String id, String reason) {
        if (!AndyUtils.isNetworkAvailable(this)) {

            return;
        }

        AndyUtils.showSimpleProgressDialog(this, getString(R.string.please_wait), false);
        HashMap<String, String> map = new HashMap<String, String>();
        map.put(Const.Params.URL, Const.ServiceType.POST_CANCEL_REQUEST_URL);
        map.put(Const.Params.ID, PreferenceHelper.getInstance().getUserId());
        map.put(Const.Params.TOKEN, PreferenceHelper.getInstance().getSessionToken());
        map.put(Const.Params.REQUEST_ID, String.valueOf(id));
        map.put(Const.Params.USER_REASON, "cancel");
        new HttpRequester(this, Const.POST, map, Const.ServiceCode.POST_CANCEL_REQUEST, this);
    }


    private void startCheckingUpcomingRequests() {
        startCheckRegTimer();
    }

    public void startCheckRegTimer() {
        reqhandler.postDelayed(runnable, 4000);
    }


    private void stopCheckingUpcomingRequests() {
        if (reqhandler != null) {
            reqhandler.removeCallbacks(runnable);

            Log.d("mahi", "stop handler");
        }
    }

    public void getIncomingRequestsInProgress(String reqId) {
        if (!AndyUtils.isNetworkAvailable(this)) {

            return;
        }

        HashMap<String, String> map = new HashMap<String, String>();
        map.put(Const.Params.URL, Const.ServiceType.POST_REQUEST_STATUS_CHECK_LATER_URL);
        map.put(Const.Params.ID, PreferenceHelper.getInstance().getUserId());
        map.put(Const.Params.TOKEN, PreferenceHelper.getInstance().getSessionToken());
        map.put(Const.Params.REQUEST_ID, reqId);
        new HttpRequester(this, Const.POST, map, Const.ServiceCode.POST_REQUEST_STATUS_CHECK_LATER, this);

    }

    public void payNow() {
        if (!AndyUtils.isNetworkAvailable(this)) {

            AndyUtils.showShortToast(getString(R.string.please_wait), this);
            return;
        }
        AndyUtils.showSimpleProgressDialog(this, getString(R.string.please_wait), false);
        HashMap<String, String> map = new HashMap<String, String>();
        map.put(Const.Params.URL, Const.ServiceType.POST_PAY_NOW_URL);
        map.put(Const.Params.ID, PreferenceHelper.getInstance().getUserId());
        map.put(Const.Params.TOKEN, PreferenceHelper.getInstance().getSessionToken());
        map.put(Const.Params.REQUEST_ID, String.valueOf(requestDetails.getRequestId()));
        map.put(Const.Params.PAYMENT_MODE, requestDetails.getPaymentMode());
        map.put(Const.Params.IS_PAID, String.valueOf("1"));

        AndyUtils.appLog("Ashutosh", "PayNowMap" + map);
        new HttpRequester(this, Const.POST, map, Const.ServiceCode.POST_PAY_NOW, this);
    }

    @Override
    public void onResume() {
        super.onResume();
        jobMapView.onResume();

    }

    @Override
    public void onPause() {
        super.onPause();
        jobMapView.onPause();
    }

    private void setUpMap() {
        if (mGoogleMap == null) {
            jobMapView.getMapAsync(new OnMapReadyCallback() {
                @Override
                public void onMapReady(GoogleMap googleMap) {
                    mGoogleMap = googleMap;

                    if (requestDetails != null) {
                        setProviderMarker(requestDetails);
                    }
                }
            });
        }
    }

    @Override
    public void onLocationReceived(LatLng latlong) {

    }

    @Override
    public void onLocationReceived(final Location location) {
//        this.runOnUiThread(new Runnable() {
//            @Override
//            public void run() {
//                if (location != null) {
//                    AndyUtils.appLog("CurrentLocation", location.toString());
//                    LatLng latLang = new LatLng(location.getLatitude(),
//                            location.getLongitude());
//
//                    if (currentMarker == null) {
//                        CameraPosition sourecCameraPosition = CameraPosition.builder()
//                                .target(latLang)
//                                .zoom(14)
//                                .build();
//                        currentMarker = mGoogleMap.addMarker(new MarkerOptions().position(latLang).title("My Location").icon(BitmapDescriptorFactory.fromResource(R.drawable.marker_green)));
//                        mGoogleMap.animateCamera(CameraUpdateFactory.newCameraPosition(sourecCameraPosition));
//                    } else {
//                        currentMarker.setPosition(latLang);
//                    }
//
//                }
//            }
//        });

    }

    @Override
    public void onConntected(Bundle bundle) {

    }

    @Override
    public void onConntected(Location location) {

    }

    @Override
    public void onTaskCompleted(String response, int serviceCode) {
        switch (serviceCode) {
            case Const.ServiceCode.POST_CANCEL_REQUEST:
                AndyUtils.removeProgressDialog();
                AndyUtils.appLog("Ashutosh", "CancelRequestResponse" + response);
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    if (jsonObject.optString(Const.SUCCESS).equals("true")) {
                        stopCheckingUpcomingRequests();
                        PreferenceHelper.getInstance().putRequestId(Const.NO_REQUEST);
                        AndyUtils.showLongToast("Request cancel successfully", this);
                        Intent intent = new Intent(this, MainActivity.class);
                        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                        startActivity(intent);
                        finish();
                    } else if (jsonObject.optString(Const.SUCCESS).equals("false")) {
                        AndyUtils.showShortToast(jsonObject.optString("error"), this);

                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                break;
            case Const.ServiceCode.POST_REQUEST_STATUS_CHECK_LATER:
                AndyUtils.appLog("Ashutosh", "CheckStatusResponse" + response);
                requestDetails = ParseContent.getInstance().parsingRequestInLaterProgress(response);

                if (requestDetails != null) {
                    setDataOnViews(requestDetails);
                    setProviderMarker(requestDetails);
                    if (requestDetails.getProviderPhone().equals("")) {
                        callButton.setVisibility(View.GONE);
                    }
                    else {
                        callButton.setVisibility(View.VISIBLE);
                    }
                    if (requestDetails.getProviderStatus().equals("5") && (requestDetails.getBeforeImage() != null || !requestDetails.getBeforeImage().equals(""))) {
                        if (beforeImageStatus == false) {
                            beforeImage.setVisibility(View.VISIBLE);
                            if (!requestDetails.getBeforeImage().equals("")) {
                                Glide.with(this).load(requestDetails.getBeforeImage()).into(beforeImage);
                            } else {
//                                beforeImage.setImageResource(R.drawable.before_img);
                            }
                            beforeImageStatus = true;
                        }
                    }

                    if (requestDetails.getProviderStatus().equals("6") && (requestDetails.getAfterImage() != null || !requestDetails.getAfterImage().equals(""))) {
                        if (afterImageStatus == false) {
                            afterImage.setVisibility(View.VISIBLE);
                            if (!requestDetails.getAfterImage().equals("")) {
                                Glide.with(this).load(requestDetails.getAfterImage()).into(afterImage);
                            } else {
//                                afterImage.setImageResource(R.drawable.after_img);
                            }
                            afterImageStatus = true;
                        }
                    }
                    setProviderMarker(requestDetails);
                    setCloseAppStatus(Integer.parseInt(requestDetails.getProviderStatus()));
                    setStatus(Integer.parseInt(requestDetails.getProviderStatus()));
                    if (Integer.parseInt(requestDetails.getProviderStatus()) == 6 && Integer.parseInt(requestDetails.getStatus()) == 5) {
                        stopCheckingUpcomingRequests();
                        horizontalStepView.setVisibility(View.GONE);
                        invoiceLayout.setVisibility(View.VISIBLE);
                        cancelButton.setVisibility(View.VISIBLE);
                        paynowButton.setVisibility(View.VISIBLE);
                        setDataOnInvoiceViews(requestDetails);
                        ratingBar.setVisibility(View.GONE);
                        providerCharge.setVisibility(View.GONE);

                    } else if (Integer.parseInt(requestDetails.getProviderStatus()) == 6 && Integer.parseInt(requestDetails.getStatus()) == 6) {
                        stopCheckingUpcomingRequests();
                        ratingReviewLayout.setVisibility(View.VISIBLE);
                        horizontalStepView.setVisibility(View.GONE);
                        submitButton.setVisibility(View.VISIBLE);
                        paynowButton.setVisibility(View.GONE);
                        ratingBar.setVisibility(View.GONE);
                        providerCharge.setVisibility(View.GONE);
                    } else if (Integer.parseInt(requestDetails.getProviderStatus()) == 6 && Integer.parseInt(requestDetails.getStatus()) == 7) {
                        stopCheckingUpcomingRequests();
                        ratingReviewLayout.setVisibility(View.VISIBLE);
                        horizontalStepView.setVisibility(View.GONE);
                        submitButton.setVisibility(View.VISIBLE);
                        paynowButton.setVisibility(View.GONE);
                        ratingBar.setVisibility(View.GONE);
                        providerCharge.setVisibility(View.GONE);
                    } else if (Integer.parseInt(requestDetails.getProviderStatus()) == 7 && Integer.parseInt(requestDetails.getStatus()) == 7) {
                        stopCheckingUpcomingRequests();
                        ratingReviewLayout.setVisibility(View.VISIBLE);
                        horizontalStepView.setVisibility(View.GONE);
                        submitButton.setVisibility(View.VISIBLE);
                        paynowButton.setVisibility(View.GONE);
                        ratingBar.setVisibility(View.GONE);
                        providerCharge.setVisibility(View.GONE);
                    }
                }
                else {
                    stopCheckingUpcomingRequests();
                    PreferenceHelper.getInstance().putRequestId(Const.NO_REQUEST);
                    AndyUtils.showLongToast("Request is no longer available", this);
                    Intent intent = new Intent(this, MainActivity.class);
                    intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                    startActivity(intent);
                    this.finish();
                }
                break;
            case Const.ServiceCode.POST_PAY_NOW:
                AndyUtils.removeProgressDialog();
                AndyUtils.appLog("AShiutos", "PaynowResponse" + response);
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    if (jsonObject.getString(Const.SUCCESS).equals("true")) {
                        stopCheckingUpcomingRequests();
                        AndyUtils.showShortToast("Payment done successfully", this);
                        invoiceLayout.setVisibility(View.GONE);
                        paynowButton.setVisibility(View.GONE);
                        submitButton.setVisibility(View.VISIBLE);
                        ratingBar.setVisibility(View.GONE);
                        ratingReviewLayout.setVisibility(View.VISIBLE);
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                break;
            case Const.ServiceCode.POST_REQUEST_RATING:
                AndyUtils.removeProgressDialog();
                AndyUtils.appLog("AShiutos", "RatingResponse" + response);
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    if (jsonObject.getString(Const.SUCCESS).equals("true")) {
                        stopCheckingUpcomingRequests();
                        PreferenceHelper.getInstance().putRequestId(Const.NO_REQUEST);
                        AndyUtils.showShortToast("Review done successfully", this);
                        Intent intent = new Intent(this, MainActivity.class);
                        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                        startActivity(intent);
                        this.finish();
                    } else if (jsonObject.optString(Const.SUCCESS).equals("false")) {
                        AndyUtils.showShortToast("Waiting for provider to confirm payment", this);
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }

        }
    }


    @Override
    public void onBackPressed() {
//        Intent jobIntent = new Intent(this, JobActivity.class);
//        startActivity(jobIntent);
//        finish();

        super.onBackPressed();
        stopCheckingUpcomingRequests();
    }


    @Override
    protected void onStop() {
        super.onStop();
    }

    private void setDataOnInvoiceViews(RequestDetails details) {
        totalPrice.setText(" $" + details.getTotalPrice());
        taxPrice.setText("$" + details.getTaxPrice());
        basePrice.setText("$" + details.getBasePrice());
        totalTime.setText(details.getExtraPrice() + "hrs");
        paymentMode.setText(details.getPaymentMode());
    }

    private void setStatus(int status) {
        switch (status) {
            case 2:
                if (firstStatus == false) {
                    stepsBeanList.get(0).setState(1);
                    horizontalStepView.setStepViewTexts(stepsBeanList);
                    firstStatus = true;
                }
                break;
            case 3:
                if (secondStatus == false) {
                    stepsBeanList.get(1).setState(1);
                    horizontalStepView.setStepViewTexts(stepsBeanList);
                    secondStatus = true;
                }
                break;
            case 4:
                if (thirdStatus == false) {
                    cancelButton.setBackgroundResource(R.color.background_color);
                    cancelButton.setEnabled(false);
                    stepsBeanList.get(2).setState(1);
                    horizontalStepView.setStepViewTexts(stepsBeanList);
                    thirdStatus = true;
                }

                break;
            case 5:
                if (forthStatus == false) {
                    cancelButton.setBackgroundResource(R.color.background_color);
                    cancelButton.setEnabled(false);
                    stepsBeanList.get(3).setState(1);
                    horizontalStepView.setStepViewTexts(stepsBeanList);
                    forthStatus = true;
                }
                break;
            case 6:
                if (fifthStatus == false) {
                    stepsBeanList.get(4).setState(1);
                    horizontalStepView.setStepViewTexts(stepsBeanList);
                    fifthStatus = true;
                }

                break;
            default:
        }
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.bn_cancel:
                if (requestDetails != null) {
                    cancelRequest(requestDetails.getRequestId(), "");
                }
                break;
            case R.id.bn_payNow:
                payNow();
                break;
            case R.id.bn_submit:

                if (feedbackRatingBar.getRating() != 0.0f && requestDetails != null) {
                    AndyUtils.appLog("JobMAp", "FeedBackRating" + feedbackRatingBar.getRating());
                    giveReview(reviewEdit.getText().toString(), feedbackRatingBar.getRating());
                } else {
                    AndyUtils.showShortToast("Please give rating", this);
                }
                break;
            case R.id.bn_later_back:
                onBackPressed();
                break;
            case R.id.btn_floating_call:

                if (requestDetails != null && (requestDetails.getProviderPhone() != null || !requestDetails.getProviderPhone().equals(""))) {
                    Intent intent = new Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + requestDetails.getProviderPhone()));
                    startActivity(intent);
                } else {
                    AndyUtils.showShortToast("Sorry, number is not available", this);
                }
                break;
            case R.id.btn_floating_info:
                if (requestDetails != null){
                    Intent intent = new Intent(this, InfoActivity.class);
                    intent.putExtra(Const.Params.REQUEST_ID, requestDetails.getRequestId());
                    startActivity(intent);
                }
                break;
            case R.id.btn_floating_message:
                if (requestDetails != null) {
                    Bundle bundle = new Bundle();
                    bundle.putString(Const.Params.REQUEST_ID, requestDetails.getRequestId());
                    bundle.putString(Const.Params.PROVIDER_ID, requestDetails.getProviderId());
                    bundle.putString(Const.Params.NAME, requestDetails.getProviderName());
                    bundle.putString(Const.Params.REQUEST_META_ID, "");
                    bundle.putString(Const.Params.BID_STATUS, "");
                    Intent intent = new Intent(this, ChatActivity.class);
                    intent.putExtras(bundle);
                    startActivity(intent);
                }
                break;

        }
    }

    private void giveReview(String comment, float rating) {
        if (!AndyUtils.isNetworkAvailable(this)) {

            AndyUtils.showShortToast(getString(R.string.please_wait), this);
            return;
        }
        AndyUtils.showSimpleProgressDialog(this, getString(R.string.please_wait), false);
        HashMap<String, String> map = new HashMap<String, String>();
        map.put(Const.Params.URL, Const.ServiceType.POST_REQUEST_RATING_URL);
        map.put(Const.Params.ID, PreferenceHelper.getInstance().getUserId());
        map.put(Const.Params.TOKEN, PreferenceHelper.getInstance().getSessionToken());
        map.put(Const.Params.REQUEST_ID, String.valueOf(requestDetails.getRequestId()));
        map.put(Const.Params.COMMENT, comment);
        map.put(Const.Params.RATING, String.valueOf((int) rating));

        AndyUtils.appLog("Ashutosh", "PayNowMap" + map);
        new HttpRequester(this, Const.POST, map, Const.ServiceCode.POST_REQUEST_RATING, this);
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        mGoogleMap = googleMap;
        if (mGoogleMap != null){
            mGoogleMap.getUiSettings().setMyLocationButtonEnabled(false);
            mGoogleMap.getUiSettings().setMapToolbarEnabled(true);
            if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                // TODO: Consider calling
                //    ActivityCompat#requestPermissions
                // here to request the missing permissions, and then overriding
                //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
                //                                          int[] grantResults)
                // to handle the case where the user grants the permission. See the documentation
                // for ActivityCompat#requestPermissions for more details.
                return;
            }
            mGoogleMap.setMyLocationEnabled(true);
        }
    }
}
