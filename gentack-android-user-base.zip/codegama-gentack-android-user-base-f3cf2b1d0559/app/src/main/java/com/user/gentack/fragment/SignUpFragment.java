package com.user.gentack.fragment;

import android.app.Activity;
import android.app.DatePickerDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentSender;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.TextInputLayout;
import android.support.v4.app.DialogFragment;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TextView;

import com.facebook.AccessToken;
import com.facebook.CallbackManager;
import com.facebook.FacebookCallback;
import com.facebook.FacebookException;
import com.facebook.FacebookSdk;
import com.facebook.GraphRequest;
import com.facebook.GraphResponse;
import com.facebook.login.LoginManager;
import com.facebook.login.LoginResult;
import com.user.gentack.R;
import com.user.gentack.activity.LoginRegisterActivity;
import com.user.gentack.activity.MainActivity;
import com.user.gentack.custom_interface.AsyncTaskCompleteListener;
import com.user.gentack.networking.HttpRequester;
import com.user.gentack.utils.AndyUtils;
import com.user.gentack.utils.Const;
import com.user.gentack.utils.ParseContent;
import com.user.gentack.utils.PreferenceHelper;
import com.google.android.gms.auth.api.Auth;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.auth.api.signin.GoogleSignInResult;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.GoogleApiClient;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.Arrays;
import java.util.Calendar;
import java.util.HashMap;

/**
 * Created by user on 2/28/2017.
 */

public class SignUpFragment extends Fragment implements View.OnClickListener, AsyncTaskCompleteListener,
         GoogleApiClient.OnConnectionFailedListener {

    private static final String TAG = "SignUpFragment";
    private static final int GOOGLE_SIGN_IN = 205;
    private static EditText nameEdit, emailEdit, dobEdit, phoneEdit, passwordEdit, cpasswordEdit;
    private TextView facebookText, googleText;
    private TextInputLayout inputLayoutName, inputLayoutEmail, inputLayoutDob, inputLayoutPhone, inputLayoutPassword, inputLayoutCPassword;
    private String sName, sEmail, sDob, sPhone, sPassword, sCPassword, sSocial_unique_id;
    private LoginRegisterActivity activity;
    private CallbackManager callbackManager;
    private boolean mSignInClicked, mIntentInProgress;
    private String loginType = Const.MANUAL;
    private GoogleApiClient mGoogleApiClient;
    private ConnectionResult mConnectionResult;
    private Button signUpButton;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        activity = (LoginRegisterActivity) getActivity();
        FacebookSdk.sdkInitialize(activity);
        callbackManager = CallbackManager.Factory.create();
        GoogleSignInOptions gso = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestEmail()
                .build();

        mGoogleApiClient = new GoogleApiClient.Builder(activity)
                .enableAutoManage(activity /* FragmentActivity */, this /* OnConnectionFailedListener */)
                .addApi(Auth.GOOGLE_SIGN_IN_API, gso)
                .build();
        AndyUtils.generateKeyHAsh(activity);
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_signup_layout, container, false);
        facebookText = (TextView) view.findViewById(R.id.tv_facebook_signup);
        googleText = (TextView) view.findViewById(R.id.tv_google_signup);
        inputLayoutName = (TextInputLayout) view.findViewById(R.id.input_layout_name);
        inputLayoutEmail = (TextInputLayout) view.findViewById(R.id.input_layout_email);
        inputLayoutDob = (TextInputLayout) view.findViewById(R.id.input_layout_dob);
        inputLayoutPhone = (TextInputLayout) view.findViewById(R.id.input_layout_phone);
        inputLayoutPassword = (TextInputLayout) view.findViewById(R.id.input_layout_password);
        inputLayoutCPassword = (TextInputLayout) view.findViewById(R.id.input_layout_cpassword);
        nameEdit = (EditText) view.findViewById(R.id.input_name);
        emailEdit = (EditText) view.findViewById(R.id.input_email);
        dobEdit = (EditText) view.findViewById(R.id.input_dob);
        phoneEdit = (EditText) view.findViewById(R.id.input_phone);
        passwordEdit = (EditText) view.findViewById(R.id.input_password);
        cpasswordEdit = (EditText) view.findViewById(R.id.input_cpassword);
        signUpButton = (Button) view.findViewById(R.id.bn_signup);
        dobEdit.setOnClickListener(this);
        facebookText.setOnClickListener(this);
        googleText.setOnClickListener(this);
        signUpButton.setOnClickListener(this);
        facebookRegisterCallBack();
        return view;
    }


    private void getSignUpDetails() {
        sName = nameEdit.getText().toString();
        sEmail = emailEdit.getText().toString();
        sDob = dobEdit.getText().toString();
        sPhone = phoneEdit.getText().toString();
        sPassword = passwordEdit.getText().toString();
        sCPassword = cpasswordEdit.getText().toString();
    }

    private void signIn() {
        Intent signInIntent = Auth.GoogleSignInApi.getSignInIntent(mGoogleApiClient);
        startActivityForResult(signInIntent, GOOGLE_SIGN_IN);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.tv_facebook_signup:
                AndyUtils.appLog(TAG, "On Click of Facebook::");
                LoginManager.getInstance().logInWithReadPermissions(this, Arrays.asList("public_profile", "email", "user_birthday", "user_photos", "user_location"));
                loginType = Const.FACEBOOK;
                break;
            case R.id.tv_google_signup:
                AndyUtils.appLog(TAG, "On Click of GooglePlus::");
                mSignInClicked = true;
                if (!mGoogleApiClient.isConnecting()) {
                    AndyUtils.showSimpleProgressDialog(activity, getString(R.string.connecting_gmail), false);
                    signIn();
                }
                break;
            case R.id.input_dob:
                SelectDateFragment dateFragment = new SelectDateFragment();
                dateFragment.show(getChildFragmentManager(), "");
                break;
            case R.id.bn_signup:
                getSignUpDetails();
                if (isValidData()) {
                    userRegistration();
                }
                break;
        }
    }

    private boolean isValidData() {
        if (sName.length() == 0) {
            AndyUtils.showShortToast(getString(R.string.please_enter_name), activity);
            return false;
        } else if (sEmail.length() == 0) {
            AndyUtils.showShortToast(getString(R.string.please_enter_emailid), activity);
            return false;
        } else if (!AndyUtils.eMailValidation(sEmail)) {
            inputLayoutEmail.setError(getString(R.string.incorrect_emailid));
            return false;
        } else if (sPhone.length() == 0) {
            AndyUtils.showShortToast(getString(R.string.please_enter_phone), activity);
            return false;
        } else if (sPhone.length() < 6) {
            AndyUtils.showShortToast("Phone number must have 6 digits", activity);
            return false;
        } else if (sPassword.length() == 0) {
            AndyUtils.showShortToast(getString(R.string.please_enter_password), activity);
            return false;
        } else if (sPassword.length() < 6) {
            AndyUtils.showShortToast("Password must have more than 6 characters", activity);
            return false;
        } else if (sCPassword.length() == 0) {
            AndyUtils.showShortToast("Please enter confirm password", activity);
            return false;
        } else if (sCPassword.length() < 6) {
            AndyUtils.showShortToast("Confirm Password must have more than 6 characters", activity);
            return false;
        } else if (!sPassword.equals(sCPassword)) {
            AndyUtils.showShortToast("Password and Confirm Password do not match", activity);
            return false;
        } else {
            return true;
        }

    }

    private void userRegistration() {
        if (!AndyUtils.isNetworkAvailable(activity)) {
            AndyUtils.showShortToast(getString(R.string.no_internet), activity);
            return;
        }

        AndyUtils.showSimpleProgressDialog(activity, getString(R.string.please_wait), false);
        HashMap<String, String> map = new HashMap<String, String>();
        map.put(Const.Params.URL, Const.ServiceType.POST_REGISTRATION_URL);
        map.put(Const.Params.EMAIL, sEmail);
        if (loginType.equals(Const.FACEBOOK) || loginType.equals(Const.GOOGLE)) {
            map.put(Const.Params.SOCIAL_UNIQUE_ID, sSocial_unique_id);
            map.put(Const.Params.LOGIN_BY, loginType);
        } else {
            map.put(Const.Params.LOGIN_BY, Const.MANUAL);
            map.put(Const.Params.MOBILE, sPhone);
            map.put(Const.Params.PASSWORD, sPassword);
        }

        map.put(Const.Params.NAME, sName);
        map.put(Const.Params.TIMEZONE, PreferenceHelper.getInstance().getTimeZone());
        map.put(Const.Params.DEVICE_TYPE, Const.ANDROID);
        map.put(Const.Params.DEVICE_TOKEN, PreferenceHelper.getInstance().getDeviceToken());


        AndyUtils.appLog("Ashutosh", "RegisterMap" + map);
        new HttpRequester(activity, Const.POST, map, Const.ServiceCode.POST_REGISTRATION, this);

    }

    @Override
    public void onTaskCompleted(String response, int serviceCode) {
        switch (serviceCode) {
            case Const.ServiceCode.POST_REGISTRATION:
                AndyUtils.removeProgressDialog();
                AndyUtils.appLog("Ashutosh", "RegisterResponse" + response);
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    if (jsonObject.optString(Const.SUCCESS).equals(Const.TRUE)) {
                        AndyUtils.showLongToast("Registration done successfully", activity);
                        ParseContent.getInstance().saveIdAndToken(response);
                        Intent intent = new Intent(activity, MainActivity.class);
                        startActivity(intent);
                        activity.finish();
                    } else {
                        AndyUtils.showShortToast(jsonObject.optString("error"), activity);
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }

                break;

        }
    }

    private void facebookRegisterCallBack() {
        LoginManager.getInstance().registerCallback(callbackManager, new FacebookCallback<LoginResult>() {
            //    private FacebookCallback<LoginResult> callback = new FacebookCallback<LoginResult>() {
            @Override
            public void onSuccess(LoginResult loginResult) {
                AndyUtils.appLog(TAG, "onSuccess");
                GraphRequest request = GraphRequest.newMeRequest(AccessToken.getCurrentAccessToken(),
                        new GraphRequest.GraphJSONObjectCallback() {
                            @Override
                            public void onCompleted(JSONObject jsonObject, GraphResponse graphResponse) {
                                if (jsonObject != null && graphResponse != null) {
                                    AndyUtils.appLog("Json Object", jsonObject.toString());
                                    AndyUtils.appLog("Graph response", graphResponse.toString());
                                    try {
                                        sName = jsonObject.getString("name");
                                        sEmail = jsonObject.getString("email");
                                        sSocial_unique_id = jsonObject.getString("id");
                                        if (sSocial_unique_id != null) {
                                            loginType = Const.FACEBOOK;
                                            userRegistration();
                                        } else {
                                            AndyUtils.showShortToast("Invalidate Data", activity);
                                        }
                                    } catch (JSONException e) {
                                        e.printStackTrace();
                                    }

                                }
                            }
                        }

                );
                Bundle parameters = new Bundle();
                parameters.putString("fields", "id,name,link,locale,hometown,email,gender,birthday,location");
                request.setParameters(parameters);
                request.executeAsync();
            }


            @Override
            public void onCancel() {
                AndyUtils.showLongToast(getString(R.string.login_cancelled), activity);
            }

            @Override
            public void onError(FacebookException error) {
                AndyUtils.showLongToast(getString(R.string.login_failed), activity);
                AndyUtils.appLog("login failed Error", error.toString());
            }
        });
    }


    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        Log.d("Activity Res", "" + requestCode);
        switch (requestCode) {
            case GOOGLE_SIGN_IN:
                if (resultCode != Activity.RESULT_OK) {
                    mSignInClicked = false;
                    AndyUtils.removeProgressDialog();
                }
                mIntentInProgress = false;
                GoogleSignInResult result = Auth.GoogleSignInApi.getSignInResultFromIntent(data);
                handleSignInResult(result);
                break;
            default:
                callbackManager.onActivityResult(requestCode, resultCode, data);

        }
    }

    private void handleSignInResult(GoogleSignInResult result) {
        Log.d(TAG, "handleSignInResult:" + result.isSuccess());
        AndyUtils.removeProgressDialog();
        if (result.isSuccess()) {
            GoogleSignInAccount acct = result.getSignInAccount();
            if (acct != null) {
                sSocial_unique_id = acct.getId();
                sName = acct.getDisplayName();
                sEmail = acct.getEmail();
                if (sSocial_unique_id != null) {
                    loginType = Const.GOOGLE;
                    userRegistration();
                }
                else {
                    AndyUtils.showShortToast(getString(R.string.invalid_data), activity);
                }
            }
            else {
                AndyUtils.showShortToast(getString(R.string.invalid_data), activity);
            }
        }
        else {
            // Signed out, show unauthenticated UI.
            AndyUtils.showShortToast(getString(R.string.invalid_data), activity);
        }
    }

    private void resolveSignInError() {
        if (mConnectionResult.hasResolution()) {
            try {
                mIntentInProgress = true;
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN) {
                    startIntentSenderForResult(mConnectionResult
                                    .getResolution().getIntentSender(), GOOGLE_SIGN_IN, null,
                            0, 0, 0, null);
                }
            } catch (IntentSender.SendIntentException e) {
                // The intent was canceled before it was sent. Return to the
                // default
                // state and attempt to connect to get an updated
                // ConnectionResult.
                mIntentInProgress = false;
                mGoogleApiClient.connect();
            }
        }
    }

    @Override
    public void onConnectionFailed(@NonNull ConnectionResult connectionResult) {
        if (!mIntentInProgress) {
            // Store the ConnectionResult so that we can use it later when the
            // user clicks
            // 'sign-in'.

            mConnectionResult = connectionResult;
            if (mSignInClicked) {
                // The user has already clicked 'sign-in' so we attempt to
                // resolve all

                // errors until the user is signed in, or they cancel.
                resolveSignInError();
            }
        }

    }

    @Override
    public void onStop() {
        super.onStop();
    }

    public static class SelectDateFragment extends DialogFragment implements DatePickerDialog.OnDateSetListener {

        private DatePickerDialog pickerDialog;

        public Dialog onCreateDialog(Bundle savedInstanceState) {
            final Calendar calendar = Calendar.getInstance();
            final int yy = calendar.get(Calendar.YEAR);
            final int mm = calendar.get(Calendar.MONTH);
            final int dd = calendar.get(Calendar.DAY_OF_MONTH);

            pickerDialog = new DatePickerDialog(getActivity(), R.style.DialogTheme, this, yy, mm, dd);


            pickerDialog.setButton(DialogInterface.BUTTON_POSITIVE, "OK", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    if (which == DialogInterface.BUTTON_POSITIVE) {

                        String date = pickerDialog.getDatePicker().getDayOfMonth() + "-" + pickerDialog.getDatePicker().getMonth() + "-" + pickerDialog.getDatePicker().getYear();
                        dobEdit.setText(date);

                    }
                }
            });
            return pickerDialog;
        }

        @Override
        public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
            AndyUtils.appLog("CarSelectionFragment", "OnDateSet");
        }

    }
}
