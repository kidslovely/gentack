package com.user.gentack.fragment;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.user.gentack.R;
import com.user.gentack.activity.MainActivity;
import com.user.gentack.adapter.CategoryAdapter;
import com.user.gentack.custom_interface.AsyncTaskCompleteListener;
import com.user.gentack.model.CategoryDetails;
import com.user.gentack.networking.HttpRequester;
import com.user.gentack.utils.AndyUtils;
import com.user.gentack.utils.Const;
import com.user.gentack.utils.ParseContent;
import com.user.gentack.utils.PreferenceHelper;
import com.user.gentack.utils.RecyclerViewItemClickListener;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.List;

/**
 * Created by user on 3/5/2017.
 */

public class SubCategoryFragment extends Fragment implements AsyncTaskCompleteListener {

    private static String categoryId = "";
    private MainActivity activity;
    private RecyclerView subCatRecyclerView;
    private TextView noSubCategory;
    private ProgressBar subCategoryProgressBar;
    private Bundle bundle;
    private List<CategoryDetails> categoryDetailsList;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        activity = (MainActivity) getActivity();
        bundle = getArguments();
        if (bundle != null) {
            categoryId = bundle.getString(Const.Params.CATEGORY_ID);
        }
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_sub_category_layout, container, false);
        subCatRecyclerView = (RecyclerView) view.findViewById(R.id.rv_sub_category);
        GridLayoutManager layoutManager = new GridLayoutManager(activity, 2);
        subCatRecyclerView.setLayoutManager(layoutManager);
        noSubCategory = (TextView) view.findViewById(R.id.tv_noSubCategory);
        subCategoryProgressBar = (ProgressBar) view.findViewById(R.id.subCategoryProgressBar);
        if (!categoryId.equals("")) {
            getSubCategoryDetails(categoryId);
        }


        subCatRecyclerView.addOnItemTouchListener(new RecyclerViewItemClickListener(activity, new RecyclerViewItemClickListener.OnItemClickListener() {
            @Override
            public void onItemClick(View view, int position) {
                activity.backButton.setVisibility(View.VISIBLE);
                Bundle bundle = new Bundle();
                bundle.putSerializable(Const.Params.SUB_CATEGORY_FRAGMENT, categoryDetailsList.get(position));
                bundle.putString(Const.Params.CATEGORY_ID, categoryId);
                JobDetailFragment jobDetailFragment = new JobDetailFragment();
                jobDetailFragment.setArguments(bundle);
                activity.addFragment(jobDetailFragment, false, "", "");
            }
        }));
        return view;
    }

    @Override
    public void onResume() {
        super.onResume();
        activity.currentFragment = Const.Params.SUB_CATEGORY_FRAGMENT;
    }

    private void getSubCategoryDetails(String id) {
        if (!AndyUtils.isNetworkAvailable(activity)) {
            AndyUtils.showShortToast(getString(R.string.no_internet), activity);
            return;
        }
        subCategoryProgressBar.setVisibility(View.VISIBLE);
        HashMap<String, String> map = new HashMap<String, String>();
        map.put(Const.Params.URL, Const.ServiceType.POST_SUB_CATEGORIES_URL);
        map.put(Const.Params.ID, PreferenceHelper.getInstance().getUserId());
        map.put(Const.Params.TOKEN, PreferenceHelper.getInstance().getSessionToken());
        map.put(Const.Params.CATEGORY_ID, String.valueOf(id));

        AndyUtils.appLog("Ashutosh", "SubCategoryMap" + map);
        new HttpRequester(activity, Const.POST, map, Const.ServiceCode.POST_SUB_CATEGORIES, this);

    }

    @Override
    public void onTaskCompleted(String response, int serviceCode) {
        switch (serviceCode) {
            case Const.ServiceCode.POST_SUB_CATEGORIES:
                subCategoryProgressBar.setVisibility(View.GONE);
                AndyUtils.appLog("Ashutosh", "CategoryResponse" + response);
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    if (jsonObject.optString(Const.SUCCESS).equals(Const.TRUE)) {
                        categoryDetailsList = ParseContent.getInstance().parsingSubCategoryListResponse(response);
                        if (categoryDetailsList.size() > 0) {
                            noSubCategory.setVisibility(View.GONE);
                            CategoryAdapter adapter = new CategoryAdapter(activity, categoryDetailsList);
                            subCatRecyclerView.setAdapter(adapter);
                        } else {
                            noSubCategory.setVisibility(View.VISIBLE);
                        }
                    } else {
                        noSubCategory.setVisibility(View.VISIBLE);
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
        }

    }
}
