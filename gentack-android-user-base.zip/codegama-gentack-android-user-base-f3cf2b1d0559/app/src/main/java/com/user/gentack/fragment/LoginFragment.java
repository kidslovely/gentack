package com.user.gentack.fragment;

import android.app.Activity;
import android.app.Dialog;
import android.content.Intent;
import android.content.IntentSender;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.TextInputLayout;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import com.facebook.AccessToken;
import com.facebook.CallbackManager;
import com.facebook.FacebookCallback;
import com.facebook.FacebookException;
import com.facebook.FacebookSdk;
import com.facebook.GraphRequest;
import com.facebook.GraphResponse;
import com.facebook.login.LoginManager;
import com.facebook.login.LoginResult;
import com.user.gentack.R;
import com.user.gentack.activity.LoginRegisterActivity;
import com.user.gentack.activity.MainActivity;
import com.user.gentack.custom_interface.AsyncTaskCompleteListener;
import com.user.gentack.networking.HttpRequester;
import com.user.gentack.utils.AndyUtils;
import com.user.gentack.utils.Const;
import com.user.gentack.utils.ParseContent;
import com.user.gentack.utils.PreferenceHelper;
import com.google.android.gms.auth.api.Auth;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.auth.api.signin.GoogleSignInResult;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.GoogleApiClient;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.Arrays;
import java.util.HashMap;

/**
 * Created by user on 2/28/2017.
 */

public class LoginFragment extends Fragment implements View.OnClickListener, AsyncTaskCompleteListener,
        GoogleApiClient.OnConnectionFailedListener {

    private static final String TAG = LoginFragment.class.getSimpleName();
    private static final int GOOGLE_SIGN_IN = 205;
    private TextView facebookText, googleText;
    private LoginRegisterActivity activity;
    private EditText emailEdit, passwordEdit;
    private String sEmail, sPassword, sSocial_unique_id, sName;
    private TextInputLayout emailLayout, passwordLayout;
    private CallbackManager callbackManager;
    private boolean mSignInClicked, mIntentInProgress;
    private String loginType = Const.MANUAL;
    private GoogleApiClient mGoogleApiClient;
    private ConnectionResult mConnectionResult;
    private Button loginButton;
    private Dialog forgotDialog;
    private TextView forgotPassword;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        activity = (LoginRegisterActivity) getActivity();
        FacebookSdk.sdkInitialize(activity);
        callbackManager = CallbackManager.Factory.create();

        GoogleSignInOptions gso = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestEmail()
                .build();

        mGoogleApiClient = new GoogleApiClient.Builder(activity)
                .enableAutoManage(activity /* FragmentActivity */, this /* OnConnectionFailedListener */)
                .addApi(Auth.GOOGLE_SIGN_IN_API, gso)
                .build();

        AndyUtils.generateKeyHAsh(activity);
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_login_layout, container, false);
        facebookText = (TextView) view.findViewById(R.id.tv_facebook_login);
        googleText = (TextView) view.findViewById(R.id.tv_google_login);
        emailEdit = (EditText) view.findViewById(R.id.et_email);
        passwordEdit = (EditText) view.findViewById(R.id.et_password);
        loginButton = (Button) view.findViewById(R.id.bn_login);
        emailLayout = (TextInputLayout) view.findViewById(R.id.input_login_email);
        passwordLayout = (TextInputLayout) view.findViewById(R.id.input_login_password);
        forgotPassword = (TextView) view.findViewById(R.id.tv_forgot_password);
        loginButton.setOnClickListener(this);
        facebookText.setOnClickListener(this);
        googleText.setOnClickListener(this);
        forgotPassword.setOnClickListener(this);
        facebookRegisterCallBack();
        return view;
    }

    private void getLoginDetails() {
        sEmail = emailEdit.getText().toString();
        sPassword = passwordEdit.getText().toString();
    }


    private boolean isValidData() {
        if (sEmail.length() == 0) {
            AndyUtils.showShortToast(getString(R.string.please_enter_emailid), activity);
            return false;
        } else if (!AndyUtils.eMailValidation(sEmail)) {
            emailLayout.setError(getString(R.string.incorrect_emailid));
            return false;
        } else if (sPassword.length() == 0) {
            AndyUtils.showShortToast(getString(R.string.please_enter_password), activity);
            return false;
        } else {
            return true;
        }

    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.tv_facebook_login:
                AndyUtils.appLog(TAG, "On Click of Facebook::");
                LoginManager.getInstance().logInWithReadPermissions(this, Arrays.asList("public_profile", "email", "user_birthday", "user_photos", "user_location"));
                loginType = Const.FACEBOOK;
                break;
            case R.id.tv_google_login:
                AndyUtils.appLog(TAG, "On Click of GooglePlus::");
                mSignInClicked = true;
                if (!mGoogleApiClient.isConnecting()) {
                    AndyUtils.showSimpleProgressDialog(activity, getString(R.string.connecting_gmail), false);
                    signIn();
                }
                break;
            case R.id.bn_login:
                getLoginDetails();
                if (isValidData()) {
                    userLogin();
                }
                break;
            case R.id.tv_forgot_password:
                showForgotPasswordDialog();
                break;
        }
    }

    private void signIn() {
        Intent signInIntent = Auth.GoogleSignInApi.getSignInIntent(mGoogleApiClient);
        startActivityForResult(signInIntent, GOOGLE_SIGN_IN);
    }

    private void showForgotPasswordDialog() {
        forgotDialog = new Dialog(activity, R.style.DialogThemeforview);
        forgotDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        forgotDialog.setContentView(R.layout.dialog_forgot_password_layout);
        final EditText emailId = (EditText) forgotDialog.findViewById(R.id.et_forgot_emailId);
        Button requestButton = (Button) forgotDialog.findViewById(R.id.btn_reset);
        ImageView backButton = (ImageView) forgotDialog.findViewById(R.id.btn_back_password);

        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                forgotDialog.cancel();
            }
        });
        requestButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (emailId.getText().toString().length() == 0) {
                    AndyUtils.showShortToast(getString(R.string.please_enter_emailid), activity);
                } else {
                    requestForgotPassword(emailId.getText().toString());
                }

            }
        });
        forgotDialog.show();
    }

    private void requestForgotPassword(String emailId) {
        if (!AndyUtils.isNetworkAvailable(activity)) {
            AndyUtils.showShortToast(getString(R.string.no_internet), activity);
            return;
        }
        AndyUtils.showSimpleProgressDialog(activity, getString(R.string.please_wait), false);
        HashMap<String, String> map = new HashMap<String, String>();
        map.put(Const.Params.URL, Const.ServiceType.POST_FORGOT_PASSWORD_URL);
        map.put(Const.Params.EMAIL, emailId);


        AndyUtils.appLog(TAG, "ForgotPasswordMap" + map);

        new HttpRequester(activity, Const.POST, map, Const.ServiceCode.POST_FORGOT_PASSWORD, this);
    }


    private void userLogin() {
        if (!AndyUtils.isNetworkAvailable(activity)) {
            AndyUtils.showShortToast(getString(R.string.no_internet), activity);
            return;
        }
        AndyUtils.showSimpleProgressDialog(activity, getString(R.string.please_wait), false);
        HashMap<String, String> map = new HashMap<String, String>();
        map.put(Const.Params.URL, Const.ServiceType.POST_LOGIN_URL);
        map.put(Const.Params.EMAIL, sEmail);
        if (loginType.equals(Const.FACEBOOK) || loginType.equals(Const.GOOGLE)) {
            map.put(Const.Params.SOCIAL_UNIQUE_ID, sSocial_unique_id);
            map.put(Const.Params.LOGIN_BY, loginType);
        } else {
            map.put(Const.Params.LOGIN_BY, Const.MANUAL);
            map.put(Const.Params.PASSWORD, sPassword);
        }

        map.put(Const.Params.DEVICE_TYPE, Const.ANDROID);
        map.put(Const.Params.TIMEZONE, PreferenceHelper.getInstance().getTimeZone());
        map.put(Const.Params.DEVICE_TOKEN, PreferenceHelper.getInstance().getDeviceToken());


        AndyUtils.appLog("Ashutosh", "RegisterMap" + map);
        new HttpRequester(activity, Const.POST, map, Const.ServiceCode.POST_LOGIN, this);

    }


    private void userSocailLogin() {
        if (!AndyUtils.isNetworkAvailable(activity)) {
            AndyUtils.showShortToast(getString(R.string.no_internet), activity);
            return;
        }

        AndyUtils.showSimpleProgressDialog(activity, getString(R.string.please_wait), false);
        HashMap<String, String> map = new HashMap<String, String>();
        map.put(Const.Params.URL, Const.ServiceType.POST_REGISTRATION_URL);
        map.put(Const.Params.EMAIL, sEmail);
        if (loginType.equals(Const.FACEBOOK) || loginType.equals(Const.GOOGLE)) {
            map.put(Const.Params.SOCIAL_UNIQUE_ID, sSocial_unique_id);
            map.put(Const.Params.LOGIN_BY, loginType);
        }
        map.put(Const.Params.NAME, sName);
        map.put(Const.Params.DEVICE_TYPE, Const.ANDROID);
        map.put(Const.Params.TIMEZONE, PreferenceHelper.getInstance().getTimeZone());
        map.put(Const.Params.DEVICE_TOKEN, PreferenceHelper.getInstance().getDeviceToken());

        AndyUtils.appLog("Ashutosh", "RegisterMap" + map);
        new HttpRequester(activity, Const.POST, map, Const.ServiceCode.POST_LOGIN, this);

    }


    @Override
    public void onTaskCompleted(String response, int serviceCode) {
        switch (serviceCode) {
            case Const.ServiceCode.POST_LOGIN:
                AndyUtils.removeProgressDialog();
                AndyUtils.appLog("Ashutosh", "LoginResponse" + response);
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    if (jsonObject.getString(Const.SUCCESS).equals(Const.TRUE)) {
                        PreferenceHelper.getInstance().putFirstTimeLogin(true);
                        ParseContent.getInstance().saveIdAndToken(response);
                        Intent intent = new Intent(activity, MainActivity.class);
                        startActivity(intent);
                        activity.finish();
                    } else {
                        AndyUtils.showShortToast(jsonObject.optString("error"), activity);
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                break;
            case Const.ServiceCode.POST_FORGOT_PASSWORD:
                AndyUtils.removeProgressDialog();
                AndyUtils.appLog("Ashutosh", "ForgotPasswordResponse" + response);
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    if (jsonObject.getString(Const.SUCCESS).equals(Const.TRUE)) {
                        AndyUtils.showLongToast(jsonObject.optString("message"), activity);
                        if (forgotDialog != null && forgotDialog.isShowing()) {
                            forgotDialog.cancel();
                        }
                    }
                    else {
                        AndyUtils.showLongToast(jsonObject.optString("error"), activity);
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }


        }
    }

    private void facebookRegisterCallBack() {
        LoginManager.getInstance().registerCallback(callbackManager, new FacebookCallback<LoginResult>() {
            //    private FacebookCallback<LoginResult> callback = new FacebookCallback<LoginResult>() {
            @Override
            public void onSuccess(LoginResult loginResult) {
                AndyUtils.appLog(TAG, "onSuccess");
                GraphRequest request = GraphRequest.newMeRequest(AccessToken.getCurrentAccessToken(),
                        new GraphRequest.GraphJSONObjectCallback() {
                            @Override
                            public void onCompleted(JSONObject jsonObject, GraphResponse graphResponse) {
                                if (jsonObject != null && graphResponse != null) {
                                    AndyUtils.appLog("Json Object", jsonObject.toString());
                                    AndyUtils.appLog("Graph response", graphResponse.toString());
                                    try {
                                        sName = jsonObject.getString("name");
                                        sEmail = jsonObject.getString("email");
                                        sSocial_unique_id = jsonObject.getString("id");
                                        if (sSocial_unique_id != null) {
                                            loginType = Const.FACEBOOK;
                                            userSocailLogin();
                                        } else {
                                            AndyUtils.showShortToast("Invalidate Data", activity);
                                        }
                                    } catch (JSONException e) {
                                        e.printStackTrace();
                                    }

                                }
                            }
                        }

                );
                Bundle parameters = new Bundle();
                parameters.putString("fields", "id,name,link,locale,hometown,email,gender,birthday,location");
                request.setParameters(parameters);
                request.executeAsync();
            }


            @Override
            public void onCancel() {
                AndyUtils.showLongToast(getString(R.string.login_cancelled), activity);
            }

            @Override
            public void onError(FacebookException error) {
                AndyUtils.showLongToast(getString(R.string.login_failed), activity);
                AndyUtils.appLog("login failed Error", error.toString());
            }
        });
    }


    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        Log.d("Activity Res", "" + requestCode);
        switch (requestCode) {
            case GOOGLE_SIGN_IN:
                if (resultCode != Activity.RESULT_OK) {
                    mSignInClicked = false;
                    AndyUtils.removeProgressDialog();
                }
                mIntentInProgress = false;

                GoogleSignInResult result = Auth.GoogleSignInApi.getSignInResultFromIntent(data);
                handleSignInResult(result);
                break;
            default:
                callbackManager.onActivityResult(requestCode, resultCode, data);

        }
    }

    private void handleSignInResult(GoogleSignInResult result) {
        Log.d(TAG, "handleSignInResult:" + result.isSuccess());
        AndyUtils.removeProgressDialog();
        if (result.isSuccess()) {
            GoogleSignInAccount acct = result.getSignInAccount();
            if (acct != null) {
                sSocial_unique_id = acct.getId();
                sName = acct.getDisplayName();
                sEmail = acct.getEmail();
                if (sSocial_unique_id != null) {
                    loginType = Const.GOOGLE;
                    userSocailLogin();
                }
                else {
                    AndyUtils.showShortToast(getString(R.string.invalid_data), activity);
                }
            }
            else {
                AndyUtils.showShortToast(getString(R.string.invalid_data), activity);
            }
        }
        else {
            // Signed out, show unauthenticated UI.
            AndyUtils.showShortToast(getString(R.string.invalid_data), activity);
        }
    }

    private void resolveSignInError() {
        if (mConnectionResult.hasResolution()) {
            try {
                mIntentInProgress = true;
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN) {
                    startIntentSenderForResult(mConnectionResult
                                    .getResolution().getIntentSender(), GOOGLE_SIGN_IN, null,
                            0, 0, 0, null);
                }
            } catch (IntentSender.SendIntentException e) {
                // The intent was canceled before it was sent. Return to the
                // default
                // state and attempt to connect to get an updated
                // ConnectionResult.
                mIntentInProgress = false;
                mGoogleApiClient.connect();
            }
        }
    }

    @Override
    public void onConnectionFailed(@NonNull ConnectionResult connectionResult) {
        if (!mIntentInProgress) {
            // Store the ConnectionResult so that we can use it later when the
            // user clicks
            // 'sign-in'.

            mConnectionResult = connectionResult;
            if (mSignInClicked) {
                // The user has already clicked 'sign-in' so we attempt to
                // resolve all

                // errors until the user is signed in, or they cancel.
                resolveSignInError();
            }
        }

    }


    @Override
    public void onStop() {
        super.onStop();
    }
}
