package com.user.gentack.fragment;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.Fragment;
import android.support.v4.content.ContextCompat;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.aurelhubert.simpleratingbar.SimpleRatingBar;
import com.baoyachi.stepview.HorizontalStepView;
import com.baoyachi.stepview.bean.StepBean;
import com.bumptech.glide.Glide;
import com.user.gentack.activity.DetailProfileActivity;
import com.user.gentack.activity.InfoActivity;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapView;
import com.google.android.gms.maps.MapsInitializer;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.CameraPosition;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.user.gentack.R;
import com.user.gentack.activity.ChatActivity;
import com.user.gentack.activity.MainActivity;
import com.user.gentack.custom_interface.AsyncTaskCompleteListener;
import com.user.gentack.model.RequestDetails;
import com.user.gentack.networking.HttpRequester;
import com.user.gentack.utils.AndyUtils;
import com.user.gentack.utils.Const;
import com.user.gentack.utils.LocationHelper;
import com.user.gentack.utils.ParseContent;
import com.user.gentack.utils.PreferenceHelper;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/**
 * Created by user on 3/11/2017.
 */

public class JobMapFragment extends Fragment implements LocationHelper.OnLocationReceived, AsyncTaskCompleteListener, View.OnClickListener, OnMapReadyCallback {

    FloatingActionButton callButton, messageButton, infoButton;
    private MapView jobMapView;
    private MainActivity activity;
    private Bundle mBundle;
    private GoogleMap mGoogleMap;
    private Marker currentMarker, destinationMArker;
    private HorizontalStepView horizontalStepView;
    private Button cancelButton, paynowButton, submitButton;
    private ImageView providerIcon, afterImage, beforeImage;
    private TextView providerName, providerCharge;
    private SimpleRatingBar ratingBar, feedbackRatingBar;
    private EditText reviewEdit;
    private LinearLayout ratingReviewLayout, invoiceLayout;
    private TextView basePrice, totalTime, taxPrice, totalPrice, paymentMode;
    private boolean firstStatus = false, secondStatus = false, thirdStatus = false, forthStatus = false, fifthStatus = false, afterImageStatus = false, beforeImageStatus = false;
    private Bundle requestBundle;
    private RequestDetails requestDetails;
    private List<StepBean> stepsBeanList;


    private Handler reqhandler;
    Runnable runnable = new Runnable() {
        public void run() {
            getIncomingRequestsInProgress();
            reqhandler.postDelayed(this, 4000);
        }
    };

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        activity = (MainActivity) getActivity();
        LocationHelper locationHelper = new LocationHelper(activity);
        locationHelper.setLocationReceivedLister(this);
        reqhandler = new Handler();
        mBundle = savedInstanceState;
        requestBundle = getArguments();
        if (requestBundle != null) {
            requestDetails = (RequestDetails) requestBundle.getSerializable(Const.REQUEST_BUNDLE_DETAIL);
        }
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        activity = (MainActivity) context;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        if (requestDetails.getProviderPhone().equals("")) {
            callButton.setVisibility(View.GONE);
        }
        else {
            callButton.setVisibility(View.VISIBLE);
        }
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_job_map, container, false);
        jobMapView = (MapView) view.findViewById(R.id.jobMapView);
        cancelButton = (Button) view.findViewById(R.id.bn_cancel);
        cancelButton.setOnClickListener(this);
        paynowButton = (Button) view.findViewById(R.id.bn_payNow);
        paynowButton.setOnClickListener(this);
        callButton = (FloatingActionButton) view.findViewById(R.id.btn_floating_call);
        messageButton = (FloatingActionButton) view.findViewById(R.id.btn_floating_message);
        infoButton = (FloatingActionButton) view.findViewById(R.id.btn_floating_info);
        callButton.setOnClickListener(this);
        messageButton.setOnClickListener(this);
        infoButton.setOnClickListener(this);
        totalPrice = (TextView) view.findViewById(R.id.tv_totalPrice);
        taxPrice = (TextView) view.findViewById(R.id.tv_taxPrice);
        totalTime = (TextView) view.findViewById(R.id.tv_toatTime);
        basePrice = (TextView) view.findViewById(R.id.tv_basePrice);
        invoiceLayout = (LinearLayout) view.findViewById(R.id.ll_invoice);
        ratingReviewLayout = (LinearLayout) view.findViewById(R.id.ll_rating_review);
        providerIcon = (ImageView) view.findViewById(R.id.iv_providerIcon);
        providerName = (TextView) view.findViewById(R.id.tv_provider_name);
        providerCharge = (TextView) view.findViewById(R.id.tv_provider_charge);
        horizontalStepView = (HorizontalStepView) view.findViewById(R.id.horizontalStepVIew);
        reviewEdit = (EditText) view.findViewById(R.id.input_feedBack);
        feedbackRatingBar = (SimpleRatingBar) view.findViewById(R.id.feedback_rating);
        paymentMode = (TextView) view.findViewById(R.id.tv_payment_mode);
        ratingBar = (SimpleRatingBar) view.findViewById(R.id.rating);
        submitButton = (Button) view.findViewById(R.id.bn_submit);
        afterImage = (ImageView) view.findViewById(R.id.iv_after_image);
        beforeImage = (ImageView) view.findViewById(R.id.iv_before_image);
        afterImage.setVisibility(View.GONE);
        beforeImage.setVisibility(View.GONE);
        submitButton.setOnClickListener(this);
        activity.headerText.setText(requestDetails.getJobTitle());
        stepsBeanList = new ArrayList<>();
        StepBean stepBean0 = new StepBean(getString(R.string.provider_accepted), -1);
        StepBean stepBean1 = new StepBean(getString(R.string.provider_started), -1);
        StepBean stepBean2 = new StepBean(getString(R.string.provider_arrived), -1);
        StepBean stepBean3 = new StepBean(getString(R.string.provider_service_start), -1);
        StepBean stepBean4 = new StepBean(getString(R.string.provider_service_completed), -1);
        stepsBeanList.add(stepBean0);
        stepsBeanList.add(stepBean1);
        stepsBeanList.add(stepBean2);
        stepsBeanList.add(stepBean3);
        stepsBeanList.add(stepBean4);
        horizontalStepView
                .setStepViewTexts(stepsBeanList)
                .setTextSize(10)//set textSize
                .setStepsViewIndicatorCompletedLineColor(ContextCompat.getColor(getActivity(), R.color.green_color))//设置StepsViewIndicator完成线的颜色
                .setStepsViewIndicatorUnCompletedLineColor(ContextCompat.getColor(getActivity(), R.color.dark_grey))//设置StepsViewIndicator未完成线的颜色
                .setStepViewComplectedTextColor(ContextCompat.getColor(getActivity(), android.R.color.black))//设置StepsView text完成线的颜色
                .setStepViewUnComplectedTextColor(ContextCompat.getColor(getActivity(), android.R.color.black))//设置StepsView text未完成线的颜色
                .setStepsViewIndicatorCompleteIcon(ContextCompat.getDrawable(getActivity(), R.drawable.selected))
                .setStepsViewIndicatorDefaultIcon(ContextCompat.getDrawable(getActivity(), R.drawable.unselected));
        providerIcon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(activity, DetailProfileActivity.class);
                intent.putExtra(Const.Params.PROVIDER_ID, requestDetails.getProviderId());
                startActivity(intent);
            }
        });
        return view;
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);

        try {
            MapsInitializer.initialize(activity);

        } catch (Exception e) {
            e.printStackTrace();
        }

        jobMapView.onCreate(mBundle);

        setUpMap();
        if (requestDetails != null) {
            setDataOnViews(requestDetails);
            setCloseAppStatus(Integer.parseInt(requestDetails.getProviderStatus()));
            if (Integer.parseInt(requestDetails.getProviderStatus()) == 6 && Integer.parseInt(requestDetails.getStatus()) == 5) {

                stopCheckingUpcomingRequests();
                horizontalStepView.setVisibility(View.GONE);
                invoiceLayout.setVisibility(View.VISIBLE);
                cancelButton.setVisibility(View.VISIBLE);
                paynowButton.setVisibility(View.VISIBLE);
                setDataOnInvoiceViews(requestDetails);
                ratingBar.setVisibility(View.GONE);
                providerCharge.setVisibility(View.GONE);

            } else if (Integer.parseInt(requestDetails.getProviderStatus()) == 6 && Integer.parseInt(requestDetails.getStatus()) == 6) {
                stopCheckingUpcomingRequests();
                ratingReviewLayout.setVisibility(View.VISIBLE);
                horizontalStepView.setVisibility(View.GONE);
                submitButton.setVisibility(View.VISIBLE);
                paynowButton.setVisibility(View.GONE);
                ratingBar.setVisibility(View.GONE);
                providerCharge.setVisibility(View.GONE);
            } else if (Integer.parseInt(requestDetails.getProviderStatus()) == 6 && Integer.parseInt(requestDetails.getStatus()) == 7) {
                stopCheckingUpcomingRequests();
                ratingReviewLayout.setVisibility(View.VISIBLE);
                horizontalStepView.setVisibility(View.GONE);
                submitButton.setVisibility(View.VISIBLE);
                paynowButton.setVisibility(View.GONE);
                ratingBar.setVisibility(View.GONE);
                providerCharge.setVisibility(View.GONE);
            } else if (Integer.parseInt(requestDetails.getProviderStatus()) == 7 && Integer.parseInt(requestDetails.getStatus()) == 7) {
                stopCheckingUpcomingRequests();
                ratingReviewLayout.setVisibility(View.VISIBLE);
                horizontalStepView.setVisibility(View.GONE);
                submitButton.setVisibility(View.VISIBLE);
                paynowButton.setVisibility(View.GONE);
                ratingBar.setVisibility(View.GONE);
                providerCharge.setVisibility(View.GONE);
            } else {
                startCheckingUpcomingRequests();
            }


        }


    }

    private void setProviderMarker(RequestDetails requestDetails) {
        if (requestDetails.getProviderLatitude() != null && requestDetails.getProviderLongitude() != null) {
            LatLng latLng = new LatLng(Double.valueOf(requestDetails.getProviderLatitude()), Double.valueOf(requestDetails.getProviderLongitude()));
            if (destinationMArker == null) {
                destinationMArker = mGoogleMap.addMarker(new MarkerOptions().position(latLng).title(requestDetails.getProviderName()).icon(BitmapDescriptorFactory.fromResource(R.drawable.marker_black)));
            } else {
                destinationMArker.setPosition(latLng);
            }
        }
        if (requestDetails.getsLatitude() != null && requestDetails.getsLongitude() != null){
            LatLng latLng = new LatLng(Double.valueOf(requestDetails.getsLatitude()), Double.valueOf(requestDetails.getsLongitude()));
            if (currentMarker == null){
                CameraPosition sourecCameraPosition = CameraPosition.builder()
                                .target(latLng)
                                .zoom(11)
                                .build();
                        mGoogleMap.animateCamera(CameraUpdateFactory.newCameraPosition(sourecCameraPosition));
                currentMarker = mGoogleMap.addMarker(new MarkerOptions().position(latLng).title("Service Location").icon(BitmapDescriptorFactory.fromResource(R.drawable.marker_green)));
            }
            else {
                currentMarker.setPosition(latLng);
            }
        }
    }

    private void setCloseAppStatus(int status) {

        switch (status) {
            case 2:
                stepsBeanList.get(0).setState(1);
                horizontalStepView.setStepViewTexts(stepsBeanList);
                break;
            case 3:
                stepsBeanList.get(0).setState(1);
                stepsBeanList.get(1).setState(1);
                horizontalStepView.setStepViewTexts(stepsBeanList);
                break;
            case 4:
                cancelButton.setBackgroundResource(R.color.background_color);
                cancelButton.setEnabled(false);
                stepsBeanList.get(0).setState(1);
                stepsBeanList.get(1).setState(1);
                stepsBeanList.get(2).setState(1);
                horizontalStepView.setStepViewTexts(stepsBeanList);
                break;
            case 5:
                cancelButton.setBackgroundResource(R.color.background_color);
                cancelButton.setEnabled(false);
                stepsBeanList.get(0).setState(1);
                stepsBeanList.get(1).setState(1);
                stepsBeanList.get(2).setState(1);
                stepsBeanList.get(3).setState(1);
                horizontalStepView.setStepViewTexts(stepsBeanList);
                break;
            case 6:
                stepsBeanList.get(0).setState(1);
                stepsBeanList.get(1).setState(1);
                stepsBeanList.get(2).setState(1);
                stepsBeanList.get(3).setState(1);
                stepsBeanList.get(4).setState(1);
                horizontalStepView.setStepViewTexts(stepsBeanList);
                break;
            default:
        }

    }


    private void setDataOnViews(RequestDetails details) {

        if (details.getProviderStatus().equals("5") && (details.getBeforeImage() != null || !details.getBeforeImage().equals(""))) {
            if (beforeImageStatus == false) {
                beforeImage.setVisibility(View.VISIBLE);
                if (!details.getBeforeImage().equals("")) {
                    Glide.with(activity).load(details.getBeforeImage()).into(beforeImage);
                } else {
//                    beforeImage.setImageResource(R.drawable.before_img);
                }
                beforeImageStatus = true;
            }
        }
        if ((details.getProviderStatus().equals("6") || details.getProviderStatus().equals("7")) && (details.getAfterImage() != null || !details.getAfterImage().equals(""))) {

            if (beforeImageStatus == false) {
                beforeImage.setVisibility(View.VISIBLE);
                if (!details.getBeforeImage().equals("")) {
                    Glide.with(activity).load(details.getBeforeImage()).into(beforeImage);
                } else {
//                    beforeImage.setImageResource(R.drawable.before_img);
                }
                beforeImageStatus = true;
            }
            if (afterImageStatus == false) {
                afterImage.setVisibility(View.VISIBLE);
                if (!details.getAfterImage().equals("")) {
                    Glide.with(activity).load(details.getAfterImage()).into(afterImage);
                } else {
//                    afterImage.setImageResource(R.drawable.after_img);
                }
                afterImageStatus = true;
            }
        }

        if (details.getProviderPicture() != null) {
            Glide.with(activity).load(details.getProviderPicture()).into(providerIcon);
        }
        if (details.getCharges() != null) {
            providerCharge.setText(details.getJobTitle() + " " + "/" + " " + details.getCurrency() + details.getCharges());
        }
        if (details.getProviderName() != null) {
            providerName.setText(details.getProviderName());
        }
        try {

            if (details.getProviderRating().equals("0")) {
                ratingBar.setRating(0);
            } else {
                ratingBar.setRating(Integer.parseInt(String.valueOf((requestDetails.getProviderRating().charAt(0)))));
            }


        } catch (Exception e) {
            e.printStackTrace();
        }


    }


    private void cancelRequest(String id, String reason) {
        if (!AndyUtils.isNetworkAvailable(activity)) {

            return;
        }

        AndyUtils.showSimpleProgressDialog(activity, getString(R.string.please_wait), false);
        HashMap<String, String> map = new HashMap<String, String>();
        map.put(Const.Params.URL, Const.ServiceType.POST_CANCEL_REQUEST_URL);
        map.put(Const.Params.ID, PreferenceHelper.getInstance().getUserId());
        map.put(Const.Params.TOKEN, PreferenceHelper.getInstance().getSessionToken());
        map.put(Const.Params.REQUEST_ID, String.valueOf(id));
        map.put(Const.Params.USER_REASON, "cancel");
        new HttpRequester(activity, Const.POST, map, Const.ServiceCode.POST_CANCEL_REQUEST, this);
    }


    private void startCheckingUpcomingRequests() {
        startCheckRegTimer();
    }

    public void startCheckRegTimer() {
        reqhandler.postDelayed(runnable, 4000);
    }


    private void stopCheckingUpcomingRequests() {
        if (reqhandler != null) {
            reqhandler.removeCallbacks(runnable);

            Log.d("mahi", "stop handler");
        }
    }

    public void getIncomingRequestsInProgress() {
        if (!AndyUtils.isNetworkAvailable(activity)) {

            return;
        }

        HashMap<String, String> map = new HashMap<String, String>();
        map.put(Const.Params.URL, Const.ServiceType.POST_REQUEST_STATUS_CHECK_NOW_URL);
        map.put(Const.Params.ID, PreferenceHelper.getInstance().getUserId());
        map.put(Const.Params.TOKEN, PreferenceHelper.getInstance().getSessionToken());

        new HttpRequester(activity, Const.POST, map, Const.ServiceCode.POST_REQUEST_STATUS_CHECK_NOW, this);

    }

    public void payNow() {
        if (!AndyUtils.isNetworkAvailable(activity)) {

            AndyUtils.showShortToast(getString(R.string.please_wait), activity);
            return;
        }
        AndyUtils.showSimpleProgressDialog(activity, getString(R.string.please_wait), false);
        HashMap<String, String> map = new HashMap<String, String>();
        map.put(Const.Params.URL, Const.ServiceType.POST_PAY_NOW_URL);
        map.put(Const.Params.ID, PreferenceHelper.getInstance().getUserId());
        map.put(Const.Params.TOKEN, PreferenceHelper.getInstance().getSessionToken());
        map.put(Const.Params.REQUEST_ID, String.valueOf(requestDetails.getRequestId()));
        map.put(Const.Params.PAYMENT_MODE, requestDetails.getPaymentMode());
        map.put(Const.Params.IS_PAID, String.valueOf("1"));

        AndyUtils.appLog("Ashutosh", "PayNowMap" + map);
        new HttpRequester(activity, Const.POST, map, Const.ServiceCode.POST_PAY_NOW, this);
    }

    @Override
    public void onResume() {
        super.onResume();
        jobMapView.onResume();
        activity.currentFragment = Const.Params.JOB_MAP_FRAGMENT;

    }

    @Override
    public void onPause() {
        super.onPause();
        jobMapView.onPause();
    }

    private void setUpMap() {
        if (mGoogleMap == null) {
            jobMapView.getMapAsync(new OnMapReadyCallback() {
                @Override
                public void onMapReady(GoogleMap googleMap) {
                    mGoogleMap = googleMap;

                    if (requestDetails != null) {
                        setProviderMarker(requestDetails);
                    }
                }
            });
        }
    }

    @Override
    public void onLocationReceived(LatLng latlong) {

    }

    @Override
    public void onLocationReceived(final Location location) {
//        activity.runOnUiThread(new Runnable() {
//            @Override
//            public void run() {
//                if (location != null) {
//                    AndyUtils.appLog("CurrentLocation", location.toString());
//                    LatLng latLang = new LatLng(location.getLatitude(),
//                            location.getLongitude());
//
//                    if (currentMarker == null) {
//                        CameraPosition sourecCameraPosition = CameraPosition.builder()
//                                .target(latLang)
//                                .zoom(14)
//                                .build();
//                        currentMarker = mGoogleMap.addMarker(new MarkerOptions().position(latLang).title("My Location").icon(BitmapDescriptorFactory.fromResource(R.drawable.marker_green)));
//                        mGoogleMap.animateCamera(CameraUpdateFactory.newCameraPosition(sourecCameraPosition));
//                    } else {
//                        currentMarker.setPosition(latLang);
//                    }
//
//                }
//            }
//        });

    }

    @Override
    public void onConntected(Bundle bundle) {

    }

    @Override
    public void onConntected(Location location) {

    }

    @Override
    public void onTaskCompleted(String response, int serviceCode) {
        switch (serviceCode) {
            case Const.ServiceCode.POST_CANCEL_REQUEST:
                AndyUtils.removeProgressDialog();
                AndyUtils.appLog("Ashutosh", "CancelRequestResponse" + response);
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    if (jsonObject.optString(Const.SUCCESS).equals("true")) {
                        stopCheckingUpcomingRequests();
                        PreferenceHelper.getInstance().putRequestId(Const.NO_REQUEST);
                        AndyUtils.showShortToast("Request cancel successfully", activity);
                        activity.headerText.setText("Category");
                        activity.addFragment(new CategoryFragment(), false, "", "");
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                break;
            case Const.ServiceCode.POST_REQUEST_STATUS_CHECK_NOW:
                AndyUtils.appLog("Ashutosh", "CheckStatusResponse" + response);
                requestDetails = ParseContent.getInstance().parsingRequestInProgress(response);

                if (requestDetails != null) {
                    if (requestDetails.getProviderStatus().equals("5") && (requestDetails.getBeforeImage() != null || !requestDetails.getBeforeImage().equals(""))) {
                        if (beforeImageStatus == false) {
                            beforeImage.setVisibility(View.VISIBLE);
                            if (!requestDetails.getBeforeImage().equals("")) {
                                Glide.with(activity).load(requestDetails.getBeforeImage()).into(beforeImage);
                            } else {
//                                beforeImage.setImageResource(R.drawable.default_user);
                            }
                            beforeImageStatus = true;
                        }
                    }

                    if (requestDetails.getProviderStatus().equals("6") && (requestDetails.getAfterImage() != null || !requestDetails.getAfterImage().equals(""))) {
                        if (afterImageStatus == false) {
                            afterImage.setVisibility(View.VISIBLE);
                            if (!requestDetails.getAfterImage().equals("")) {
                                Glide.with(activity).load(requestDetails.getAfterImage()).into(afterImage);
                            } else {
//                                afterImage.setImageResource(R.drawable.default_user);
                            }
                            afterImageStatus = true;
                        }
                    }
                    setProviderMarker(requestDetails);
                    setStatus(Integer.parseInt(requestDetails.getProviderStatus()));
                    if (Integer.parseInt(requestDetails.getProviderStatus()) == 6) {
                        stopCheckingUpcomingRequests();
                        ratingBar.setVisibility(View.GONE);
                        providerCharge.setVisibility(View.GONE);
                        stopCheckingUpcomingRequests();
                        horizontalStepView.setVisibility(View.GONE);
                        invoiceLayout.setVisibility(View.VISIBLE);
                        cancelButton.setVisibility(View.VISIBLE);
                        paynowButton.setVisibility(View.VISIBLE);
                        setDataOnInvoiceViews(requestDetails);

                    }
                } else {
                    stopCheckingUpcomingRequests();
                    PreferenceHelper.getInstance().putRequestId(Const.NO_REQUEST);
                    AndyUtils.showLongToast("Request Cancelled by provider", activity);
                    Intent intent = new Intent(activity, MainActivity.class);
                    startActivity(intent);
                }

                break;
            case Const.ServiceCode.POST_PAY_NOW:
                AndyUtils.removeProgressDialog();
                AndyUtils.appLog("AShiutos", "PaynowResponse" + response);
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    if (jsonObject.getString(Const.SUCCESS).equals("true")) {
                        stopCheckingUpcomingRequests();
                        AndyUtils.showShortToast("Payment done successfully", activity);
                        invoiceLayout.setVisibility(View.GONE);
                        paynowButton.setVisibility(View.GONE);
                        submitButton.setVisibility(View.VISIBLE);
                        ratingBar.setVisibility(View.GONE);
                        ratingReviewLayout.setVisibility(View.VISIBLE);
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                break;
            case Const.ServiceCode.POST_REQUEST_RATING:
                AndyUtils.removeProgressDialog();
                AndyUtils.appLog("AShiutos", "RatingResponse" + response);
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    if (jsonObject.getString(Const.SUCCESS).equals("true")) {
                        stopCheckingUpcomingRequests();
                        PreferenceHelper.getInstance().putRequestId(Const.NO_REQUEST);
                        AndyUtils.showShortToast("Review done successfully", activity);
                        Intent intent = new Intent(activity, MainActivity.class);
                        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                        startActivity(intent);
                        activity.finish();
                    } else if (jsonObject.optString(Const.SUCCESS).equals("false")) {
                        AndyUtils.showShortToast("Waiting for provider to confirm payment", activity);
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }

        }
    }

    private void setDataOnInvoiceViews(RequestDetails details) {
        totalPrice.setText(" $" + details.getTotalPrice());
        taxPrice.setText("$" + details.getTaxPrice());
        basePrice.setText("$" + details.getBasePrice());
        totalTime.setText(details.getExtraPrice() + "hrs");
        paymentMode.setText(details.getPaymentMode());
    }

    private void setStatus(int status) {
        switch (status) {
            case 2:
                if (firstStatus == false) {
                    stepsBeanList.get(0).setState(1);
                    horizontalStepView.setStepViewTexts(stepsBeanList);
                    firstStatus = true;
                }
                break;
            case 3:
                if (secondStatus == false) {
                    stepsBeanList.get(1).setState(1);
                    horizontalStepView.setStepViewTexts(stepsBeanList);
                    secondStatus = true;
                }
                break;
            case 4:
                if (thirdStatus == false) {
                    cancelButton.setBackgroundResource(R.color.background_color);
                    cancelButton.setEnabled(false);
                    stepsBeanList.get(2).setState(1);
                    horizontalStepView.setStepViewTexts(stepsBeanList);
                    thirdStatus = true;
                }

                break;
            case 5:
                if (forthStatus == false) {
                    cancelButton.setBackgroundResource(R.color.background_color);
                    cancelButton.setEnabled(false);
                    stepsBeanList.get(3).setState(1);
                    horizontalStepView.setStepViewTexts(stepsBeanList);
                    forthStatus = true;
                }
                break;
            case 6:
                if (fifthStatus == false) {
                    stepsBeanList.get(4).setState(1);
                    horizontalStepView.setStepViewTexts(stepsBeanList);
                    fifthStatus = true;
                }

                break;
            default:
        }
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.bn_cancel:
                cancelRequest(requestDetails.getRequestId(), "");
                break;
            case R.id.bn_payNow:
                payNow();
                break;
            case R.id.bn_submit:
                if (feedbackRatingBar.getRating() != 0.0f && requestDetails != null) {
                    AndyUtils.appLog("JobMAp", "FeedBackRating" + feedbackRatingBar.getRating());
                    giveReview(reviewEdit.getText().toString(), feedbackRatingBar.getRating());
                } else {
                    AndyUtils.showShortToast("Please give rating", activity);
                }
                break;
            case R.id.btn_floating_call:

                if (requestDetails.getProviderPhone() != null || !requestDetails.getProviderPhone().equals("")) {
                    Intent intent = new Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + requestDetails.getProviderPhone()));
                    startActivity(intent);
                } else {
                    AndyUtils.showShortToast("Sorry, number is not available", activity);
                }
                break;
            case R.id.btn_floating_message:

                if (requestDetails != null) {
                    Bundle bundle = new Bundle();
                    bundle.putString(Const.Params.REQUEST_ID, requestDetails.getRequestId());
                    bundle.putString(Const.Params.PROVIDER_ID, requestDetails.getProviderId());
                    bundle.putString(Const.Params.NAME, requestDetails.getProviderName());
                    bundle.putString(Const.Params.REQUEST_META_ID, "");
                    bundle.putString(Const.Params.BID_STATUS, "");
                    Intent intent = new Intent(activity, ChatActivity.class);
                    intent.putExtras(bundle);
                    startActivity(intent);
                }
                break;
            case R.id.btn_floating_info:
                if (requestDetails != null) {
                    Intent intent = new Intent(activity, InfoActivity.class);
                    intent.putExtra(Const.Params.REQUEST_ID, requestDetails.getRequestId());
                    startActivity(intent);
                }
                break;
        }
    }

    private void giveReview(String comment, float rating) {
        if (!AndyUtils.isNetworkAvailable(activity)) {

            AndyUtils.showShortToast(getString(R.string.please_wait), activity);
            return;
        }
        AndyUtils.showSimpleProgressDialog(activity, getString(R.string.please_wait), false);
        HashMap<String, String> map = new HashMap<String, String>();
        map.put(Const.Params.URL, Const.ServiceType.POST_REQUEST_RATING_URL);
        map.put(Const.Params.ID, PreferenceHelper.getInstance().getUserId());
        map.put(Const.Params.TOKEN, PreferenceHelper.getInstance().getSessionToken());
        map.put(Const.Params.REQUEST_ID, String.valueOf(requestDetails.getRequestId()));
        map.put(Const.Params.COMMENT, comment);
        map.put(Const.Params.RATING, String.valueOf((int) rating));

        AndyUtils.appLog("Ashutosh", "PayNowMap" + map);
        new HttpRequester(activity, Const.POST, map, Const.ServiceCode.POST_REQUEST_RATING, this);
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        mGoogleMap = googleMap;
        if (mGoogleMap != null){
            mGoogleMap.getUiSettings().setMyLocationButtonEnabled(false);
            mGoogleMap.getUiSettings().setMapToolbarEnabled(true);
            if (ActivityCompat.checkSelfPermission(activity, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(activity, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                // TODO: Consider calling
                //    ActivityCompat#requestPermissions
                // here to request the missing permissions, and then overriding
                //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
                //                                          int[] grantResults)
                // to handle the case where the user grants the permission. See the documentation
                // for ActivityCompat#requestPermissions for more details.
                return;
            }
            mGoogleMap.setMyLocationEnabled(true);
        }
    }
}
