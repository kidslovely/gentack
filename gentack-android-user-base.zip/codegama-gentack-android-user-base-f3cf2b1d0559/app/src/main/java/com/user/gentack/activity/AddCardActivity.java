package com.user.gentack.activity;

import android.app.Activity;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.braintreepayments.api.BraintreePaymentActivity;
import com.braintreepayments.api.PaymentRequest;
import com.braintreepayments.api.models.PaymentMethodNonce;
import com.user.gentack.R;
import com.user.gentack.adapter.GetCardsAdapter;
import com.user.gentack.adapter.RecyclerLongPressClickListener;
import com.user.gentack.custom_interface.AsyncTaskCompleteListener;
import com.user.gentack.model.CardDetails;
import com.user.gentack.networking.HttpRequester;
import com.user.gentack.utils.AndyUtils;
import com.user.gentack.utils.Const;
import com.user.gentack.utils.PreferenceHelper;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class AddCardActivity extends AppCompatActivity implements AsyncTaskCompleteListener {


    private static final int REQUEST_CODE = 133;
    private FloatingActionButton addCardButton;
    private RecyclerView cardRecyclerView;
    private TextView noCardAdded;
    private TextView toolbarHeaderText;
    private ImageView backButton;
    private Toolbar addCardToolbar;
    private List<CardDetails> cardDetailsList;
    private int position = -1;
    private GetCardsAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_card_layout);
        addCardButton = (FloatingActionButton) findViewById(R.id.bn_add_card);
        cardRecyclerView = (RecyclerView) findViewById(R.id.rv_add_card);
        addCardToolbar = (Toolbar) findViewById(R.id.tb_add_card);
        setSupportActionBar(addCardToolbar);
        toolbarHeaderText = (TextView) findViewById(R.id.toolbar_card);
        toolbarHeaderText.setText(getString(R.string.add_card));
        backButton = (ImageView) findViewById(R.id.btn_back_card);
        noCardAdded = (TextView) findViewById(R.id.tv_no_card_added);
        getAddedCard();
        addCardButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getBrainTreeClientToken();
            }
        });
        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

        cardRecyclerView.addOnItemTouchListener(
                new RecyclerLongPressClickListener(this, cardRecyclerView, new RecyclerLongPressClickListener.OnItemClickListener() {
                    @Override
                    public void onItemClick(View view, int position) {


                    }

                    @Override
                    public void onLongItemClick(View view, int position) {

                        AndyUtils.appLog("Ashutosh", "longPress");
                        deleteCardLogoutDialog(position, cardDetailsList.get(position).getCardId());

                    }


                })
        );
    }

    private void deleteCardLogoutDialog(final int position, final String cId) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        String message = "Are you sure you want to delete card?";
        builder.setMessage(message);
        builder.setPositiveButton(getString(R.string.ok), new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
                AddCardActivity.this.position = position;
                deleteCard(cId);
            }
        });

        builder.setNegativeButton(getString(R.string.cancel), new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

            }
        });
        builder.show();
    }

    private void deleteCard(String cId) {
        if (!AndyUtils.isNetworkAvailable(this)) {
            AndyUtils.showLongToast(getString(R.string.no_internet), this);
            return;
        }
        AndyUtils.showSimpleProgressDialog(this, getString(R.string.please_wait), false);
        HashMap<String, String> map = new HashMap<>();
        map.put(Const.Params.URL, Const.ServiceType.POST_CARD_DELETE_URL);
        map.put(Const.Params.ID, PreferenceHelper.getInstance().getUserId());
        map.put(Const.Params.TOKEN, PreferenceHelper.getInstance().getSessionToken());
        map.put(Const.Params.CARD_ID, String.valueOf(cId));

        AndyUtils.appLog("Ashutosh", "GetAddedCardMap" + map);

        new HttpRequester(this, Const.POST, map, Const.ServiceCode.POST_CARD_DELETE, this);


    }


    private void getAddedCard() {
        if (!AndyUtils.isNetworkAvailable(this)) {
            AndyUtils.showLongToast(getString(R.string.no_internet), this);
            return;
        }
        AndyUtils.showSimpleProgressDialog(this, getString(R.string.please_wait), false);
        HashMap<String, String> map = new HashMap<>();
        map.put(Const.Params.URL, Const.ServiceType.GET_ADDED_CARDS_URL);
        map.put(Const.Params.ID, PreferenceHelper.getInstance().getUserId());
        map.put(Const.Params.TOKEN, PreferenceHelper.getInstance().getSessionToken());

        AndyUtils.appLog("Ashutosh", "GetAddedCardMap" + map);

        new HttpRequester(this, Const.POST, map, Const.ServiceCode.GET_ADDED_CARDS, this);


    }


    private void getBrainTreeClientToken() {
        if (!AndyUtils.isNetworkAvailable(this)) {
            AndyUtils.showLongToast(getString(R.string.no_internet), this);
            return;
        }
        AndyUtils.showSimpleProgressDialog(this, getString(R.string.please_wait), false);
        HashMap<String, String> map = new HashMap<>();
        map.put(Const.Params.URL, Const.ServiceType.GET_BRAIN_TREE_TOKEN_URL);
        map.put(Const.Params.ID, PreferenceHelper.getInstance().getUserId());
        map.put(Const.Params.TOKEN, PreferenceHelper.getInstance().getSessionToken());

        AndyUtils.appLog("Ashutosh", "BrainTreeClientTokenMap" + map);

        new HttpRequester(this, Const.POST, map, Const.ServiceCode.GET_BRAIN_TREE_TOKEN, this);


    }

    @Override
    public void onResume() {
        super.onResume();

    }

    @Override
    public void onTaskCompleted(String response, int serviceCode) {
        JSONObject jsonObject;
        AndyUtils.removeProgressDialog();
        switch (serviceCode) {
            case Const.ServiceCode.GET_BRAIN_TREE_TOKEN:
                AndyUtils.appLog("Ashutosh", "BrainTreeClientTokenResponse" + response);
                try {
                    jsonObject = new JSONObject(response);
                    if (jsonObject.getString("success").equals("true")) {
                        String clientToken = jsonObject.optString("client_token");
                        PaymentRequest paymentRequest = new PaymentRequest()
                                .clientToken(clientToken)
                                .submitButtonText("Add");
                        startActivityForResult(paymentRequest.getIntent(this), REQUEST_CODE);

                    }


                } catch (JSONException e) {
                    e.printStackTrace();
                }
                break;
            case Const.ServiceCode.CREATE_ADD_CARD:
                AndyUtils.appLog("Ashutosh", "BrainTreeClientTokenResponse" + response);
                try {
                    jsonObject = new JSONObject(response);
                    if (jsonObject.getString("success").equals("true")) {

                        AndyUtils.showShortToast(getString(R.string.card_added), this);
                        getAddedCard();

                    }


                } catch (JSONException e) {
                    e.printStackTrace();
                }
                break;
            case Const.ServiceCode.GET_ADDED_CARDS:
                AndyUtils.appLog("Ashutosh", "GetAddedCardResponse" + response);
                try {


                    jsonObject = new JSONObject(response);
                    if (jsonObject.getString("success").equals("true")) {
                        JSONArray jsonArray = jsonObject.optJSONArray("card");
                        if (jsonArray != null && jsonArray.length() > 0) {
                            cardDetailsList = new ArrayList<>();
                            for (int i = 0; i < jsonArray.length(); i++) {
                                JSONObject cardObject = jsonArray.getJSONObject(i);
                                CardDetails cardDetails = new CardDetails();
                                cardDetails.setCardId(cardObject.optString("id"));
                                cardDetails.setCardNumber(cardObject.optString("last_four"));
                                cardDetails.setIsDefault(cardObject.optString("is_default"));
                                cardDetails.setType(cardObject.optString("card_type"));
                                cardDetails.setCustomerId(cardObject.optString("customer_id"));
                                cardDetailsList.add(cardDetails);
                            }

                            LinearLayoutManager layoutManager = new LinearLayoutManager(this);
                            cardRecyclerView.setLayoutManager(layoutManager);
                            adapter = new GetCardsAdapter(this, cardDetailsList);
                            cardRecyclerView.setAdapter(adapter);
                            noCardAdded.setVisibility(View.GONE);
                        } else noCardAdded.setVisibility(View.VISIBLE);


                    } else {
                        noCardAdded.setVisibility(View.VISIBLE);
                        AndyUtils.showShortToast(jsonObject.getString("error_message"), this);
                    }


                } catch (JSONException e) {
                    e.printStackTrace();
                }
                break;
            case Const.ServiceCode.POST_CARD_DELETE:
                AndyUtils.removeProgressDialog();
                AndyUtils.appLog("AddCardActivity", "DeleteCardResponse" + response);
                try {
                    JSONObject jsonObject1 = new JSONObject(response);
                    if (jsonObject1.optString(Const.SUCCESS).equals(Const.TRUE)) {
                        removeCardFromList();
                        AndyUtils.showShortToast(getString(R.string.card_deleted), AddCardActivity.this);
                    }
                    else {
                        AndyUtils.showShortToast(jsonObject1.optString("error"), this);
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }


        }

    }

    private void removeCardFromList() {
        cardDetailsList.remove(position);
        adapter.notifyItemRemoved(position);
        adapter.notifyItemRangeChanged(position, cardDetailsList.size());
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {

        if (requestCode == REQUEST_CODE) {
            if (resultCode == Activity.RESULT_OK) {
                PaymentMethodNonce paymentMethodNonce = data.getParcelableExtra(
                        BraintreePaymentActivity.EXTRA_PAYMENT_METHOD_NONCE);
                String nonce = paymentMethodNonce.getNonce();
                // Send the nonce to your server.
                postNonceToServer(nonce);
            }
        }
    }

    void postNonceToServer(String nonce) {
        if (!AndyUtils.isNetworkAvailable(this)) {
            AndyUtils.showLongToast(getString(R.string.no_internet), this);
            return;
        }
        AndyUtils.showSimpleProgressDialog(this, getString(R.string.please_wait), false);
        HashMap<String, String> map = new HashMap<>();
        map.put(Const.Params.URL, Const.ServiceType.CREATE_ADD_CARD_URL);
        map.put(Const.Params.ID, PreferenceHelper.getInstance().getUserId());
        map.put(Const.Params.TOKEN, PreferenceHelper.getInstance().getSessionToken());
        map.put(Const.Params.PAYMENT_METHOD_NONCE, nonce);

        AndyUtils.appLog("Ashutosh", "BrainTreeADDCARDMap" + map);

        new HttpRequester(this, Const.POST, map, Const.ServiceCode.CREATE_ADD_CARD, this);

    }

    @Override
    public void onBackPressed() {
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
        finish();
    }
}
