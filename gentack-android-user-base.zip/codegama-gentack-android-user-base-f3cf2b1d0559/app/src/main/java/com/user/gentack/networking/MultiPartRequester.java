package com.user.gentack.networking;

import android.content.Context;
import android.util.Log;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.user.gentack.app.AppController;
import com.user.gentack.custom_interface.AsyncTaskCompleteListener;
import com.user.gentack.model.ResponseHandler;
import com.user.gentack.utils.AndyUtils;
import com.user.gentack.utils.Const;


import org.greenrobot.eventbus.EventBus;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.Map;

/**
 * Created by user on 7/7/2015.
 */
public class MultiPartRequester {

    Context activity;
    private AsyncTaskCompleteListener asyncTaskCompleteListener;
    int service_code;


    public MultiPartRequester(Context activity, Map<String, String> map, int service_code, AsyncTaskCompleteListener asyncTaskCompleteListener) {

        this.activity = activity;
        this.service_code = service_code;
        this.asyncTaskCompleteListener = asyncTaskCompleteListener;
        String url = map.get(Const.Params.URL);
        map.remove(Const.Params.URL);
        multipart_volley_requester(url, map);
    }

    void multipart_volley_requester(String url, Map<String, String> map) {

        MultipartRequest mr = new MultipartRequest(url, new Response.ErrorListener() {

            @Override
            public void onErrorResponse(VolleyError error) {
                Log.d("Ashutosh", error.toString());
                String msg = "No network connection.Please check your internet";
                AndyUtils.showLongToast(msg,activity);
                AndyUtils.removeProgressDialog();
            }

        }, new Response.Listener<String>() {

            @Override
            public void onResponse(String response)
            {
                AndyUtils.appLog("Ashutosh","MultipartRequesterResponse" +response);
                responseHandling(response);
                asyncTaskCompleteListener.onTaskCompleted(response.toString(), service_code);
            }

        }, map);

        mr.setRetryPolicy(new DefaultRetryPolicy(Const.TIMEOUT,
                Const.MAX_RETRY,
                Const.DEFAULT_BACKOFF_MULT));
        AppController.getInstance().addToRequestQueue(mr);
    }

    private void responseHandling(String response){
        try {
            JSONObject res = new JSONObject(response);
            if (res.optInt("error_code") == 103 || res.optInt("error_code") == 104
                    || res.optInt("error_code") == 502 || res.optInt("error_code") == 503
                    || res.optInt("error_code") == 504) {
                EventBus.getDefault().post(new ResponseHandler(true, res.optString("error")));
            }
        }
        catch (JSONException e){
            e.printStackTrace();
        }
    }
}
