package com.user.gentack.activity;

import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import com.user.gentack.R;
import com.user.gentack.adapter.ChatAdapter;
import com.user.gentack.custom_interface.AsyncTaskCompleteListener;
import com.user.gentack.model.ChatObject;
import com.user.gentack.networking.HttpRequester;
import com.user.gentack.utils.AndyUtils;
import com.user.gentack.utils.Const;
import com.user.gentack.utils.PreferenceHelper;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import io.socket.client.IO;
import io.socket.client.Socket;
import io.socket.emitter.Emitter;


/**
 * Created by user on 2/18/2017.
 */

public class ChatActivity extends AppCompatActivity implements AsyncTaskCompleteListener {
    ChatAdapter messageAdapter;
//    DatabaseHandler db;
    private Toolbar chatToolbar;
    private ListView chat_lv;
    private ImageView btn_send, chat_back;
    private List<ChatObject> messages;
    private Socket mSocket;
    private TextView headerText;
    private Boolean isConnected = true;
    private EditText et_message;
    private String reciver_id = "", requestId = "", reqiestMetaId, lastMessage = "", bid_status = "";
    private Button confirmButton;
    private Emitter.Listener onConnect = new Emitter.Listener() {
        @Override
        public void call(Object... args) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    if (!isConnected) {

                        try {

                            JSONObject object = new JSONObject();
                            object.put("myid", "up" + PreferenceHelper.getInstance().getUserId());
                            object.put("reqid", requestId);
                            Log.e("update_object", "" + object);
                            mSocket.emit("update sender", object);

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }


                        isConnected = true;
                    }
                    if (isConnected) {


                        try {

                            JSONObject object = new JSONObject();
                            object.put("myid", "up" + PreferenceHelper.getInstance().getUserId());
                            object.put("reqid", requestId);
                            Log.e("update_object", "" + object);
                            mSocket.emit("update sender", object);

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }


                    }
                }
            });
        }
    };
    private Emitter.Listener onDisconnect = new Emitter.Listener() {
        @Override
        public void call(Object... args) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    isConnected = false;
                    JSONObject messageObj = new JSONObject();
                    try {
                        messageObj.put("user_id", PreferenceHelper.getInstance().getUserId());

                        messageObj.put("provider_id", reciver_id);
                        messageObj.put("type", "up");
                        messageObj.put("reqid", requestId);

                        Log.e("mahi", "message socket in chat" + messageObj.toString());
                        mSocket.emit("update push", messageObj);

                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }
            });
        }
    };
    private Emitter.Listener onConnectError = new Emitter.Listener() {
        @Override
        public void call(Object... args) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {

                }
            });
        }
    };
    private Emitter.Listener onNewMessage = new Emitter.Listener() {
        @Override
        public void call(final Object... args) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    JSONObject data = (JSONObject) args[0];

                    String type;
                    String data_type;
                    String message, stat;
                    try {
                        stat = data.getString("type");
                        type = data.getString("status");
                        data_type = data.getString("data_type");
                        message = data.getString("message");
                      /*  if(stat.equals("pu")) {

                        } else {
                            showChat("sent", data_type, message);
                        }*/
                        showChat("receive", data_type, message);
                        // showChat(type, data_type, message);
                        Log.d("mahi", "new message recive" + message);
                        pingCall(PreferenceHelper.getInstance().getUserId(), data.getString(Const.Params.PROVIDER_ID), stat, requestId);
                    } catch (JSONException e) {
                        return;
                    }


                }
            });
        }
    };
    private Emitter.Listener onUserJoined = new Emitter.Listener() {
        @Override
        public void call(final Object... args) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    JSONObject data = (JSONObject) args[0];
                    String username;
                    int numUsers;
                    try {
                        username = data.getString("username");
                        numUsers = data.getInt("numUsers");
                    } catch (JSONException e) {
                        return;
                    }
/*
                    addLog(getResources().getString(R.string.message_user_joined, username));
                    addParticipantsLog(numUsers);*/
                }
            });
        }
    };
    private Emitter.Listener onUserLeft = new Emitter.Listener() {
        @Override
        public void call(final Object... args) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    JSONObject data = (JSONObject) args[0];
                    String username;
                    int numUsers;
                    try {
                        username = data.getString("username");
                        numUsers = data.getInt("numUsers");
                    } catch (JSONException e) {
                        return;
                    }

                }
            });
        }
    };
    private Emitter.Listener onTyping = new Emitter.Listener() {
        @Override
        public void call(final Object... args) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    JSONObject data = (JSONObject) args[0];
                    String username;
                    try {
                        username = data.getString("username");
                    } catch (JSONException e) {
                        return;
                    }

                }
            });
        }
    };
    private Emitter.Listener onStopTyping = new Emitter.Listener() {
        @Override
        public void call(final Object... args) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    JSONObject data = (JSONObject) args[0];
                    String username;
                    try {
                        username = data.getString("username");
                    } catch (JSONException e) {
                        return;
                    }

                }
            });
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
        setContentView(R.layout.chat_layout);

//        db = new DatabaseHandler(this);
        chatToolbar = (Toolbar) findViewById(R.id.toolbar_chat);
        headerText = (TextView) findViewById(R.id.toolbar_profile);
        chat_back = (ImageView) findViewById(R.id.btn_back_chat);
        chat_lv = (ListView) findViewById(R.id.chat_lv);
        et_message = (EditText) findViewById(R.id.et_message);
        btn_send = (ImageView) findViewById(R.id.btn_send);
        confirmButton = (Button) findViewById(R.id.bn_confirm);
        setSupportActionBar(chatToolbar);
        getSupportActionBar().setTitle(null);
        Bundle bundle = getIntent().getExtras();
        if (bundle != null) {
            reciver_id = bundle.getString(Const.Params.PROVIDER_ID);
            requestId = bundle.getString(Const.Params.REQUEST_ID);
            reqiestMetaId = bundle.getString(Const.Params.REQUEST_META_ID);
            bid_status = bundle.getString(Const.Params.BID_STATUS);
            headerText.setText(bundle.getString(Const.Params.NAME));
            initiateSokect();
        }

        if (reqiestMetaId.equals("")) {
            confirmButton.setVisibility(View.GONE);
        }

        if (!bid_status.equals("") && bid_status.equals("3")) {
            confirmButton.setEnabled(false);
            confirmButton.setText("Waiting for final bid amount");
        }
        loadMessages();
        messages = new ArrayList<>();
        messageAdapter = new ChatAdapter(getApplicationContext(), R.layout.list_item_chat_message, messages);
        chat_lv.setAdapter(messageAdapter);
        btn_send.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (et_message.getText().toString().length() == 0) {
                    AndyUtils.showShortToast("Please Enter Message before send", getApplicationContext());
                    et_message.requestFocus();
                } else {
                    if (mSocket.connected()) {
                        lastMessage = et_message.getText().toString();
                        attemptSend(et_message.getText().toString());
                        // AndyUtils.hideKeyBoard(getApplicationContext());
                        et_message.setText("");

                    }
                }

            }
        });
        chat_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });

        confirmButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showBidDialog();
            }
        });
    }

    private void pingCall(String user_id, String provider_id, String type, String request_id){
        HashMap<String, String > map = new HashMap<String, String>();
        map.put(Const.Params.URL, Const.ServiceType.HOST_URL + "/message/update/status");
        map.put(Const.Params.USER_ID, user_id);
        map.put(Const.Params.PROVIDER_ID, provider_id);
        map.put("type", type);
        map.put(Const.Params.REQUEST_ID, request_id);
        Log.e("PING CALL", map.toString());
        new HttpRequester(ChatActivity.this, Const.POST, map, 100, this);
    }

    private void loadMessages(){
        HashMap<String, String> map = new HashMap<String, String>();
        map.put(Const.Params.URL, Const.ServiceType.GET_MESSAGES);
        map.put(Const.Params.ID, PreferenceHelper.getInstance().getUserId());
        map.put(Const.Params.TOKEN, PreferenceHelper.getInstance().getSessionToken());
        map.put(Const.Params.REQUEST_ID, requestId);
        map.put(Const.Params.PROVIDER_ID, reciver_id);
        AndyUtils.appLog("ChatMap", "ChatMessagesRequestMap" + map);
        AndyUtils.showSimpleProgressDialog(this, "Loading", false);
        new HttpRequester(this, Const.POST, map, Const.ServiceCode.GET_MESSAGES_CODE, this);
    }

    private void showBidDialog() {
        final Dialog dialog = new Dialog(this, R.style.DialogTheme);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.dialog_payment_bid);
        final EditText bidEdit = (EditText) dialog.findViewById(R.id.et_bid);
        Button bid = (Button) dialog.findViewById(R.id.bn_bid);
        bid.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (bidEdit.getText().toString().length() == 0) {
                    AndyUtils.showShortToast("Please enter your bid amount", ChatActivity.this);
                } else {
                    dialog.cancel();
                    confirmBidAmount(bidEdit.getText().toString());

                }
            }
        });
        dialog.show();
    }


    private void confirmBidAmount(String amt) {
        if (!AndyUtils.isNetworkAvailable(this)) {
            AndyUtils.showShortToast(getString(R.string.no_internet), this);
            return;
        }
        AndyUtils.showSimpleProgressDialog(this, getString(R.string.please_wait), false);
        HashMap<String, String> map = new HashMap<String, String>();
        map.put(Const.Params.URL, Const.ServiceType.POST_ASSIGN_REQUEST_URL);
        map.put(Const.Params.ID, PreferenceHelper.getInstance().getUserId());
        map.put(Const.Params.TOKEN, PreferenceHelper.getInstance().getSessionToken());
        map.put(Const.Params.PRICE_PER_HOUR, String.valueOf(amt));
        map.put(Const.Params.REQUEST_ID, requestId);
        map.put(Const.Params.REQUEST_META_ID, reqiestMetaId);


        AndyUtils.appLog("Ashutosh", "AssignRequestMap" + map);
        new HttpRequester(this, Const.POST, map, Const.ServiceCode.POST_ASSIGN_REQUEST, this);
    }

    private void attemptSend(String message) {
        if (!mSocket.connected()) return;

        JSONObject messageObj = new JSONObject();
        try {
            messageObj.put("message", message);
            messageObj.put("user_id", PreferenceHelper.getInstance().getUserId());

            messageObj.put("provider_id", reciver_id);
            messageObj.put("type", "up");
            messageObj.put("data_type", "TEXT");
            messageObj.put("status", "sent");
            messageObj.put("reqid", requestId);

            Log.e("mahi", "message socket in chat" + messageObj.toString());
            showChat("sent", "TEXT", message);
            mSocket.emit("send message", messageObj);

        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    private void initiateSokect() {

        try {
            mSocket = IO.socket(Const.ServiceType.SOCKET_URL);
        } catch (URISyntaxException e) {
            throw new RuntimeException(e);
        }

        mSocket.on(Socket.EVENT_CONNECT, onConnect);
        mSocket.on(Socket.EVENT_DISCONNECT, onDisconnect);
        mSocket.on(Socket.EVENT_CONNECT_ERROR, onConnectError);
        mSocket.on(Socket.EVENT_CONNECT_TIMEOUT, onConnectError);
        mSocket.on("message", onNewMessage);
        mSocket.on("user joined", onUserJoined);
        mSocket.on("user left", onUserLeft);
        mSocket.on("typing", onTyping);
        mSocket.on("stop typing", onStopTyping);
        mSocket.connect();
    }

    @Override
    public void onTaskCompleted(String response, int serviceCode) {
        switch (serviceCode) {
            case Const.ServiceCode.POST_ASSIGN_REQUEST:
                AndyUtils.removeProgressDialog();
                AndyUtils.appLog("ChatActivity", "AssignRequestResponse" + response);
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    if (jsonObject.optString(Const.SUCCESS).equals(Const.TRUE)) {
                        AndyUtils.showLongToast("Bid confirmed successfully", this);
                        Intent intent = new Intent(this, JobActivity.class);
                        startActivity(intent);
                        finish();
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                break;
            case Const.ServiceCode.GET_MESSAGES_CODE:
                AndyUtils.removeProgressDialog();
                AndyUtils.appLog("CHAT_MESSAGES", response);
                try {
                    JSONObject object = new JSONObject(response);
                    if (object.optString("success").equalsIgnoreCase("true")){
                        JSONArray data = object.getJSONArray("data");
                        if (data.length() > 0) {
                            for (int i = 0; i < data.length(); i++){
                                JSONObject chatObj = data.getJSONObject(i);
                                ChatObject chat = new ChatObject(
                                        chatObj.optString("message"),
                                        chatObj.optString("type").equals("up") ? "sent" : "receive",
                                        "TEXT",
                                        requestId,
                                        PreferenceHelper.getInstance().getUserId(),
                                        reciver_id
                                );
                                messages.add(chat);
                            }
                            messageAdapter.notifyDataSetChanged();
                        }
                    }
                }
                catch (JSONException e){
                    e.printStackTrace();
                }
        }

    }

    private void showChat(String type, String data_type, String message) {

//        if (messages == null || messages.size() == 0) {
//
//            messages = new ArrayList<ChatObject>();
//        }

        messages.add(new ChatObject(message, type, data_type, ""
                + requestId, PreferenceHelper.getInstance().getUserId(), reciver_id));

        ChatAdapter chatAdabter = new ChatAdapter(ChatActivity.this, R.layout.list_item_chat_message, messages);
        chat_lv.setAdapter(chatAdabter);
        // chatAdabter.notifyDataSetChanged();
        //  if (type.equals("sent")) {
//        ChatObject chat = new ChatObject(message, type, data_type, ""
//                + requestId, PreferenceHelper.getInstance().getUserId(), reciver_id);

        //     db.insertChat(chat);
        //   }

        // chatAdabter.notifyDataSetChanged();

    }

  /*  private Runnable onTypingTimeout = new Runnable() {
        @Override
        public void run() {
            if (!mTyping) return;

            mTyping = false;
            mSocket.emit("stop typing");
        }
    };*/

    @Override
    public void onPause() {
        super.onPause();

    }

    @Override
    public void onStop() {
        super.onStop();

    }

    @Override
    public void onDestroy() {
        super.onDestroy();

        mSocket.disconnect();

        mSocket.off(Socket.EVENT_CONNECT, onConnect);
        mSocket.off(Socket.EVENT_DISCONNECT, onDisconnect);
        mSocket.off(Socket.EVENT_CONNECT_ERROR, onConnectError);
        mSocket.off(Socket.EVENT_CONNECT_TIMEOUT, onConnectError);
        mSocket.off("message", onNewMessage);
        mSocket.off("user joined", onUserJoined);
        mSocket.off("user left", onUserLeft);
        mSocket.off("typing", onTyping);
        mSocket.off("stop typing", onStopTyping);
    }
}
