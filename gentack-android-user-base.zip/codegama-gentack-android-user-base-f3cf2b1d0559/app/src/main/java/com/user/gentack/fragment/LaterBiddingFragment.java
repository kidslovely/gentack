package com.user.gentack.fragment;

import android.app.Dialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.app.Fragment;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.aurelhubert.simpleratingbar.SimpleRatingBar;
import com.bumptech.glide.Glide;
import com.user.gentack.R;
import com.user.gentack.activity.MainActivity;
import com.user.gentack.adapter.ProviderUserRatingAdapter;
import com.user.gentack.adapter.SelectBiddingAdapter;
import com.user.gentack.custom_interface.AsyncTaskCompleteListener;
import com.user.gentack.model.BiddingProviderDetails;
import com.user.gentack.model.BiddingRequestDetails;
import com.user.gentack.model.RequestDetails;
import com.user.gentack.networking.HttpRequester;
import com.user.gentack.utils.AndyUtils;
import com.user.gentack.utils.Const;
import com.user.gentack.utils.ParseContent;
import com.user.gentack.utils.PreferenceHelper;
import com.user.gentack.utils.RecyclerViewItemClickListener;
import com.user.gentack.utils.VerticalSpaceItemDecoration;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/**
 * Created by user on 4/2/2017.
 */

public class LaterBiddingFragment extends Fragment implements View.OnClickListener, AsyncTaskCompleteListener {

    private static final String TAG = LaterBiddingFragment.class.getSimpleName();
    private static final int All_REQUEST_TYPE = 2;
    private static final int SELECT_REQUEST_TYPE = 3;
    private static final int LOCATION_REQUEST_TYPE = 1;
    private Dialog providerDetailDialog;
    private TextView noJob, headerText, allText, selectText, locationText;
    private ProgressBar biddingProgressBar;
    private RecyclerView biddingRecyclerView;
    private Button bidNow;
    private MainActivity activity;
    private BiddingRequestDetails biddingRequestDetails;
    private Bundle bundle;
    private List<RequestDetails> requestDetailsList;
    private int requestType = 2;
    private String providerId = "";

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        bundle = getArguments();
        if (bundle != null) {
            biddingRequestDetails = (BiddingRequestDetails) bundle.getSerializable(Const.REQUEST_BUNDLE_DETAIL);
        }


    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_bidding_layout, container, false);
        activity = (MainActivity) getActivity();
        allText = (TextView) view.findViewById(R.id.tv_bid_all);
        selectText = (TextView) view.findViewById(R.id.tv_bid_select);
        locationText = (TextView) view.findViewById(R.id.tv_bid_location);
        headerText = (TextView) view.findViewById(R.id.tv_bid_desc);
        allText.setBackgroundResource(R.color.dark_grey);
        headerText.setVisibility(View.VISIBLE);
        headerText.setText(getString(R.string.bid_send_all));
        bidNow = (Button) view.findViewById(R.id.bn_bid_now);
        biddingProgressBar = (ProgressBar) view.findViewById(R.id.biddingProgressbar);
        biddingRecyclerView = (RecyclerView) view.findViewById(R.id.rv_bidding);
        bidNow.setOnClickListener(this);
        allText.setOnClickListener(this);
        selectText.setOnClickListener(this);
        locationText.setOnClickListener(this);


        biddingRecyclerView.addOnItemTouchListener(new RecyclerViewItemClickListener(activity, new RecyclerViewItemClickListener.OnItemClickListener() {
            @Override
            public void onItemClick(View view, int position) {
                getProviderProfileAndRatings(requestDetailsList.get(position).getProviderId(), requestDetailsList.get(position).getTempReqId());
            }
        }));
        return view;
    }


    private void getProviderProfileAndRatings(String pId, String tempRequestId) {
        if (!AndyUtils.isNetworkAvailable(activity)) {

            AndyUtils.showShortToast(getString(R.string.no_internet), activity);
            return;
        }

        AndyUtils.showSimpleProgressDialog(activity, getString(R.string.please_wait), false);
        HashMap<String, String> map = new HashMap<String, String>();
        map.put(Const.Params.URL, Const.ServiceType.POST_PROVIDER_DETAIL_URL);
        map.put(Const.Params.ID, PreferenceHelper.getInstance().getUserId());
        map.put(Const.Params.TOKEN, PreferenceHelper.getInstance().getSessionToken());
        map.put(Const.Params.TEMP_REQUEST_ID, tempRequestId);
        map.put(Const.Params.REQUEST_ID, "");
        map.put(Const.Params.PROVIDER_ID, String.valueOf(pId));

        AndyUtils.appLog(TAG, "PostProviderDetailMap" + map);
        new HttpRequester(activity, Const.POST, map, Const.ServiceCode.POST_PROVIDER_DETAIL, this);
    }


    @Override
    public void onClick(View view) {

        switch (view.getId()) {

            case R.id.tv_bid_all:
                providerId = "";
                allText.setBackgroundResource(R.color.dark_grey);
                selectText.setBackgroundResource(R.color.background_color);
                locationText.setBackgroundResource(R.color.background_color);
                biddingRecyclerView.setVisibility(View.GONE);
                headerText.setVisibility(View.VISIBLE);
                biddingProgressBar.setVisibility(View.GONE);
                headerText.setText(getString(R.string.bid_send_all));
                bidNow.setVisibility(View.VISIBLE);
                requestType = All_REQUEST_TYPE;
                break;
            case R.id.tv_bid_select:
                getAllProviders();
                allText.setBackgroundResource(R.color.background_color);
                selectText.setBackgroundResource(R.color.dark_grey);
                locationText.setBackgroundResource(R.color.background_color);
                biddingRecyclerView.setVisibility(View.VISIBLE);
                headerText.setVisibility(View.GONE);
                bidNow.setVisibility(View.GONE);
                requestType = SELECT_REQUEST_TYPE;
                break;
            case R.id.tv_bid_location:
                providerId = "";
                allText.setBackgroundResource(R.color.background_color);
                selectText.setBackgroundResource(R.color.background_color);
                locationText.setBackgroundResource(R.color.dark_grey);
                biddingRecyclerView.setVisibility(View.GONE);
                headerText.setVisibility(View.VISIBLE);
                headerText.setText(getString(R.string.bid_send_near_location));
                bidNow.setVisibility(View.VISIBLE);
                biddingProgressBar.setVisibility(View.GONE);
                requestType = LOCATION_REQUEST_TYPE;
                break;
            case R.id.bn_bid_now:
                showBidDialog("");
                break;

        }

    }

    private void getAllProviders() {
        if (!AndyUtils.isNetworkAvailable(activity)) {

            AndyUtils.showShortToast(getString(R.string.no_internet), activity);
            return;
        }

        biddingProgressBar.setVisibility(View.VISIBLE);
        HashMap<String, String> map = new HashMap<String, String>();
        map.put(Const.Params.URL, Const.ServiceType.POST_GET_ALL_PROVIDERS_URL);
        map.put(Const.Params.ID, PreferenceHelper.getInstance().getUserId());
        map.put(Const.Params.TOKEN, PreferenceHelper.getInstance().getSessionToken());
        map.put(Const.Params.TEMP_REQUEST_ID, PreferenceHelper.getInstance().getRegistrationID());

        AndyUtils.appLog(TAG, "GetProviderMap" + map);
        new HttpRequester(activity, Const.POST, map, Const.ServiceCode.POST_GET_ALL_PROVIDERS, this);
    }

    private void showBidDialog(final String pId) {
        final Dialog dialog = new Dialog(activity, R.style.DialogTheme);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.dialog_payment_bid);
        final EditText bidEdit = (EditText) dialog.findViewById(R.id.et_bid);
        Button bid = (Button) dialog.findViewById(R.id.bn_bid);
        bid.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (bidEdit.getText().toString().length() == 0) {
                    AndyUtils.showShortToast("Please enter your bid amount", activity);
                } else {
                    dialog.cancel();
                    saveDraftRequest(bidEdit.getText().toString(), pId);
                }
            }
        });
        dialog.show();
    }

    private void saveDraftRequest(String bidAmount, String pId) {

        if (!AndyUtils.isNetworkAvailable(activity)) {

            AndyUtils.showShortToast(getString(R.string.no_internet), activity);
            return;
        }
        AndyUtils.showSimpleProgressDialog(activity, getString(R.string.please_wait), false);

        HashMap<String, String> map = new HashMap<>();
        map.put(Const.Params.URL, Const.ServiceType.POST_DRAFTS_REQUEST_URL);
        map.put(Const.Params.ID, PreferenceHelper.getInstance().getUserId());
        map.put(Const.Params.TOKEN, PreferenceHelper.getInstance().getSessionToken());
        map.put(Const.Params.JOB_TYPE, String.valueOf("2"));
        map.put(Const.Params.SUB_CATEGORY_ID, biddingRequestDetails.getSubCategoryId());
        map.put(Const.Params.REQUEST_TYPE, String.valueOf(requestType));
        map.put(Const.Params.CATEGORY_ID, biddingRequestDetails.getCategoryId());
        map.put(Const.Params.S_ADDRESS, biddingRequestDetails.getAddress());
        map.put(Const.Params.S_LATITUDE, String.valueOf(biddingRequestDetails.getLatitude()));
        map.put(Const.Params.S_LONGITUDE, String.valueOf(biddingRequestDetails.getLongitude()));
        map.put(Const.Params.NAME, biddingRequestDetails.getJobTitle());
        map.put(Const.Params.DESCRIPTION, biddingRequestDetails.getDescription());
        map.put(Const.Params.NOTE, biddingRequestDetails.getNote());
        map.put(Const.Params.USER_PRICE, String.valueOf(bidAmount));
        map.put(Const.Params.TEMP_REQUEST_ID, PreferenceHelper.getInstance().getRegistrationID());
        map.put(Const.Params.PROVIDER_ID, String.valueOf(pId));
        map.put(Const.Params.REQUEST_DATE, biddingRequestDetails.getRequestDateTime());
        AndyUtils.appLog("Ashutosh", "DraftsBiddingMap" + map);


        new HttpRequester(activity, Const.POST, map, Const.ServiceCode.POST_DRAFTS_REQUEST, this);
    }


    private void createJobRequestLater(String bidAmount, String providerId, String tempReqId) {
        if (!AndyUtils.isNetworkAvailable(activity)) {
            AndyUtils.showShortToast(getString(R.string.no_internet), activity);
            return;
        }

        HashMap<String, String> map = new HashMap<>();
        map.put(Const.Params.URL, Const.ServiceType.POST_REQUEST_LATER_URL);
        map.put(Const.Params.ID, PreferenceHelper.getInstance().getUserId());
        map.put(Const.Params.TOKEN, PreferenceHelper.getInstance().getSessionToken());
        map.put(Const.Params.S_ADDRESS, biddingRequestDetails.getAddress());
        map.put(Const.Params.S_LATITUDE, String.valueOf(biddingRequestDetails.getLatitude()));
        map.put(Const.Params.S_LONGITUDE, String.valueOf(biddingRequestDetails.getLongitude()));
        map.put(Const.Params.NAME, biddingRequestDetails.getJobTitle());
        map.put(Const.Params.DESCRIPTION, biddingRequestDetails.getDescription());
        map.put(Const.Params.NOTE, biddingRequestDetails.getNote());
        map.put(Const.Params.USER_PRICE, String.valueOf(bidAmount));
        map.put(Const.Params.TEMP_REQUEST_ID, tempReqId);
        map.put(Const.Params.REQUEST_DATE, biddingRequestDetails.getRequestDateTime());
        map.put(Const.Params.PROVIDER_ID, String.valueOf(providerId));
        map.put(Const.Params.REQUEST_TYPE, String.valueOf(requestType));


        AndyUtils.appLog("Ashutosh", "JobLaterRequestMap" + map);

        new HttpRequester(activity, Const.POST, map, Const.ServiceCode.POST_REQUEST_LATER, this);

    }


    @Override
    public void onTaskCompleted(String response, int serviceCode) {
        switch (serviceCode) {
            case Const.ServiceCode.POST_GET_ALL_PROVIDERS:
                biddingProgressBar.setVisibility(View.GONE);
                AndyUtils.appLog(TAG, "AllProviderResponse" + response);
                try {

                    if (requestDetailsList != null) {
                        requestDetailsList.clear();
                    }
                    JSONObject jsonObject = new JSONObject(response);
                    if (jsonObject.optString(Const.SUCCESS).equals("true")) {
                        requestDetailsList = new ArrayList<>();
                        JSONObject tempObject = jsonObject.optJSONObject("temp_request");
                        String serviceType = tempObject.optString("sub_category_name");

                        JSONArray dataArray = jsonObject.optJSONArray("data");
                        if (dataArray != null && dataArray.length() > 0) {
                            for (int i = 0; i < dataArray.length(); i++) {
                                JSONObject dataObject = dataArray.optJSONObject(i);
                                RequestDetails requestDetails = new RequestDetails();
                                requestDetails.setProviderId(dataObject.optString("provider_id"));
                                requestDetails.setProviderName(dataObject.optString("provider_name"));
                                requestDetails.setProviderPicture(dataObject.optString("provider_picture"));
                                requestDetails.setCharges(dataObject.optString("price_per_hour"));
                                requestDetails.setProviderRating(dataObject.optString("rating"));
                                requestDetails.setJobTitle(serviceType);
                                requestDetails.setTempReqId(tempObject.optString(Const.Params.TEMP_REQUEST_ID));
                                requestDetailsList.add(requestDetails);

                            }
                            LinearLayoutManager layoutManager = new LinearLayoutManager(activity);
                            biddingRecyclerView.setLayoutManager(layoutManager);
                            biddingRecyclerView.setItemAnimator(new DefaultItemAnimator());
                            SelectBiddingAdapter biddingAdapter = new SelectBiddingAdapter(activity, requestDetailsList);
                            biddingRecyclerView.setAdapter(biddingAdapter);
                        }
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                break;
            case Const.ServiceCode.POST_REQUEST_LATER:
                AndyUtils.removeProgressDialog();
                AndyUtils.appLog("LaterBidding", "PostRequestLaterResponse" + response);
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    if (jsonObject.optString("success").equals("true")) {
                        if (providerDetailDialog != null && providerDetailDialog.isShowing()) {
                            providerDetailDialog.cancel();
                        }
                        AndyUtils.showLongToast("Bid created successfully", activity);
                        activity.headerText.setText("Category");
                        activity.addFragment(new CategoryFragment(), false, "", "");
                    } else if (jsonObject.optString(Const.SUCCESS).equals("false")) {
                        AndyUtils.showLongToast(jsonObject.optString("error"), activity);
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                break;
            case Const.ServiceCode.POST_PROVIDER_DETAIL:
                AndyUtils.removeProgressDialog();
                AndyUtils.appLog("LaterBidding", "PostProviderDetailResponse" + response);

                BiddingProviderDetails biddingProviderDetails = ParseContent.getInstance().parsingBiddingProviderDetails(response);
                if (biddingProviderDetails != null) {
                    showProviderDetailsDialog(biddingProviderDetails);
                }
                break;
            case Const.ServiceCode.POST_DRAFTS_REQUEST:
                AndyUtils.appLog("LaterBidding", "PostDraftRequestResponse" + response);
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    if (jsonObject.optString(Const.SUCCESS).equals(Const.TRUE)) {
                        JSONObject dataObject = jsonObject.optJSONObject("data");
                        String tempReqId = dataObject.optString(Const.Params.TEMP_REQUEST_ID);
                        String bidAmount = dataObject.optString(Const.Params.USER_PRICE);
                        createJobRequestLater(bidAmount, providerId, tempReqId);


                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }

//                createJobRequestLater();


        }
    }


    private void showProviderDetailsDialog(final BiddingProviderDetails biddingProviderDetails) {
        providerDetailDialog = new Dialog(activity, R.style.DialogThemeforview);
        providerDetailDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        providerDetailDialog.setContentView(R.layout.dialog_provider_profile_layout);
        ImageView providerIcon = (ImageView) providerDetailDialog.findViewById(R.id.iv_dialog_providerIcon);
        TextView providerName = (TextView) providerDetailDialog.findViewById(R.id.tv_dialog_provider_name);
        TextView providerCharge = (TextView) providerDetailDialog.findViewById(R.id.tv_dialog_provider_charge);
        SimpleRatingBar ratingBar = (SimpleRatingBar) providerDetailDialog.findViewById(R.id.dialog_rating);
        RecyclerView ratingRecyclerView = (RecyclerView) providerDetailDialog.findViewById(R.id.rv_ratings);
        FloatingActionButton callButton = (FloatingActionButton) providerDetailDialog.findViewById(R.id.fab_dialog_call);
        FloatingActionButton messageButton = (FloatingActionButton) providerDetailDialog.findViewById(R.id.fab_dialog_message);
        Button requestButton = (Button) providerDetailDialog.findViewById(R.id.bn_dialog_request);
        TextView headerText = (TextView) providerDetailDialog.findViewById(R.id.tb_dialog_header_job);
        TextView noRatings = (TextView) providerDetailDialog.findViewById(R.id.tv_noratings);
        headerText.setText(biddingProviderDetails.getServiceType());

        ImageView backButton = (ImageView) providerDetailDialog.findViewById(R.id.btn_dialog_back_job);
        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                providerDetailDialog.cancel();
            }
        });

        callButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (biddingProviderDetails.getProviderNumber() != null && !biddingProviderDetails.getProviderNumber().equals("")) {
                    Intent intent = new Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + biddingProviderDetails.getProviderNumber()));
                    startActivity(intent);
                } else {
                    AndyUtils.showShortToast("Sorry, number is not available", activity);
                }
            }
        });
        messageButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (biddingProviderDetails.getProviderNumber() != null && !biddingProviderDetails.getProviderNumber().equals("")) {
                    Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("sms:" + biddingProviderDetails.getProviderNumber()));
                    startActivity(intent);
                } else {
                    AndyUtils.showShortToast("Sorry, number is not available", activity);
                }

            }
        });

        requestButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                providerId = biddingProviderDetails.getProviderId();
                showBidDialog(providerId);
            }
        });

        if (biddingProviderDetails.getProviderPicture() != null && !biddingProviderDetails.getProviderPicture().equals("")) {
            Glide.with(activity).load(biddingProviderDetails.getProviderPicture()).into(providerIcon);
        } else {
            providerIcon.setImageResource(R.drawable.default_user);
        }


        providerName.setText(biddingProviderDetails.getProviderName());
        providerCharge.setText(biddingProviderDetails.getServiceType() + " / " + "$" + biddingProviderDetails.getCharge());
        if (biddingProviderDetails.getProviderRatingsArrayList() != null && biddingProviderDetails.getProviderRatingsArrayList().size() > 0) {
            LinearLayoutManager layoutManager = new LinearLayoutManager(activity);
            ratingRecyclerView.setLayoutManager(layoutManager);
            ProviderUserRatingAdapter ratingAdapter = new ProviderUserRatingAdapter(activity, biddingProviderDetails.getProviderRatingsArrayList());
            ratingRecyclerView.addItemDecoration(new VerticalSpaceItemDecoration(14));
            ratingRecyclerView.setAdapter(ratingAdapter);
        } else {
            noRatings.setVisibility(View.VISIBLE);
        }


        try {

            if (biddingProviderDetails.getRating().equals("0")) {
                ratingBar.setRating(0);
            } else {
                ratingBar.setRating(Integer.parseInt(String.valueOf((biddingProviderDetails.getRating().charAt(0)))));
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        providerDetailDialog.setCancelable(true);
        providerDetailDialog.show();

    }
}
