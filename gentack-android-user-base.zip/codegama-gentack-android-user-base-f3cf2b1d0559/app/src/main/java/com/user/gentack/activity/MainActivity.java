package com.user.gentack.activity;

import android.content.BroadcastReceiver;
import android.content.Intent;
import android.content.res.Configuration;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.facebook.AccessToken;
import com.facebook.FacebookSdk;
import com.facebook.GraphRequest;
import com.facebook.GraphResponse;
import com.facebook.HttpMethod;
import com.facebook.login.LoginManager;
import com.user.gentack.R;
import com.user.gentack.custom_interface.AsyncTaskCompleteListener;
import com.user.gentack.fragment.CategoryFragment;
import com.user.gentack.fragment.JobMapFragment;
import com.user.gentack.fragment.SubCategoryFragment;
import com.user.gentack.gcm.GCMRegisterHandler;
import com.user.gentack.gcm.GcmBroadcastReceiver;
import com.user.gentack.model.RequestDetails;
import com.user.gentack.model.ResponseHandler;
import com.user.gentack.networking.HttpRequester;
import com.user.gentack.utils.AndyUtils;
import com.user.gentack.utils.Const;
import com.user.gentack.utils.ParseContent;
import com.user.gentack.utils.PreferenceHelper;
import com.google.android.gms.auth.api.Auth;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.ResultCallback;
import com.google.android.gms.common.api.Status;

import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;

import java.util.HashMap;

public class MainActivity extends AppCompatActivity implements AsyncTaskCompleteListener, GoogleApiClient.OnConnectionFailedListener {


    public Toolbar mainToolbar;
    public DrawerLayout drawerLayout;
    public String currentFragment = "";
    public ActionBarDrawerToggle drawerToggle;
    public View navigationFragment;
    public ImageView backButton;
    public TextView headerText;
    private Intent intent;
    private GoogleApiClient mGoogleApiClient;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        FacebookSdk.sdkInitialize(this);
        if (TextUtils.isEmpty(PreferenceHelper.getInstance().getDeviceToken())) {
            registerGcmReceiver(new GcmBroadcastReceiver());
            Log.d("SplashActivity", "FirstTime");
        }

        GoogleSignInOptions gso = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestEmail()
                .build();

        mGoogleApiClient = new GoogleApiClient.Builder(this)
                .enableAutoManage(this /* FragmentActivity */, this /* OnConnectionFailedListener */)
                .addApi(Auth.GOOGLE_SIGN_IN_API, gso)
                .build();

        mainToolbar = (Toolbar) findViewById(R.id.tb_main);
        setSupportActionBar(mainToolbar);
        getSupportActionBar().setTitle("");
        drawerLayout = (DrawerLayout) findViewById(R.id.drawer_layout);
        navigationFragment = findViewById(R.id.navigation_drawer);
        headerText = (TextView) findViewById(R.id.tv_main_header);
        headerText.setText("Category");
        backButton = (ImageView) findViewById(R.id.btn_back);
        backButton.setVisibility(View.GONE);
        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });
        initDrawer();
        if (AndyUtils.isNetworkAvailable(this)) {
            getStatusCheck();
            Log.d("Ashutosh", "onresume main activity");
        }
        addFragment(new CategoryFragment(), false, "", "");
        Log.d("ID", PreferenceHelper.getInstance().getUserId());
        Log.d("TOKEN", PreferenceHelper.getInstance().getSessionToken());

    }


    public void registerGcmReceiver(BroadcastReceiver mHandleMessageReceiver) {
        if (mHandleMessageReceiver != null) {
            new GCMRegisterHandler(this, mHandleMessageReceiver);
        }
    }

    public void unregisterGcmReceiver(BroadcastReceiver mHandleMessageReceiver) {

        try {
            if (mHandleMessageReceiver != null) {
                unregisterReceiver(mHandleMessageReceiver);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onEvent(ResponseHandler handler) {
        if (handler.isFlag()) {
            AndyUtils.showLongToast(handler.getMessage(), this);
        }
        PreferenceHelper.getInstance().putFirstTimeLogin(false);
        logout();
        switch (PreferenceHelper.getInstance().getLoginBy()) {
            case Const.GOOGLE:
                signOutGoogle();
                break;
            case Const.FACEBOOK:
                logoutfromFacebook();
                break;
        }
        PreferenceHelper.getInstance().putRequestId(Const.NO_REQUEST);
        Intent intent = new Intent(this, SplashActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
        finish();
    }

    private void logout(){
        HashMap<String, String> map = new HashMap<String, String>();
        map.put(Const.Params.URL, Const.ServiceType.LOGOUT);
        map.put(Const.Params.ID, PreferenceHelper.getInstance().getUserId());
        map.put(Const.Params.TOKEN, PreferenceHelper.getInstance().getSessionToken());
        new HttpRequester(this, Const.POST, map, Const.ServiceCode.LOGOUT_CODE, this);

    }

    public void signOutGoogle(){
        Auth.GoogleSignInApi.revokeAccess(mGoogleApiClient).setResultCallback(new ResultCallback<Status>() {
            @Override
            public void onResult(@NonNull Status status) {
                Log.d("GOOGLESTATUS", status.toString());
            }
        });
    }

    public void logoutfromFacebook() {

        if (AccessToken.getCurrentAccessToken() == null) {
            return; // already logged out
        }

        new GraphRequest(AccessToken.getCurrentAccessToken(), "/me/permissions/", null, HttpMethod.DELETE, new GraphRequest
                .Callback() {
            @Override
            public void onCompleted(GraphResponse graphResponse) {

                LoginManager.getInstance().logOut();

            }
        }).executeAsync();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (PreferenceHelper.getInstance().getRequestId() != Const.NO_REQUEST) {
            getStatusCheck();
        } else {

        }
    }

    public void getStatusCheck() {
        if (!AndyUtils.isNetworkAvailable(this)) {

            return;
        }

        HashMap<String, String> map = new HashMap<String, String>();
        map.put(Const.Params.URL, Const.ServiceType.POST_REQUEST_STATUS_CHECK_NOW_URL);
        map.put(Const.Params.ID, PreferenceHelper.getInstance().getUserId());
        map.put(Const.Params.TOKEN, PreferenceHelper.getInstance().getSessionToken());

        new HttpRequester(this, Const.POST, map, Const.ServiceCode.POST_REQUEST_STATUS_CHECK_NOW, this);

    }

    private void initDrawer() {
        // TODO Auto-generated method stub
        drawerToggle = new ActionBarDrawerToggle(this, drawerLayout,
                mainToolbar, R.string.drawer_open, R.string.drawer_close) {

            public void onDrawerClosed(View view) {
                super.onDrawerClosed(view);
                invalidateOptionsMenu();
            }

            public void onDrawerOpened(View drawerView) {
                super.onDrawerOpened(drawerView);
//                invalidateOptionsMenu();
            }
        };

        drawerLayout.addDrawerListener(drawerToggle);
        drawerLayout.post(new Runnable() {
            @Override
            public void run() {

                drawerToggle.syncState();
            }
        });


    }

    @Override
    protected void onStart() {
        super.onStart();
        if (!EventBus.getDefault().isRegistered(this)) {
            EventBus.getDefault().register(this);
        }
    }

    @Override
    protected void onStop() {
        super.onStop();
        EventBus.getDefault().unregister(this);
    }

    public void closeDrawer() {
        drawerLayout.closeDrawers();
    }


    @Override
    protected void onPostCreate(Bundle savedInstanceState) {
        super.onPostCreate(savedInstanceState);
        drawerToggle.syncState();
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        drawerToggle.onConfigurationChanged(newConfig);
    }


    public void addFragment(Fragment fragment, boolean addToBackStack, String fragmentTitle,
                            String tag) {
        FragmentManager manager = getSupportFragmentManager();
        FragmentTransaction ft = manager.beginTransaction();
//        if (fragmentTitle.equals(Const.Params.SIGNIN_FRAGMENT)) {
//        } else if (fragmentTitle.equals(Const.Params.SIGNUP_FRAGMENT)) {
//        }
        if (addToBackStack) {
            ft.addToBackStack(tag);
        }
        ft.replace(R.id.container, fragment, tag);
        ft.commitAllowingStateLoss();
    }

    @Override
    public void onBackPressed() {
        if (currentFragment.equals(Const.Params.SUB_CATEGORY_FRAGMENT)) {
            headerText.setText("Category");
            backButton.setVisibility(View.GONE);
            addFragment(new CategoryFragment(), false, "", "");
        } else if (currentFragment.equals(Const.Params.JOB_DETAIL_FRAGMENT)) {
            headerText.setText("Sub Category");
            addFragment(new SubCategoryFragment(), false, "", "");
        } else if (currentFragment.equals(Const.Params.CATEGORY_FRAGMENT)) {
            super.onBackPressed();
        }
    }

    @Override
    public void onTaskCompleted(String response, int serviceCode) {
        switch (serviceCode) {
            case Const.ServiceCode.POST_REQUEST_STATUS_CHECK_NOW:
                AndyUtils.appLog("Ashutosh", "CheckStatusResponse" + response);
                RequestDetails requestDetails = ParseContent.getInstance().parsingRequestInProgress(response);
                if (requestDetails != null && Integer.parseInt(requestDetails.getProviderStatus()) != 0) {
                    Bundle bundle = new Bundle();
                    bundle.putSerializable(Const.REQUEST_BUNDLE_DETAIL, requestDetails);
                    JobMapFragment jobMapFragment = new JobMapFragment();
                    jobMapFragment.setArguments(bundle);
                    addFragment(jobMapFragment, false, "", "");

                }
//                else if (!ParseContent.getInstance().isSuccess(response)){
//                    int error_code = ParseContent.getInstance().getErrorCode(response);
//                    if (error_code != -1) {
//                        PreferenceHelper.getInstance().clearRequestData();
//                        PreferenceHelper.getInstance().putFirstTimeLogin(false);
//                        PreferenceHelper.getInstance().putRequestId(Const.NO_REQUEST);
//                        Intent intent = new Intent(this, SplashActivity.class);
//                        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
//                        startActivity(intent);
//                        AndyUtils.showShortToast(
//                                error_code == 104 ?
//                                        getResources().getString(R.string.login_error)
//                                :
//                                getResources().getString(R.string.invalid_token), this);
//                    }
//                }
                break;
        }
    }

    @Override
    public void onConnectionFailed(@NonNull ConnectionResult connectionResult) {

    }
}
/*
GenTack is a trusted community marketplace for people and businesses

GenTack is a trusted community marketplace for people and businesses to outsource tasks, find local services or hire flexible staff in minutes via your Mobile.
Find local people to help you around the home and office or earn money by completing tasks for others.

How easy is it?

Post a task you need done and make your life simpler  in a few easy steps.

- Post your task, communicate with providers  about the task and await offers.
- Assign task, communicate privately and make payment upon task completion.

http://jobrabbit.info/privacy
 */
