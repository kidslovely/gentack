package com.provider.gentack.activity;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.provider.gentack.R;
import com.provider.gentack.fragment.LoginFragment;
import com.provider.gentack.fragment.SignUpFragment;
import com.provider.gentack.utils.Const;

public class LoginRegisterActivity extends AppCompatActivity implements View.OnClickListener {

    private Toolbar toolbar;
    public ImageView backButton;
    private Intent intent;
    public TextView headerText;
    public static String currentRegFragment = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_register);
        toolbar = (Toolbar) findViewById(R.id.tb_login_register);
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle("");
        headerText = (TextView) findViewById(R.id.toolbar_header);
        backButton = (ImageView) findViewById(R.id.iv_back);
        backButton.setOnClickListener(this);
        try {
            intent = getIntent();
            if (intent != null) {
                if (intent.getStringExtra(Const.Params.SINGIN_SIGNUP).equals(Const.Params.LOGIN_FRAGMENT)) {
                    addFragment(new LoginFragment(), false, Const.Params.LOGIN_FRAGMENT, "");
                } else if (intent.getStringExtra(Const.Params.SINGIN_SIGNUP).equals(Const.Params.SIGNUP_FRAGMENT)) {
                    addFragment(new SignUpFragment(), false, Const.Params.SIGNUP_FRAGMENT, "");
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

    }


    public void addFragment(Fragment fragment, boolean addToBackStack, String fragmentTitle,
                            String tag) {
        FragmentManager manager = getSupportFragmentManager();
        FragmentTransaction ft = manager.beginTransaction();
        if (fragmentTitle.equals(Const.Params.LOGIN_FRAGMENT)) {
            headerText.setText(getString(R.string.login));
        } else if (fragmentTitle.equals(Const.Params.SIGNUP_FRAGMENT)) {
            headerText.setText(getString(R.string.signup));
        }
        if (addToBackStack) {
            ft.addToBackStack(tag);
        }
        ft.replace(R.id.fl_container, fragment, tag);
        ft.commit();
    }

    @Override
    public void onResume() {
        super.onResume();

    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.iv_back:
                onBackPressed();
                break;
        }

    }

    @Override
    public void onBackPressed() {
        if (currentRegFragment.equals(Const.Params.SERVICE_FRAGMENT)) {

        } else {
            super.onBackPressed();
        }

    }
}
