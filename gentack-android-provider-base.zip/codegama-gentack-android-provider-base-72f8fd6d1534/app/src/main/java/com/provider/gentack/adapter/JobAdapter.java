package com.provider.gentack.adapter;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.provider.gentack.R;
import com.provider.gentack.model.BiddingRequestDetails;

import java.text.SimpleDateFormat;
import java.util.List;

/**
 * Created by user on 4/8/2017.
 */

public class JobAdapter extends RecyclerView.Adapter<JobAdapter.CustomViewHolder> {


    private Context mContext;
    private List<BiddingRequestDetails> requestDetailsList;
    SimpleDateFormat simpleDateFormat;
    SimpleDateFormat inputformat;

    public JobAdapter(Context context, List<BiddingRequestDetails> requestDetailsList) {
        mContext = context;
        this.requestDetailsList = requestDetailsList;
        simpleDateFormat = new SimpleDateFormat("E, MMM, dd, yyyy hh:mm a");
        inputformat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
    }

    @Override
    public CustomViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(mContext).inflate(R.layout.adapter_job_bidding_layout, null);

        return new CustomViewHolder(view);
    }

    @Override
    public void onBindViewHolder(CustomViewHolder holder, int position) {
        BiddingRequestDetails requestDetails = requestDetailsList.get(position);
        if (requestDetails.getServicePicture() != null && !requestDetails.getServicePicture().equals("")) {
            Glide.with(mContext).load(requestDetails.getServicePicture()).into(holder.providerIcon);
        } else {
            holder.providerIcon.setImageResource(R.drawable.default_user);
        }

        String job_Date ="";
        job_Date = requestDetails.getRequestDateTime();
        holder.tv_service_date.setText(job_Date);

        holder.jobService.setText(requestDetails.getServiceType());


        holder.jobTitle.setText(requestDetails.getJobTitle());
        if(requestDetails.getBid_status().equals("2")){
            holder.jobCharge.setText(requestDetails.getCurrency() + requestDetails.getBidded_price() + "/Hr");
        } else if(requestDetails.getBid_status().equals("1")) {
            holder.jobCharge.setText(requestDetails.getCurrency() + requestDetails.getPrice() + "/Hr");
        } else if(requestDetails.getBid_status().equals("3")){
            holder.jobCharge.setText(requestDetails.getCurrency() + requestDetails.getFinal_price() + "/Hr");
        }

        holder.jobDesc.setText(requestDetails.getDescription());


    }

    @Override
    public int getItemCount() {
        return requestDetailsList.size();
    }

    public class CustomViewHolder extends RecyclerView.ViewHolder {
        private ImageView providerIcon;
        private TextView jobService, jobTitle, jobCharge, jobDesc,tv_service_date;


        public CustomViewHolder(View itemView) {
            super(itemView);
            providerIcon = (ImageView) itemView.findViewById(R.id.iv_bidding);
            jobService = (TextView) itemView.findViewById(R.id.tv_job_serviceType);
            jobTitle = (TextView) itemView.findViewById(R.id.tv_service_title);
            jobCharge = (TextView) itemView.findViewById(R.id.tv_job_charges);
            jobDesc = (TextView) itemView.findViewById(R.id.tv_description);
            tv_service_date = (TextView)itemView.findViewById(R.id.tv_service_date);

        }
    }
}