package com.provider.gentack.activity;

import android.content.DialogInterface;
import android.os.Handler;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.provider.gentack.R;
import com.provider.gentack.adapter.RedeemAdapter;
import com.provider.gentack.custom_interface.AsyncTaskCompleteListener;
import com.provider.gentack.model.Redeem;
import com.provider.gentack.networking.HttpRequester;
import com.provider.gentack.utils.AndyUtils;
import com.provider.gentack.utils.Const;
import com.provider.gentack.utils.PreferenceHelper;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class RedeemsActivity extends AppCompatActivity implements SwipeRefreshLayout.OnRefreshListener,
        AsyncTaskCompleteListener, RedeemAdapter.OnCancelRedeemRequestListener {

    private Toolbar chatToolbar;
    private ImageView chat_back;

    private TextView total, paid, remaining;
    private Button redeem;

    private RecyclerView videosListView;
    private List<Redeem> redeems;
    private SwipeRefreshLayout swipe;
    private TextView nodata;

    private RedeemAdapter adapter;
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
        setContentView(R.layout.activity_redeems);
        chatToolbar = (Toolbar) findViewById(R.id.toolbar_chat);
        chat_back = (ImageView) findViewById(R.id.btn_back_chat);
        setSupportActionBar(chatToolbar);
        getSupportActionBar().setTitle(null);

        redeems = new ArrayList<>();

        videosListView = (RecyclerView) findViewById(R.id.videoslist);
        swipe = (SwipeRefreshLayout) findViewById(R.id.swipe);
        nodata = (TextView) findViewById(R.id.nodata);

        swipe.post(new Runnable() {
            @Override
            public void run() {
                swipe.setRefreshing(true);
                loadData();
            }
        });

        total = (TextView) findViewById(R.id.total);
        paid = (TextView) findViewById(R.id.paid);
        remaining = (TextView) findViewById(R.id.remaining);
        redeem = (Button) findViewById(R.id.redeem);

        swipe.setOnRefreshListener(this);
        videosListView.setHasFixedSize(true);
        videosListView.setNestedScrollingEnabled(false);
        videosListView.setLayoutManager(new LinearLayoutManager(this));
        videosListView.setItemAnimator(new DefaultItemAnimator());
        adapter = new RedeemAdapter(this, redeems);
        videosListView.setAdapter(adapter);
        adapter.setOnCancelRedeemRequestListener(this);
        redeem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                new AlertDialog.Builder(RedeemsActivity.this)
                        .setMessage("Are you sure to redeem " + remaining.getText().toString() + "?")
                        .setPositiveButton("YES", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                dialogInterface.dismiss();
                                redeemRequest();
                            }
                        })
                        .setNegativeButton("NO", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                dialogInterface.cancel();
                            }
                        })
                        .create().show();
            }
        });
        
        chat_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });
    }

    private void redeemRequest(){
        if (!AndyUtils.isNetworkAvailable(this)) {
            if (swipe.isRefreshing()) swipe.setRefreshing(false);
            return;
        }
        HashMap<String, String> map = new HashMap<>();
        map.put(Const.Params.URL, Const.ServiceType.SEND_REDEEM);
        map.put(Const.Params.ID, PreferenceHelper.getInstance().getUserId());
        map.put(Const.Params.TOKEN, PreferenceHelper.getInstance().getSessionToken());
        new HttpRequester(this, Const.POST, map, Const.ServiceCode.SEND_REDEEM_CODE,this);
    }

    private void loadData(){
        if (!AndyUtils.isNetworkAvailable(this)) {
            if (swipe.isRefreshing()) swipe.setRefreshing(false);
            return;
        }
        redeems.clear();
        HashMap<String, String> map = new HashMap<>();
        map.put(Const.Params.URL, Const.ServiceType.REDEEMS_LIST);
        map.put(Const.Params.ID, PreferenceHelper.getInstance().getUserId());
        map.put(Const.Params.TOKEN, PreferenceHelper.getInstance().getSessionToken());
        new HttpRequester(this, Const.POST, map, Const.ServiceCode.REDEEMS_LIST_CODE,this);
    }

    private void updateUI(float amount){
        if (amount <= 2) {
            redeem.setVisibility(View.INVISIBLE);
        }
        else {
            redeem.setVisibility(View.VISIBLE);
        }
    }
    
    @Override
    public void onRefresh() {
        new Handler().post(new Runnable() {
            @Override
            public void run() {
                swipe.setRefreshing(false);
                loadData();
            }
        });
    }

    @Override
    public void onTaskCompleted(String response, int serviceCode) {
        switch (serviceCode) {
            case Const.ServiceCode.REDEEMS_LIST_CODE:
                if (swipe.isRefreshing())
                    swipe.setRefreshing(false);
                try {
                    JSONObject object = new JSONObject(response);
                    if (object.optString(Const.SUCCESS).equals(Const.TRUE)) {
                        JSONObject redeemData = object.optJSONObject("data");
                        if (redeemData != null) {
                            remaining.setText(redeemData.optString("currency") + redeemData.optString("remaining"));
                            total.setText(redeemData.optString("currency") + redeemData.optString("total"));
                            paid.setText(redeemData.optString("currency") + redeemData.optString("paid"));
                            updateUI(Float.parseFloat(redeemData.optString("remaining")));
                        }
                        JSONArray data = redeemData.optJSONArray("redeem_requests");
                        for (int i = 0; data != null && i < data.length(); i++) {
                            JSONObject rd = data.getJSONObject(i);
                            Redeem redeem = new Redeem();
                            redeem.setRequest_id(rd.optString("redeem_request_id"));
                            redeem.setRequest_amount(rd.optString("request_amount"));
                            redeem.setRedeem_status(rd.optString("redeem_status"));
                            redeem.setCurrency(rd.optString("currency"));
                            redeem.setRequested_date(rd.optString("requested_date"));
                            redeem.setPaid_date(rd.optString("paid_date"));
                            redeem.setPaid(rd.optString("paid_amount"));
                            redeem.setCancel_status(rd.optString("redeem_request_cancel_allow"));
                            redeem.setStatus(rd.optString("status"));
                            redeems.add(redeem);
                        }
                        adapter.notifyDataSetChanged();
                        if (redeems.isEmpty()){
                            videosListView.setVisibility(View.GONE);
                            nodata.setVisibility(View.VISIBLE);
                        }
                        else {
                            videosListView.setVisibility(View.VISIBLE);
                            nodata.setVisibility(View.GONE);
                        }
                    }
                    else {
                        videosListView.setVisibility(View.GONE);
                        nodata.setVisibility(View.VISIBLE);
                        AndyUtils.showShortToast(object.optString("error"), RedeemsActivity.this);
                    }
                }
                catch (JSONException e) {
                    e.printStackTrace();
                }
                break;
            case Const.ServiceCode.SEND_REDEEM_CODE:
                try {
                    JSONObject object = new JSONObject(response);
                    if (object.optString(Const.SUCCESS).equals(Const.TRUE)) {
                        AndyUtils.showShortToast("Redeem Request has been placed Successfully", RedeemsActivity.this);
                        loadData();
                    }
                    else {
                        AndyUtils.showLongToast("Failed - " + object.optString("error"), RedeemsActivity.this);
                    }
                }
                catch (JSONException e){
                    e.printStackTrace();
                }
                break;
            case Const.ServiceCode.CANCEL_REDEEM_CODE:
                try {
                    JSONObject object = new JSONObject(response);
                    if (object.optString(Const.SUCCESS).equals(Const.TRUE)) {
                        AndyUtils.showShortToast("Redeem Request has been Cancelled", RedeemsActivity.this);
                        loadData();
                    }
                    else {
                        AndyUtils.showShortToast("Failed - " + object.optString("error"), RedeemsActivity.this);
                    }
                }
                catch (JSONException e){
                    e.printStackTrace();
                }
                break;
        }
    }

    @Override
    public void cancelRedeemRequest(String redeemId) {
        HashMap<String, String> map = new HashMap<>();
        map.put(Const.Params.URL, Const.ServiceType.CANCEL_REDEEM);
        map.put(Const.Params.ID, PreferenceHelper.getInstance().getUserId());
        map.put(Const.Params.TOKEN, PreferenceHelper.getInstance().getSessionToken());
        map.put("redeem_request_id", redeemId);
        new HttpRequester(this, Const.POST, map, Const.ServiceCode.CANCEL_REDEEM_CODE,this);
    }
}
