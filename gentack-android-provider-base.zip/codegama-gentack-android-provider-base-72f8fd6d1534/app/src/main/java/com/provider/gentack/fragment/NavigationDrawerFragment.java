package com.provider.gentack.fragment;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.app.AlertDialog;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.provider.gentack.R;
import com.provider.gentack.activity.ChangePassword;
import com.provider.gentack.activity.HelpwebActivity;
import com.provider.gentack.activity.HistoryActivity;
import com.provider.gentack.activity.ListJobsActivity;
import com.provider.gentack.activity.MainActivity;
import com.provider.gentack.activity.ProfileActivity;
import com.provider.gentack.activity.RedeemsActivity;
import com.provider.gentack.activity.SplashActivity;
import com.provider.gentack.adapter.NavigationDrawerItemAdapter;
import com.provider.gentack.custom_interface.AsyncTaskCompleteListener;
import com.provider.gentack.model.DrawerDetails;
import com.provider.gentack.model.ResponseHandler;
import com.provider.gentack.networking.HttpRequester;
import com.provider.gentack.utils.AndyUtils;
import com.provider.gentack.utils.Const;
import com.provider.gentack.utils.PreferenceHelper;
import com.provider.gentack.utils.RecyclerViewItemClickListener;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/**
 * Created by user on 12/28/2016.
 */
public class NavigationDrawerFragment extends Fragment implements AsyncTaskCompleteListener {

    private RecyclerView drawerRecyclerView;
    private MainActivity activity;
    private ImageView userIcon;
    private TextView userName;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.navigation_drawer_layout, container, false);
        activity = (MainActivity) getActivity();
        drawerRecyclerView = (RecyclerView) view.findViewById(R.id.rv_drawer);
        userIcon = (ImageView) view.findViewById(R.id.iv_profile);
        userName = (TextView) view.findViewById(R.id.tv_user_name);

        LinearLayoutManager layoutManager = new LinearLayoutManager(activity);
        drawerRecyclerView.setLayoutManager(layoutManager);
        final NavigationDrawerItemAdapter adapter = new NavigationDrawerItemAdapter(activity, getDrawerList());
        drawerRecyclerView.setAdapter(adapter);
        userIcon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(activity,ProfileActivity.class));
            }
        });

        getprofile();
        /*userName.setText(new PreferenceHelper(activity).getUser_name());
        Glide.with(this)
                .load(new PreferenceHelper(activity).getPicture())
                .into(userIcon);*/


        drawerRecyclerView.addOnItemTouchListener(new RecyclerViewItemClickListener(activity, new RecyclerViewItemClickListener.OnItemClickListener() {
            @Override
            public void onItemClick(View view, int position) {
                activity.closeDrawer();
                switch (position) {
                    case 0:
                        startActivity(new Intent(activity, MainActivity.class));
                        break;
                    case 1:
                        Intent i = new Intent(activity, ProfileActivity.class);
                        startActivity(i);
                        break;
                    case 2:
                        activity.addFragment(new ServiceSelectFragment(), false, "SELECT SERVICE", Const.Params.SERVICE_FRAGMENT);
                        break;
                    case 5:
                        Intent h = new Intent(activity, HistoryActivity.class);
                        startActivity(h);
                        break;
                    case 6:
                        if (new PreferenceHelper(activity).getLoginType().equals(Const.MANUAL)) {
                            Intent c = new Intent(activity, ChangePassword.class);
                            startActivity(c);
                        } else {
                            AndyUtils.showShortToast("Change Password option disabled for social media login!", activity);
                        }

                        break;
                    case 3:
                        Intent j = new Intent(activity, ListJobsActivity.class);
                        startActivity(j);
                        break;
                    case 4:
                        Intent k = new Intent(activity, RedeemsActivity.class);
                        startActivity(k);
                        break;
                    case 7:
                        startActivity(new Intent(activity, HelpwebActivity.class));
                        break;
                    case 8:
                        showLogoutDialog();
                        break;
                }

            }
        }));


        return view;
    }


    private List<DrawerDetails> getDrawerList() {
        List<DrawerDetails> drawerList = new ArrayList<>();
//        drawerList.add(new DrawerDetails(R.drawable.user_selected, getString(R.string.profile)));
//        drawerList.add(new DrawerDetails(R.drawable.ic_front_car,getString(R.string.my_parking)));
        drawerList.add(new DrawerDetails(getString(R.string.home)));
        drawerList.add(new DrawerDetails(getString(R.string.profile)));
        drawerList.add(new DrawerDetails("UPDATE SERVICE"));
        drawerList.add(new DrawerDetails(getString(R.string.job)));
        drawerList.add(new DrawerDetails(getString(R.string.redeems)));
        drawerList.add(new DrawerDetails(getString(R.string.history)));
        drawerList.add(new DrawerDetails(getString(R.string.change_password)));
        drawerList.add(new DrawerDetails(getString(R.string.help)));
        drawerList.add(new DrawerDetails(getString(R.string.sign_out)));


        return drawerList;
    }

    @Override
    public void onResume() {
        super.onResume();
//        activity.currentFragment = Const.UserSettingsFragment;
    }


    private void showLogoutDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        builder.setTitle(getString(R.string.logout));
        String message = getString(R.string.logout_text);
        builder.setMessage(message);
        builder.setPositiveButton(getString(R.string.ok), new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                onDestroyView();
                PreferenceHelper.getInstance().putFirstTimeLogin(false);
                activity.onEvent(new ResponseHandler(false, null));
                new PreferenceHelper(activity).Logout();
                Intent intent = new Intent(getActivity(), SplashActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                activity.startActivity(intent);
                activity.finish();
            }
        });

        builder.setNegativeButton(getString(R.string.cancel), new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
            }
        });
        builder.show();
    }

    private void getprofile() {
        if (!AndyUtils.isNetworkAvailable(activity)) {

            return;
        }
        HashMap<String, String> map = new HashMap<String, String>();
        map.put(Const.Params.URL, Const.ServiceType.GET_PROFILE);
        map.put(Const.Params.ID, new PreferenceHelper(activity).getUserId());
        map.put(Const.Params.TOKEN, new PreferenceHelper(activity).getSessionToken());

        new HttpRequester(activity, Const.POST, map,
                Const.ServiceCode.GET_PROFILE, this);

    }

    @Override
    public void onTaskCompleted(String response, int serviceCode) {
        switch (serviceCode) {
            case Const.ServiceCode.GET_PROFILE:
                // Log.d("mahi", "profile response" + response);
                try {
                    JSONObject job = new JSONObject(response);
                    if (job.optString("success").equals("true")) {
                        JSONObject data = job.optJSONObject("data");
                        userName.setText(data.optString("provider_name"));

                        Glide.with(this)
                                .load(data.optString("provider_picture"))
                                .into(userIcon);

                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                }

                break;
            default:
                break;
        }
    }
}
