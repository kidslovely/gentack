package com.provider.gentack.activity;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.provider.gentack.R;
import com.provider.gentack.custom_interface.AsyncTaskCompleteListener;
import com.provider.gentack.networking.HttpRequester;
import com.provider.gentack.utils.AndyUtils;
import com.provider.gentack.utils.Const;
import com.provider.gentack.utils.PreferenceHelper;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;

import de.hdodenhof.circleimageview.CircleImageView;

public class DetailProfileActivity extends AppCompatActivity implements AsyncTaskCompleteListener{

    private String user_id;
    private ImageView btn_back_profile;
    private CircleImageView iv_profile;
    private Toolbar chatToolbar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail_profile);
        chatToolbar = (Toolbar) findViewById(R.id.toolbar_chat);
        setSupportActionBar(chatToolbar);
        getSupportActionBar().setTitle(null);
        btn_back_profile = (ImageView) findViewById(R.id.btn_back_chat);
        iv_profile = (CircleImageView) findViewById(R.id.iv_profile);
        user_id = getIntent().getStringExtra(Const.Params.USER_ID);
        getUserInfo();
        btn_back_profile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });
    }

    private void getUserInfo(){
        if (user_id != null){
            HashMap<String, String> map = new HashMap<>();
            map.put(Const.Params.URL, Const.ServiceType.POST_USER_PROFIFLE);
            map.put(Const.Params.ID, PreferenceHelper.getInstance().getUserId());
            map.put(Const.Params.TOKEN, PreferenceHelper.getInstance().getSessionToken());
            map.put(Const.Params.USER_ID, user_id);
            AndyUtils.showSimpleProgressDialog(this, "Loading", false);
            new HttpRequester(this, Const.POST, map, Const.ServiceCode.POST_USER_PROFILE_CODE, this);
        }
    }

    @Override
    public void onTaskCompleted(String response, int serviceCode) {
        switch (serviceCode){
            case Const.ServiceCode.POST_USER_PROFILE_CODE:
                try {
                    JSONObject object = new JSONObject(response);
                    if (object.optString("success").equals("true")){
                        JSONObject data = object.getJSONObject("data");
                        ((TextView) findViewById(R.id.tv_provider_name)).setText(data.optString("user_name"));
                        ((TextView) findViewById(R.id.tv_provider_mobile)).setText(data.optString("mobile"));
                        ((TextView) findViewById(R.id.tv_provider_email)).setText(data.optString("email"));
                        if (data.optString("user_picture") != null) {
                            Glide.with(this).load(data.optString("user_picture")).into(iv_profile);
                        } else {
                            iv_profile.setImageResource(R.drawable.default_user);
                        }
                        AndyUtils.removeProgressDialog();
                    }
                }
                catch (JSONException e){
                    e.printStackTrace();
                }
                break;
        }
    }
}

