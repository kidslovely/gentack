package com.provider.gentack.fragment;

import android.app.Activity;
import android.app.Dialog;
import android.content.Intent;
import android.content.IntentSender;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.TextInputLayout;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import com.facebook.AccessToken;
import com.facebook.CallbackManager;
import com.facebook.FacebookCallback;
import com.facebook.FacebookException;
import com.facebook.FacebookSdk;
import com.facebook.GraphRequest;
import com.facebook.GraphResponse;
import com.facebook.HttpMethod;
import com.facebook.login.LoginManager;
import com.facebook.login.LoginResult;
import com.google.android.gms.common.api.ResultCallback;
import com.google.android.gms.common.api.Status;
import com.provider.gentack.R;
import com.provider.gentack.activity.LoginRegisterActivity;
import com.provider.gentack.activity.MainActivity;
import com.provider.gentack.activity.SplashActivity;
import com.provider.gentack.custom_interface.AsyncTaskCompleteListener;
import com.provider.gentack.networking.HttpRequester;
import com.provider.gentack.utils.AndyUtils;
import com.provider.gentack.utils.Const;
import com.provider.gentack.utils.ParseContent;
import com.provider.gentack.utils.PreferenceHelper;
import com.google.android.gms.auth.api.Auth;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.auth.api.signin.GoogleSignInResult;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.GoogleApiClient;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.Arrays;
import java.util.HashMap;

/**
 * Created by user on 2/28/2017.
 */

public class LoginFragment extends Fragment implements View.OnClickListener, AsyncTaskCompleteListener,
        GoogleApiClient.OnConnectionFailedListener {

    private static final String TAG = LoginFragment.class.getSimpleName();
    private static final int GOOGLE_SIGN_IN = 205;
    private TextView facebookText, googleText, loginButton;
    private LoginRegisterActivity activity;
    private EditText emailEdit, passwordEdit;
    private String sEmail, sPassword, sSocial_unique_id, sName;
    private TextInputLayout emailLayout, passwordLayout;
    private CallbackManager callbackManager;
    private boolean mSignInClicked, mIntentInProgress;
    private String loginType = Const.MANUAL;
    private GoogleApiClient mGoogleApiClient;
    private ConnectionResult mConnectionResult;
    private TextView btn_forgot_pass;
    private Dialog forgot_dialog;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        activity = (LoginRegisterActivity) getActivity();
        FacebookSdk.sdkInitialize(activity);
        callbackManager = CallbackManager.Factory.create();
        GoogleSignInOptions gso = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestEmail()
                .build();

        mGoogleApiClient = new GoogleApiClient.Builder(activity)
                .enableAutoManage(activity /* FragmentActivity */, this /* OnConnectionFailedListener */)
                .addApi(Auth.GOOGLE_SIGN_IN_API, gso)
                .build();
        AndyUtils.generateKeyHAsh(activity);
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_login_layout, container, false);
        facebookText = (TextView) view.findViewById(R.id.tv_facebook_login);
        googleText = (TextView) view.findViewById(R.id.tv_google_login);
        emailEdit = (EditText) view.findViewById(R.id.et_email);
        passwordEdit = (EditText) view.findViewById(R.id.et_password);
        loginButton = (TextView) view.findViewById(R.id.tv_login);
        emailLayout = (TextInputLayout) view.findViewById(R.id.input_login_email);
        passwordLayout = (TextInputLayout) view.findViewById(R.id.input_login_password);
        btn_forgot_pass = (TextView) view.findViewById(R.id.btn_forgot_pass);
        loginButton.setOnClickListener(this);
        facebookText.setOnClickListener(this);
        googleText.setOnClickListener(this);
        btn_forgot_pass.setOnClickListener(this);
        facebookRegisterCallBack();
        return view;
    }

    private void getLoginDetails() {
        sEmail = emailEdit.getText().toString();
        sPassword = passwordEdit.getText().toString();
    }


    private boolean isValidData() {
        if (sEmail.length() == 0) {
            AndyUtils.showShortToast(getString(R.string.please_enter_emailid), activity);
            return false;
        } else if (!AndyUtils.eMailValidation(sEmail)) {
            emailLayout.setError(getString(R.string.incorrect_emailid));
            return false;
        } else if (sPassword.length() == 0) {
            AndyUtils.showShortToast(getString(R.string.please_enter_password), activity);
            return false;
        } else {
            return true;
        }

    }

    private void signIn() {
        Intent signInIntent = Auth.GoogleSignInApi.getSignInIntent(mGoogleApiClient);
        startActivityForResult(signInIntent, GOOGLE_SIGN_IN);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.tv_facebook_login:
                AndyUtils.appLog(TAG, "On Click of Facebook::");
                logoutfromFacebook();
                LoginManager.getInstance().logInWithReadPermissions(this, Arrays.asList("public_profile", "email", "user_birthday", "user_photos", "user_location"));
                loginType = Const.FACEBOOK;
                break;
            case R.id.tv_google_login:
                AndyUtils.appLog(TAG, "On Click of GooglePlus::");
                mSignInClicked = true;
                signOutGoogle();
                if (!mGoogleApiClient.isConnecting()) {
                    AndyUtils.showSimpleProgressDialog(activity, getString(R.string.connecting_gmail), false);
                    signIn();
                }
                break;
            case R.id.btn_forgot_pass:
                opneforgotpass();
                break;
            case R.id.tv_login:
                getLoginDetails();
                if (isValidData()) {
                    userLogin(loginType);
                }
        }
    }

    private void opneforgotpass() {
       forgot_dialog = new Dialog(activity, R.style.DialogThemeforview);
        forgot_dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        forgot_dialog.setCancelable(true);
        forgot_dialog.setContentView(R.layout.forgot_password);
        final EditText et_forgot_email = (EditText) forgot_dialog.findViewById(R.id.et_forgot_email);
        ImageView btn_back_forgot = (ImageView)forgot_dialog.findViewById(R.id.btn_back_forgot);
        Button req_password = (Button)  forgot_dialog.findViewById(R.id.req_password);
        req_password.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(et_forgot_email.getText().toString().length()==0){
                    AndyUtils.showShortToast("Please Enter Email Id",activity);
                } else {
                    forgotpass(et_forgot_email.getText().toString());
                }
            }
        });
        btn_back_forgot.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                forgot_dialog.dismiss();
            }
        });

        forgot_dialog.show();

    }

    private void forgotpass(String sEmail) {
        if (!AndyUtils.isNetworkAvailable(activity)) {
            AndyUtils.showShortToast(getString(R.string.no_internet), activity);
            return;
        }
        AndyUtils.showSimpleProgressDialog(activity, getString(R.string.please_wait), false);
        HashMap<String, String> map = new HashMap<String, String>();
        map.put(Const.Params.URL, Const.ServiceType.POST_FORGOT_PASSWORD_URL);
        map.put(Const.Params.EMAIL, sEmail);


        new HttpRequester(activity, Const.POST, map, Const.ServiceCode.POST_FORGOT_PASSWORD, this);

    }


    private void userLogin(String loginType) {
        if (loginType.equals(Const.MANUAL)) {
            if (!AndyUtils.isNetworkAvailable(activity)) {
                AndyUtils.showShortToast(getString(R.string.no_internet), activity);
                return;
            }
            AndyUtils.showSimpleProgressDialog(activity, getString(R.string.please_wait), false);

            HashMap<String, String> map = new HashMap<String, String>();
            map.put(Const.Params.URL, Const.ServiceType.POST_LOGIN_URL);
            map.put(Const.Params.EMAIL, sEmail);
            map.put(Const.Params.PASSWORD, sPassword);
            map.put(Const.Params.DEVICE_TYPE, Const.ANDROID);
            map.put(Const.Params.TIMEZONE, PreferenceHelper.getInstance().getTimeZone());
            map.put(Const.Params.DEVICE_TOKEN, new PreferenceHelper(activity).getDeviceToken());
            map.put(Const.Params.LOGIN_BY, loginType);

            AndyUtils.appLog("Ashutosh", "RegisterMap" + map);
            new HttpRequester(activity, Const.POST, map, Const.ServiceCode.POST_LOGIN, this);
        } else {
            if (!AndyUtils.isNetworkAvailable(activity)) {
                AndyUtils.showShortToast(getString(R.string.no_internet), activity);
                return;
            }
            AndyUtils.showSimpleProgressDialog(activity, getString(R.string.please_wait), false);
            HashMap<String, String> map = new HashMap<String, String>();
            map.put(Const.Params.URL, Const.ServiceType.POST_REGISTRATION_URL);
            map.put(Const.Params.SOCIAL_ID, sSocial_unique_id);
            //map.put(Const.Params.PASSWORD, sPassword);
            map.put(Const.Params.EMAIL, sEmail);
            map.put(Const.Params.NAME, sName);
            map.put(Const.Params.TIMEZONE, PreferenceHelper.getInstance().getTimeZone());
            map.put(Const.Params.DEVICE_TYPE, Const.ANDROID);
            map.put(Const.Params.DEVICE_TOKEN, new PreferenceHelper(activity).getDeviceToken());
            map.put(Const.Params.LOGIN_BY, loginType);
            AndyUtils.appLog("Ashutosh", "RegisterMap" + map);
            new HttpRequester(activity, Const.POST, map, Const.ServiceCode.POST_REGISTRATION, this);
        }

    }

    public void signOutGoogle(){
        Auth.GoogleSignInApi.revokeAccess(mGoogleApiClient).setResultCallback(new ResultCallback<Status>() {
            @Override
            public void onResult(@NonNull Status status) {
                Log.d("GOOGLESTATUS", status.toString());
            }
        });
    }

    public void logoutfromFacebook() {

        if (AccessToken.getCurrentAccessToken() == null) {
            return; // already logged out
        }

        new GraphRequest(AccessToken.getCurrentAccessToken(), "/me/permissions/", null, HttpMethod.DELETE, new GraphRequest
                .Callback() {
            @Override
            public void onCompleted(GraphResponse graphResponse) {

                LoginManager.getInstance().logOut();

            }
        }).executeAsync();
    }

    @Override
    public void onPause() {
        super.onPause();


    }

    @Override
    public void onTaskCompleted(String response, int serviceCode) {
        switch (serviceCode) {
            case Const.ServiceCode.POST_REGISTRATION:
                AndyUtils.removeProgressDialog();
                AndyUtils.appLog("Ashutosh", "LoginResponse" + response);
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    if (jsonObject.getString(Const.SUCCESS).equals(Const.TRUE)) {
                        PreferenceHelper.getInstance().putFirstTimeLogin(true);
                        new ParseContent(activity).saveIdAndToken(response);
                        Intent intent = new Intent(activity, MainActivity.class);
                        startActivity(intent);
                        activity.finish();
                    } else {
                        String error, error_msg = "";
                        error_msg = jsonObject.optString("error_message");
                        error = jsonObject.optString("error");
                        AndyUtils.showShortToast(error, activity);
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                break;
            case Const.ServiceCode.POST_LOGIN:
                AndyUtils.removeProgressDialog();
                AndyUtils.appLog("Ashutosh", "LoginResponse" + response);
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    if (jsonObject.getString(Const.SUCCESS).equals(Const.TRUE)) {
                        PreferenceHelper.getInstance().putFirstTimeLogin(true);
                        new ParseContent(activity).saveIdAndToken(response);
                        Intent intent = new Intent(activity, MainActivity.class);
                        startActivity(intent);
                        activity.finish();
                    } else {
                        String error, error_msg = "";
                        error_msg = jsonObject.optString("error_message");
                        error = jsonObject.optString("error");
                        AndyUtils.showShortToast(error, activity);
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                break;
            case Const.ServiceCode.POST_FORGOT_PASSWORD:
               // Log.d("mahi","forgot pass"+response);
                AndyUtils.removeProgressDialog();
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    if (jsonObject.getString(Const.SUCCESS).equals(Const.TRUE)) {
                        AndyUtils.showShortToast(jsonObject.optString("message") ,activity);
                        if(forgot_dialog!=null&&forgot_dialog.isShowing()){
                            forgot_dialog.dismiss();
                        }
                    }
                    else {
                        String error = jsonObject.getString("error");
                        AndyUtils.showShortToast(error,activity);
                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                }

                break;

        }
    }

    private void facebookRegisterCallBack() {
        LoginManager.getInstance().registerCallback(callbackManager, new FacebookCallback<LoginResult>() {
            //    private FacebookCallback<LoginResult> callback = new FacebookCallback<LoginResult>() {
            @Override
            public void onSuccess(LoginResult loginResult) {
                AndyUtils.appLog(TAG, "onSuccess");
                GraphRequest request = GraphRequest.newMeRequest(AccessToken.getCurrentAccessToken(),
                        new GraphRequest.GraphJSONObjectCallback() {
                            @Override
                            public void onCompleted(JSONObject jsonObject, GraphResponse graphResponse) {
                                if (jsonObject != null && graphResponse != null) {
                                    AndyUtils.appLog("Json Object", jsonObject.toString());
                                    AndyUtils.appLog("Graph response", graphResponse.toString());
                                    try {
                                        sName = jsonObject.getString("name");
                                        sEmail = jsonObject.getString("email");
                                        sSocial_unique_id = jsonObject.getString("id");
                                        loginType = Const.FACEBOOK;
                                        userLogin(loginType);

//                                        sPictureUrl = "https://graph.facebook.com/" + sSocial_unique_id + "/picture?type=large";
//                                        mediaProfile = new SocialMediaProfile();

//                                        if (sUserName != null) {
//                                            String[] name = sUserName.split(" ");
//                                            if (name[0] != null) {
//                                                mediaProfile.setFirstName(name[0]);
//                                            }
//                                            if (name[1] != null) {
//                                                mediaProfile.setLastName(name[1]);
//                                            }
//                                        }
//                                        mediaProfile.setEmailId(sEmailId);
//                                        mediaProfile.setSocialUniqueId(sSocial_unique_id);
//                                        mediaProfile.setPictureUrl(sPictureUrl);
//                                        mediaProfile.setLoginType(Const.FACEBOOK);
//
//                                        AndyUtils.appLog("all details", sUserName + "" + sEmailId + " " + " " + sPictureUrl);
//                                        if (sSocial_unique_id != null) {
//                                            loginType = Const.FACEBOOK;
//                                            patientLogin();
//                                        } else {
//                                            AndyUtils.showShortToast("Invalidate Data", LoginActivity.this);
//                                        }
                                    } catch (JSONException e) {
                                        e.printStackTrace();
                                    }

                                }
                            }
                        }

                );
                Bundle parameters = new Bundle();
                parameters.putString("fields", "id,name,link,locale,hometown,email,gender,birthday,location");
                request.setParameters(parameters);
                request.executeAsync();
            }


            @Override
            public void onCancel() {
                AndyUtils.showLongToast(getString(R.string.login_cancelled), activity);
            }

            @Override
            public void onError(FacebookException error) {
                AndyUtils.showLongToast(getString(R.string.login_failed), activity);
                AndyUtils.appLog("login failed Error", error.toString());
            }
        });
    }


    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        Log.d("Activity Res", "" + requestCode);
        switch (requestCode) {
            case GOOGLE_SIGN_IN:
                if (resultCode != Activity.RESULT_OK) {
                    mSignInClicked = false;
                    AndyUtils.removeProgressDialog();
                }
                mIntentInProgress = false;

                GoogleSignInResult result = Auth.GoogleSignInApi.getSignInResultFromIntent(data);
                handleSignInResult(result);
                break;
            default:
                callbackManager.onActivityResult(requestCode, resultCode, data);

        }
    }

    private void handleSignInResult(GoogleSignInResult result) {
        Log.d(TAG, "handleSignInResult:" + result.isSuccess());
        AndyUtils.removeProgressDialog();
        if (result.isSuccess()) {
            GoogleSignInAccount acct = result.getSignInAccount();
            if (acct != null) {
                sSocial_unique_id = acct.getId();
                sName = acct.getDisplayName();
                sEmail = acct.getEmail();
                if (sSocial_unique_id != null) {
                    loginType = Const.GOOGLE;
                    userLogin(loginType);
                }
                else {
                    AndyUtils.showShortToast(getString(R.string.invalid_data), activity);
                }
            }
            else {
                AndyUtils.showShortToast(getString(R.string.invalid_data), activity);
            }
        }
        else {
            // Signed out, show unauthenticated UI.
            AndyUtils.showShortToast(getString(R.string.invalid_data), activity);
        }
    }

    private void resolveSignInError() {
        if (mConnectionResult.hasResolution()) {
            try {
                mIntentInProgress = true;
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN) {
                    startIntentSenderForResult(mConnectionResult
                                    .getResolution().getIntentSender(), GOOGLE_SIGN_IN, null,
                            0, 0, 0, null);
                }
            } catch (IntentSender.SendIntentException e) {
                // The intent was canceled before it was sent. Return to the
                // default
                // state and attempt to connect to get an updated
                // ConnectionResult.
                mIntentInProgress = false;
                mGoogleApiClient.connect();
            }
        }
    }

    @Override
    public void onConnectionFailed(@NonNull ConnectionResult connectionResult) {
        if (!mIntentInProgress) {
            // Store the ConnectionResult so that we can use it later when the
            // user clicks
            // 'sign-in'.

            mConnectionResult = connectionResult;
            if (mSignInClicked) {
                // The user has already clicked 'sign-in' so we attempt to
                // resolve all

                // errors until the user is signed in, or they cancel.
                resolveSignInError();
            }
        }

    }
}
