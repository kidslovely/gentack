package com.provider.gentack.activity;

import android.app.Dialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.aurelhubert.simpleratingbar.SimpleRatingBar;
import com.bumptech.glide.Glide;
import com.provider.gentack.R;
import com.provider.gentack.adapter.HistoryAdapter;
import com.provider.gentack.custom_interface.AsyncTaskCompleteListener;
import com.provider.gentack.model.History;
import com.provider.gentack.networking.HttpRequester;
import com.provider.gentack.utils.AndyUtils;
import com.provider.gentack.utils.Const;
import com.provider.gentack.utils.PreferenceHelper;
import com.provider.gentack.utils.RecyclerLongPressClickListener;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;

/**
 * Created by Mahesh on 3/19/2017.
 */

public class HistoryActivity extends AppCompatActivity implements View.OnClickListener, AsyncTaskCompleteListener {
     private RecyclerView recycel_history;
    private ProgressBar progressbar_history;
    private HistoryAdapter hisAdapter;
    private ArrayList<History>hislst;
    private ImageView btn_back_history;
    private TextView tv_empty_text;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
        setContentView(R.layout.activity_history);
        recycel_history = (RecyclerView) findViewById(R.id.recycel_history);
        progressbar_history = (ProgressBar)findViewById(R.id.progressbar_history);
        hislst = new ArrayList<History>();
        btn_back_history = (ImageView) findViewById(R.id.btn_back_history);
        btn_back_history.setOnClickListener(this);
        tv_empty_text = (TextView) findViewById(R.id.tv_empty_text);

        RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(getApplicationContext());
        recycel_history.setLayoutManager(mLayoutManager);
        recycel_history.setItemAnimator(new DefaultItemAnimator());


        recycel_history.addOnItemTouchListener(new RecyclerLongPressClickListener(this, recycel_history, new RecyclerLongPressClickListener.OnItemClickListener() {
            @Override
            public void onItemClick(View view, int position) {

                getSinglejob_details(hislst.get(position).getRequest_id());
            }

            @Override
            public void onLongItemClick(View view, int position) {

            }
        }));
        getHistory();
    }

    private void getSinglejob_details(String request_id) {

        if (!AndyUtils.isNetworkAvailable(this)) {

            return;
        }
        AndyUtils.showSimpleProgressDialog(this, "Loading...", false);
        HashMap<String, String> map = new HashMap<String, String>();
        map.put(Const.Params.URL, Const.ServiceType.SINGLE_REQUEST);
        map.put(Const.Params.ID, new PreferenceHelper(this).getUserId());
        map.put(Const.Params.TOKEN, new PreferenceHelper(this).getSessionToken());
        map.put(Const.Params.REQUEST_ID, request_id);
        new HttpRequester(this, Const.POST, map,
                Const.ServiceCode.SINGLE_REQUEST, this);
    }

    private void getHistory() {
        if (!AndyUtils.isNetworkAvailable(this)) {

            return;
        }
        progressbar_history.setVisibility(View.VISIBLE);
        HashMap<String, String> map = new HashMap<String, String>();
        map.put(Const.Params.URL, Const.ServiceType.GET_HISTORY);
        map.put(Const.Params.ID, new PreferenceHelper(this).getUserId());
        map.put(Const.Params.TOKEN, new PreferenceHelper(this).getSessionToken());

        new HttpRequester(this, Const.POST, map,
                Const.ServiceCode.GET_HISTORY, this);

    }

    @Override
    public void onBackPressed() {
        startActivity(new Intent(this,MainActivity.class));
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()){
            case R.id.btn_back_history:
                onBackPressed();
                break;
        }

    }


    @Override
    public void onTaskCompleted(String response, int serviceCode) {
        switch (serviceCode){
            case Const.ServiceCode.GET_HISTORY:
                Log.d("mahi","history"+response);

                try {
                    hislst.clear();
                    JSONObject job = new JSONObject(response);
                    if(job.getString("success").equals("true")) {
                        progressbar_history.setVisibility(View.GONE);
                        JSONArray dataarray = job.getJSONArray("data");
                        for(int i=0;i<dataarray.length();i++){
                            JSONObject dataObj = dataarray.getJSONObject(i);
                            History his = new History();
                            his.setAddress(dataObj.optString("s_address"));
                            his.setCurrency(dataObj.optString("currency"));
                            his.setProvider_name(dataObj.optString("user_name"));
                            his.setProvider_pic(dataObj.optString("user_picture"));
                            his.setService_type(dataObj.optString("sub_category_name"));
                            his.setRequest_id(dataObj.optString("request_id"));
                            his.setTotal(dataObj.optString("total"));
                            JSONObject dateObj = dataObj.getJSONObject("created_at");
                            his.setDate(dateObj.optString("date"));
                            hislst.add(his);
                        }
                        if(hislst!=null){
                            hisAdapter = new HistoryAdapter(this, hislst);

                            recycel_history.setAdapter(hisAdapter);
                        }
                        if(hislst.size()==0){
                            tv_empty_text.setVisibility(View.VISIBLE);
                        } else {
                            tv_empty_text.setVisibility(View.GONE);
                        }

                    }


                } catch (JSONException e) {
                    e.printStackTrace();
                    tv_empty_text.setVisibility(View.GONE);
                }
                break;
            case Const.ServiceCode.SINGLE_REQUEST:
                AndyUtils.removeProgressDialog();
                Log.d("mahi", "single his response" + response);
                try {
                    JSONObject job = new JSONObject(response);
                    if (job.getString("success").equals("true")) {
                        JSONObject dataObj = job.getJSONObject("data");
                        String request_id = dataObj.getString("request_id");
                        String user_id = dataObj.getString("user_id");
                        String user_name = dataObj.getString("user_name");
                        String user_picture = dataObj.getString("user_picture");
                        String user_mobile = dataObj.getString("user_mobile");
                        String description = dataObj.getString("description");
                        String note = dataObj.getString("note");
                        String request_date = dataObj.getString("request_date");
                        String category_name = dataObj.getString("sub_category_name");
                        String s_latitude = dataObj.getString("s_latitude");
                        String s_longitude = dataObj.getString("s_longitude");
                        String s_address = dataObj.getString("s_address");
                        String user_price = dataObj.getString("user_price");
                        String before_image = dataObj.getString("before_image");
                        String after_image = dataObj.getString("after_image");
                        String base_price = dataObj.getString("price_per_hour");
                        String user_rating = dataObj.getString("user_rating");
                        JSONArray invoiceArray = dataObj.getJSONArray("invoice");
                        JSONObject jobinvoice = invoiceArray.getJSONObject(0);
                        String basePrice = jobinvoice.getString("base_price");
                        String time_price = jobinvoice.getString("time_price");
                        String tax_price = jobinvoice.getString("tax_price");
                        String total = jobinvoice.getString("total");
                        String payment_mode = jobinvoice.getString("payment_mode");

                        String google_img_url = getGoogleMapThumbnail(Double.valueOf(s_latitude), Double.valueOf(s_longitude));
                        showdetailedfullview(user_id, request_id, user_name, user_picture, user_mobile, description, note, request_date, category_name, s_latitude, s_longitude, s_address, user_price, user_rating, google_img_url,user_price,before_image,after_image,payment_mode,time_price,tax_price,total,payment_mode,basePrice);
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }


            break;
        }

    }

    private void showdetailedfullview(final String user_id, final String request_id, String user_name, String user_picture, final String user_mobile, String description, String note, String request_date, String category_name, String s_latitude, String s_longitude, String s_address, String user_price, String user_rating, String google_img_url, String user_price1, String before_image, String after_image, String payment_mode, String time_price, String tax_price, String total, String paymentMode, String basePrice) {

        final Dialog _dialog = new Dialog(this, R.style.DialogThemeforview);
        _dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        _dialog.setCancelable(true);
        _dialog.setContentView(R.layout.history_full_view);
        ImageView iv_userIcon = (ImageView) _dialog.findViewById(R.id.job_user_pic);
        ImageView btn_back_full = (ImageView) _dialog.findViewById(R.id.btn_back_full);
        ImageView jobdetailedMapView = (ImageView) _dialog.findViewById(R.id.jobdetailedMapView);
        TextView tv_user_name = (TextView) _dialog.findViewById(R.id.tv_job_client_name);
        TextView tv_service_requested = (TextView) _dialog.findViewById(R.id.tv_job_client_type);

        TextView tv_extra_price = (TextView)_dialog.findViewById(R.id.tv_extra_price);
        TextView tv_base_price = (TextView)_dialog.findViewById(R.id.tv_base_price);
        TextView tv_tax_price = (TextView)_dialog.findViewById(R.id.tv_tax_price);
        TextView tv_total_price = (TextView)_dialog.findViewById(R.id.tv_total_price);
        TextView tv_payment_type =(TextView) _dialog.findViewById(R.id.tv_payment_type);

        SimpleRatingBar rating = (SimpleRatingBar) _dialog.findViewById(R.id.job_rating_bar);
        FloatingActionButton btn_floating_call = (FloatingActionButton) _dialog.findViewById(R.id.btn_floating_call);
        FloatingActionButton info = (FloatingActionButton) _dialog.findViewById(R.id.btn_floating_info);
        ImageView iv_before = (ImageView)_dialog.findViewById(R.id.iv_before);
        ImageView iv_after = (ImageView)_dialog.findViewById(R.id.iv_after);
        Glide.with(this).load(before_image).error(R.drawable.before).into(iv_before);
        Glide.with(this).load(after_image).error(R.drawable.after).into(iv_after);
        btn_back_full.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                _dialog.dismiss();
            }
        });
        tv_extra_price.setText("$"+" "+time_price);
        tv_base_price.setText("$"+" "+basePrice);
        tv_total_price.setText("$"+ " "+total);
        tv_payment_type.setText("Pay Via - "+payment_mode);
        tv_tax_price.setText("$"+" "+tax_price);
        if (!iv_userIcon.equals("")) {
            Glide.with(this).load(user_picture).error(R.drawable.default_user).into(iv_userIcon);
        }
        iv_userIcon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent inte = new Intent(HistoryActivity.this, DetailProfileActivity.class);
                inte.putExtra(Const.Params.USER_ID, user_id);
                startActivity(inte);
            }
        });
        tv_user_name.setText(user_name);
        tv_service_requested.setText(category_name);;
        Glide.with(this).load(google_img_url).into(jobdetailedMapView);
        if (!user_rating.equals("")) {
            int rate = Integer.parseInt(user_rating);
            rating.setRating(rate);
        }

        info.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(HistoryActivity.this, InfoActivity.class);
                intent.putExtra(Const.Params.REQUEST_ID, request_id);
                startActivity(intent);
            }
        });

        btn_floating_call.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Intent.ACTION_DIAL, Uri.fromParts("tel", user_mobile, null));
                startActivity(intent);
            }
        });

        _dialog.show();

    }

    public static String getGoogleMapThumbnail(double lati, double longi) {
        String staticMapUrl = "http://maps.google.com/maps/api/staticmap?center=" + lati + "," + longi + "&markers=" + lati + "," + longi + "&zoom=10&size=350x150&&sensor=false";
        return staticMapUrl;
    }
}
