package com.provider.gentack.adapter;

import android.content.Context;
import android.content.DialogInterface;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AlertDialog;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;


import com.provider.gentack.R;
import com.provider.gentack.model.Redeem;

import java.util.List;

/**
 * Created by codegama on 22/12/17.
 */

public class RedeemAdapter extends RecyclerView.Adapter<RedeemAdapter.ViewHolder>{

    private Context context;
    private List<Redeem> redeemList;
    private LayoutInflater inflater;

    public RedeemAdapter(Context context, List<Redeem> redeemList) {
        this.context = context;
        this.redeemList = redeemList;
        inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = inflater.inflate(R.layout.view_redeem_list, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(final ViewHolder holder, int position) {
        final Redeem redeem = redeemList.get(position);
        switch (Integer.parseInt(redeem.getStatus())) {
            case 0:
            case 1:
                holder.statusimage.setImageDrawable(ContextCompat.getDrawable(context, R.drawable.pay_pending));
                holder.date.setText(redeem.getRequested_date());
                holder.status.setTextColor(ContextCompat.getColor(context, android.R.color.holo_orange_dark));
                break;
            case 2:
                holder.statusimage.setImageDrawable(ContextCompat.getDrawable(context, R.drawable.pay_success));
                holder.date.setText(redeem.getPaid_date());
                holder.status.setTextColor(ContextCompat.getColor(context, R.color.green_color));
                break;
            case 3:
                holder.statusimage.setImageDrawable(ContextCompat.getDrawable(context, R.drawable.pay_failure));
                holder.date.setText(redeem.getPaid_date());
                holder.status.setTextColor(ContextCompat.getColor(context, R.color.google_color));
                break;
        }
        if (Integer.parseInt(redeem.getCancel_status()) == 0) {
            holder.cancel.setVisibility(View.INVISIBLE);
        }
        else {
            holder.cancel.setVisibility(View.VISIBLE);
        }

        holder.paid.setText(redeem.getCurrency() + redeem.getPaid());
        holder.requestamount.setText(redeem.getCurrency() + redeem.getRequest_amount());
        holder.status.setText(redeem.getRedeem_status().toUpperCase());

        holder.cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                new AlertDialog.Builder(context)
                        .setMessage("Are you sure to redeem " + holder.requestamount.getText().toString() + "?")
                        .setPositiveButton("YES", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                dialogInterface.dismiss();
                                if (listener != null) {
                                    listener.cancelRedeemRequest(redeem.getRequest_id());
                                }
                            }
                        })
                        .setNegativeButton("NO", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                dialogInterface.cancel();
                            }
                        })
                        .create().show();
            }
        });
    }

    OnCancelRedeemRequestListener listener;

    public void setOnCancelRedeemRequestListener(OnCancelRedeemRequestListener listener) {
        this.listener = listener;
    }

    public interface OnCancelRedeemRequestListener {
        void cancelRedeemRequest(String redeemId);
    }

    @Override
    public int getItemCount() {
        return redeemList.size();
    }

    public static final class ViewHolder extends RecyclerView.ViewHolder{
        ImageView statusimage;
        TextView paid, requestamount, status, date;
        Button cancel;

        public ViewHolder(View itemView) {
            super(itemView);
            statusimage = (ImageView) itemView.findViewById(R.id.statusimage);
            paid = (TextView) itemView.findViewById(R.id.paid);
            requestamount = (TextView) itemView.findViewById(R.id.requestamount);
            status = (TextView) itemView.findViewById(R.id.status);
            date = (TextView) itemView.findViewById(R.id.date);
            cancel = (Button) itemView.findViewById(R.id.cancel);
        }
    }
}
