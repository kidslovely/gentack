package com.provider.gentack.model;

import java.util.ArrayList;

/**
 * Created by root on 2/3/16.
 */
public class Category {

    private String category_title;
    private ArrayList<SubCategory> subcat = new ArrayList<SubCategory>();



    public ArrayList<SubCategory> getSubcat() {
        return subcat;
    }

    public void setSubcat(ArrayList<SubCategory> subcat) {
        this.subcat = subcat;
    }

    public String getCategory_title() {
        return category_title;
    }

    public void setCategory_title(String category_title) {
        this.category_title = category_title;
    }
}
