package com.provider.gentack.activity;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.provider.gentack.R;
import com.provider.gentack.custom_interface.AsyncTaskCompleteListener;
import com.provider.gentack.fragment.ListJobAvailableFragment;
import com.provider.gentack.fragment.ListJobBiddedFragment;
import com.provider.gentack.fragment.ListJobConfirmFragment;
import com.provider.gentack.fragment.ListJobDirectFragment;
import com.provider.gentack.utils.Const;

/**
 * Created by Mahesh on 4/2/2017.
 */

public class ListJobsActivity extends AppCompatActivity implements View.OnClickListener, AsyncTaskCompleteListener {
    private TextView btn_available,btn_confirm,btn_bidded,btn_direct;
    private ImageView btn_back_jobs;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
        setContentView(R.layout.activity_jobs);
        btn_available = (TextView) findViewById(R.id.btn_available);
        btn_confirm = (TextView) findViewById(R.id.btn_confirm);
        btn_back_jobs = (ImageView) findViewById(R.id.btn_back_jobs);
        btn_bidded = (TextView)findViewById(R.id.btn_bidded);
        btn_direct = (TextView) findViewById(R.id.btn_direct);
        btn_available.setOnClickListener(this);
  ;
        btn_confirm.setOnClickListener(this);
        btn_back_jobs.setOnClickListener(this);
        btn_bidded.setOnClickListener(this);
        btn_direct.setOnClickListener(this);

        if (getIntent().hasExtra("fromPush")){
            String request_id = getIntent().getStringExtra(Const.Params.REQUEST_ID);
            String type = getIntent().getStringExtra(Const.Params.FRAGMENT_TYPE);
            switch (type){
                case "1":
                    loadFragmentType(request_id, new ListJobAvailableFragment(), Const.Params.AVAILABLE_FRAGMENT);
                    break;
                case "2":
                    loadFragmentType(request_id, new ListJobDirectFragment(), Const.Params.DIRECT_FRAGMENT);
                    break;
                case "3":
                    loadFragmentType(request_id, new ListJobBiddedFragment(), Const.Params.BIDDED_FRAGMENT);
                    break;
            }
        }

        btn_available.setBackgroundColor(getResources().getColor(R.color.dark_grey));
        btn_direct.setBackgroundColor(getResources().getColor(R.color.background_color));
        btn_confirm.setBackgroundColor(getResources().getColor(R.color.background_color));
        btn_bidded.setBackgroundColor(getResources().getColor(R.color.background_color));
        addFragment(new ListJobAvailableFragment(),false,true,Const.Params.AVAILABLE_FRAGMENT);
    }

    private void loadFragmentType(String request_id, Fragment fragment, String tag){
        Bundle bundle = new Bundle();
        bundle.putString(Const.Params.REQUEST_ID, request_id);
        fragment.setArguments(bundle);
        addFragment(fragment, false, true, tag);
    }


    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.btn_available:
                btn_available.setBackgroundColor(getResources().getColor(R.color.dark_grey));
                btn_direct.setBackgroundColor(getResources().getColor(R.color.background_color));
                btn_confirm.setBackgroundColor(getResources().getColor(R.color.background_color));
                btn_bidded.setBackgroundColor(getResources().getColor(R.color.background_color));
                addFragment(new ListJobAvailableFragment(),false,true,Const.Params.AVAILABLE_FRAGMENT);
                break;

            case R.id.btn_confirm:
                btn_available.setBackgroundColor(getResources().getColor(R.color.background_color));
                btn_direct.setBackgroundColor(getResources().getColor(R.color.background_color));
                btn_confirm.setBackgroundColor(getResources().getColor(R.color.dark_grey));
                btn_bidded.setBackgroundColor(getResources().getColor(R.color.background_color));
                addFragment(new ListJobConfirmFragment(),false,true, Const.Params.CONFIRM_FRAGMENT);
                break;
            case R.id.btn_bidded:
                btn_available.setBackgroundColor(getResources().getColor(R.color.background_color));
                btn_direct.setBackgroundColor(getResources().getColor(R.color.background_color));
                btn_bidded.setBackgroundColor(getResources().getColor(R.color.dark_grey));
                btn_confirm.setBackgroundColor(getResources().getColor(R.color.background_color));
                addFragment(new ListJobBiddedFragment(),false,true, Const.Params.BIDDED_FRAGMENT);
                break;
            case R.id.btn_direct:
                btn_available.setBackgroundColor(getResources().getColor(R.color.background_color));
                btn_direct.setBackgroundColor(getResources().getColor(R.color.dark_grey));
                btn_bidded.setBackgroundColor(getResources().getColor(R.color.background_color));
                btn_confirm.setBackgroundColor(getResources().getColor(R.color.background_color));
                addFragment(new ListJobDirectFragment(),false,true, Const.Params.DIRECT_FRAGMENT);
                break;
            case R.id.btn_back_jobs:
                onBackPressed();
                break;
        }

    }

    @Override
    public void onBackPressed() {
        startActivity(new Intent(this,MainActivity.class));
    }

    public void addFragment(Fragment fragment, boolean addToBackStack, boolean isAnimate,
                            String tag) {
        FragmentManager manager = getSupportFragmentManager();
        FragmentTransaction ft = manager.beginTransaction();
        if (isAnimate) {
            ft.setCustomAnimations(R.anim.slide_in_right,
                    R.anim.slide_out_left, R.anim.slide_in_left,
                    R.anim.slide_out_right);

        }
        if (addToBackStack) {
            ft.addToBackStack(tag);
        }
        ft.replace(R.id.job_lists, fragment, tag);
        ft.commit();
    }

    @Override
    public void onTaskCompleted(String response, int serviceCode) {

    }
}
