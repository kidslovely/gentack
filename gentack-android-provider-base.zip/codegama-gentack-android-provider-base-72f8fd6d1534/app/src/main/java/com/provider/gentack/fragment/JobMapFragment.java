package com.provider.gentack.fragment;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.location.Location;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.provider.MediaStore;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.Fragment;
import android.support.v4.content.ContextCompat;
import android.support.v4.content.FileProvider;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.aurelhubert.simpleratingbar.SimpleRatingBar;
import com.bumptech.glide.Glide;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapView;
import com.google.android.gms.maps.MapsInitializer;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.provider.gentack.R;
import com.provider.gentack.activity.ChatActivity;
import com.provider.gentack.activity.DetailProfileActivity;
import com.provider.gentack.activity.InfoActivity;
import com.provider.gentack.activity.MainActivity;
import com.provider.gentack.custom_interface.AsyncTaskCompleteListener;
import com.provider.gentack.location.LocationHelper;
import com.provider.gentack.model.RequestDetails;
import com.provider.gentack.networking.HttpRequester;
import com.provider.gentack.networking.MultiPartRequester;
import com.provider.gentack.utils.AndyUtils;
import com.provider.gentack.utils.Const;
import com.provider.gentack.utils.ParseContent;
import com.provider.gentack.utils.PreferenceHelper;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;

import javax.microedition.khronos.opengles.GL;

import de.hdodenhof.circleimageview.CircleImageView;

/**
 * Created by Mahesh on 3/12/2017.
 */

public class JobMapFragment extends Fragment implements View.OnClickListener, LocationHelper.OnLocationReceived, AsyncTaskCompleteListener, OnMapReadyCallback {
    private MainActivity activity;
    private MapView mMapView;
    private GoogleMap googleMap;
    View view;
    private Marker mymarker;
    private SimpleRatingBar rating_bar;
    private CircleImageView iv_client_img;
    private TextView tv_client_name, tv_client_type, tv_req_date;
    private RequestDetails requestDetails;
    private Bundle requestBundle;
    private int jobStatus = 0;
    private Button tripStatusButton;
    private ImageView iv_before, iv_after;
    private Uri uri = null;
    private String imagepath = "", imagepath2 = "";
    private boolean before = false, after = false;
    private Handler reqHandler;
    private boolean isShown = false;
    private Marker client_location;
    private LinearLayout invoice_layout, rate_lay;
    private RelativeLayout lay_images;
    private FloatingActionButton btn_floating_call, btn_floating_message, btn_floating_cancel, btn_floating_info;
    private TextView tv_time, tv_priceperhour, tv_tax_price, tv_total_price, tv_payment_type;
    private Button btn_update_payment, btn_submit_rate;
    private SimpleRatingBar give_rating;
    private EditText et_comment;

    Runnable runnable = new Runnable() {
        public void run() {
            if (requestDetails != null) {
                checkRequestStatus(requestDetails.getRequestId());
                reqHandler.postDelayed(this, 4000);
            }
        }
    };

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        activity = (MainActivity) getActivity();
        LocationHelper lhelper = new LocationHelper(activity);
        lhelper.setLocationReceivedLister(this);
        requestBundle = getArguments();
        reqHandler = new Handler();
        if (requestBundle != null) {
            jobStatus = requestBundle.getInt(Const.PROVIDER_STATUS,
                    Const.IS_PROVIDER_ACCEPTED);
            requestDetails = (RequestDetails) requestBundle.getSerializable(
                    Const.REQUEST_DETAIL);

        }
        try {
            MapsInitializer.initialize(activity);
        } catch (Exception e) {
        }


    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        if (requestDetails != null && requestDetails.getClientPhoneNumber().equals("")) {
            btn_floating_call.setVisibility(View.GONE);
        }
        else {
            btn_floating_call.setVisibility(View.VISIBLE);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.fragment_job_map, container, false);
        mMapView = (MapView) view.findViewById(R.id.jobMapView);
        tv_client_name = (TextView) view.findViewById(R.id.tv_job_client_name);
        tv_client_type = (TextView) view.findViewById(R.id.tv_job_client_type);
        rating_bar = (SimpleRatingBar) view.findViewById(R.id.job_rating_bar);
        iv_client_img = (CircleImageView) view.findViewById(R.id.job_user_pic);
        tripStatusButton = (Button) view.findViewById(R.id.btn_update_status);
        iv_before = (ImageView) view.findViewById(R.id.iv_before);
        iv_after = (ImageView) view.findViewById(R.id.iv_after);
        lay_images = (RelativeLayout) view.findViewById(R.id.lay_images);
        invoice_layout = (LinearLayout) view.findViewById(R.id.invoice_layout);
        rate_lay = (LinearLayout) view.findViewById(R.id.rate_lay);
        et_comment = (EditText) view.findViewById(R.id.et_comment);
        give_rating = (SimpleRatingBar) view.findViewById(R.id.give_rating);
        btn_submit_rate = (Button) view.findViewById(R.id.btn_submit_rate);

        btn_floating_call = (FloatingActionButton) view.findViewById(R.id.btn_floating_call);
        btn_floating_message = (FloatingActionButton) view.findViewById(R.id.btn_floating_message);
        btn_floating_cancel = (FloatingActionButton) view.findViewById(R.id.btn_floating_cancel);
        btn_floating_info = (FloatingActionButton) view.findViewById(R.id.btn_floating_info);
        tv_priceperhour = (TextView) view.findViewById(R.id.tv_priceperhour);
        tv_time = (TextView) view.findViewById(R.id.txt_time);
        tv_tax_price = (TextView) view.findViewById(R.id.tv_tax_price);
        tv_total_price = (TextView) view.findViewById(R.id.tv_total_price);
        tv_payment_type = (TextView) view.findViewById(R.id.tv_payment_type);

        btn_update_payment = (Button) view.findViewById(R.id.btn_update_payment);
        btn_update_payment.setOnClickListener(this);
        btn_floating_call.setOnClickListener(this);
        btn_floating_message.setOnClickListener(this);
        btn_submit_rate.setOnClickListener(this);
        btn_floating_cancel.setOnClickListener(this);
        btn_floating_info.setOnClickListener(this);
        iv_client_img.setOnClickListener(this);

        tripStatusButton.setOnClickListener(this);
        iv_after.setOnClickListener(this);
        iv_before.setOnClickListener(this);

        mMapView.onCreate(savedInstanceState);
        mMapView.getMapAsync(this);
        iv_after.setEnabled(false);

        return view;
    }

    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);

        if (requestDetails != null) {
            tv_client_name.setText(requestDetails.getClientName());

            Glide.with(activity).load(requestDetails.getClientProfile()).into(iv_client_img);
            if (requestDetails.getBefore_image() != null && !requestDetails.getBefore_image().equals("")) {
                Glide.with(activity).load(requestDetails.getBefore_image()).into(iv_before);
                before = true;
            }
            if (requestDetails.getAfter_image() != null && !requestDetails.getAfter_image().equals("")) {
                Glide.with(activity).load(requestDetails.getAfter_image()).into(iv_after);
                after = true;
            }
            if(requestDetails.getJob_type().equals("1")) {
                tv_client_type.setText(requestDetails.getSub_category_name() + " " + "/" + " " + requestDetails.getCurrency() + requestDetails.getUser_price());
            } else {
                tv_client_type.setText(requestDetails.getSub_category_name() + " " + "/" + " " + requestDetails.getCurrency() + requestDetails.getPrice_per_hour());
            }
            startCheckingUpcomingRequests();
            rating_bar.setRating(Integer.valueOf(requestDetails.getUserRating()));
            if (requestDetails.getStatus().equals("7") || requestDetails.getStatus().equals("8")) {
                rate_lay.setVisibility(View.VISIBLE);
                invoice_layout.setVisibility(View.GONE);
            }

        }

        setJobStatus(jobStatus);


    }

    private void startCheckingUpcomingRequests() {
        startCheckRegTimer();
    }

    private void stopCheckingUpcomingRequests() {
        if (reqHandler != null) {
            reqHandler.removeCallbacks(runnable);

            Log.d("mahi", "stop handler");
        }
    }

    public void startCheckRegTimer() {
        reqHandler.postDelayed(runnable, 4000);
    }

    public void checkRequestStatus(int req_id) {
        if (!AndyUtils.isNetworkAvailable(activity)) {

            return;
        }
        HashMap<String, String> map = new HashMap<String, String>();
        map.put(Const.Params.URL, Const.ServiceType.STATUS_CHECK);
        map.put(Const.Params.ID, new PreferenceHelper(activity).getUserId());
        map.put(Const.Params.TOKEN, new PreferenceHelper(activity).getSessionToken());
        Log.d("mahi", "check req status no calling" + map.toString());
        new HttpRequester(activity, Const.POST, map, Const.ServiceCode.STATUS_CHECK, this);

    }


    private void setJobStatus(int jobStatus) {

        switch (jobStatus) {
            case Const.IS_PROVIDER_ACCEPTED:
                tripStatusButton.setText(activity.getResources().getString(R.string.btn_status_txt_1));
                invoice_layout.setVisibility(View.GONE);
                lay_images.setVisibility(View.GONE);
                btn_floating_cancel.setVisibility(View.VISIBLE);
                break;
            case Const.IS_PROVIDER_STARTED:
                tripStatusButton.setText(activity.getResources().getString(R.string.btn_status_txt_2));
                invoice_layout.setVisibility(View.GONE);
                lay_images.setVisibility(View.GONE);
                btn_floating_cancel.setVisibility(View.VISIBLE);
                break;
            case Const.IS_PROVIDER_ARRIVED:
                lay_images.setVisibility(View.VISIBLE);
                tripStatusButton.setText(activity.getResources().getString(R.string.btn_status_txt_3));
                invoice_layout.setVisibility(View.GONE);
                btn_floating_cancel.setVisibility(View.GONE);
                break;
            case Const.IS_PROVIDER_SERVICE_STARTED:
                lay_images.setVisibility(View.VISIBLE);
                iv_after.setEnabled(true);
                iv_before.setEnabled(false);
                tripStatusButton.setText(activity.getResources().getString(R.string.btn_status_txt_4));
                invoice_layout.setVisibility(View.GONE);
                btn_floating_cancel.setVisibility(View.GONE);
                break;
            case Const.IS_PROVIDER_SERVICE_COMPLETED:
                if (!requestDetails.getStatus().equals("7") && !requestDetails.getStatus().equals("8")) {
                    invoice_layout.setVisibility(View.VISIBLE);
                    lay_images.setVisibility(View.GONE);
                    tripStatusButton.setVisibility(View.GONE);
                    btn_floating_cancel.setVisibility(View.GONE);
                    tv_priceperhour.setText(requestDetails.getCurrency() + " " + requestDetails.getBaseprice());
                    tv_time.setText(requestDetails.getTime() + "hrs");
                    tv_tax_price.setText(requestDetails.getCurrency() + " " + requestDetails.getTaxprice());
                    tv_total_price.setText(requestDetails.getCurrency() + " " + requestDetails.getTotal());
                    tv_payment_type.setText("Pay Via -" + " " + requestDetails.getPayment_type());
                } else {
                    invoice_layout.setVisibility(View.GONE);
                    lay_images.setVisibility(View.GONE);
                    tripStatusButton.setVisibility(View.GONE);
                    rate_lay.setVisibility(View.VISIBLE);
                }
                break;

            default:
                break;
        }
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.job_user_pic:
                Log.d("IMAGECLICK", "YES");
                Intent inte= new Intent(activity, DetailProfileActivity.class);
                inte.putExtra(Const.Params.USER_ID, requestDetails.getClientId());
                startActivity(inte);
                break;
            case R.id.btn_update_status:
                switch (jobStatus) {
                    case Const.IS_PROVIDER_ACCEPTED:
                        iv_after.setEnabled(false);
                        providerStarted();
                        break;
                    case Const.IS_PROVIDER_STARTED:
                        iv_after.setEnabled(false);
                        providerArrived();
                        break;
                    case Const.IS_PROVIDER_ARRIVED:
                        providerServiceStarted();
                        break;
                    case Const.IS_PROVIDER_SERVICE_STARTED:
                        iv_after.setEnabled(true);
                        iv_before.setEnabled(false);
                        providerServiceCompleted();

                        break;

                    default:
                        break;
                }
                break;
            case R.id.btn_floating_cancel:
                new AlertDialog.Builder(activity)
                        .setTitle(null)
                        .setMessage("Are you sure you want to cancel this request?")
                        .setPositiveButton(android.R.string.yes, new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int which) {
                                // continue with delete
                                dialog.dismiss();
                                cancelrequest();
                            }
                        })
                        .setNegativeButton(android.R.string.no, new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int which) {
                                // do nothing
                                dialog.dismiss();
                            }
                        })
                        .setIcon(android.R.drawable.ic_dialog_alert)
                        .show();

                break;
            case R.id.btn_update_payment:
                if (requestDetails.getPayment_type().equals("card")) {

                    invoice_layout.setVisibility(View.GONE);
                    rate_lay.setVisibility(View.VISIBLE);
                } else {
                    if (requestDetails.getStatus().equals("5") && requestDetails.getPayment_type().equals("cod")) {

                    } else {

                        confirmpayment();

                    }

                }
                break;
            case R.id.btn_submit_rate:
                if (give_rating.getRating() == 0 || et_comment.getText().toString().length() == 0) {
                    AndyUtils.showShortToast("Please rate provider!", activity);
                } else {
                    giverate();
                }
                break;
            case R.id.btn_floating_call:
                if (requestDetails != null) {
                    Intent intent = new Intent(Intent.ACTION_DIAL, Uri.fromParts("tel", requestDetails.getClientPhoneNumber(), null));
                    startActivity(intent);
                }

                break;
            case R.id.btn_floating_message:

                if (requestDetails != null) {
                    Bundle mbundle = new Bundle();
                    mbundle.putString("request_id", String.valueOf(requestDetails.getRequestId()));
                    mbundle.putString("user_picture", requestDetails.getClientProfile());
                    mbundle.putString("reciver_id", requestDetails.getClientId());
                    Intent i = new Intent(activity, ChatActivity.class);
                    i.putExtras(mbundle);
                    activity.startActivity(i);
                }
                break;
            case R.id.btn_floating_info:
                if (requestDetails != null){
                    Intent i = new Intent(activity, InfoActivity.class);
                    i.putExtra(Const.Params.REQUEST_ID, String.valueOf(requestDetails.getRequestId()));
                    activity.startActivity(i);
                }
                break;
            case R.id.iv_before:
                if (before) {
                    new AlertDialog.Builder(activity, R.style.DialogTheme)
                            .setMessage("Are you sure to upload again? This will result to delete the already uploaded one.")
                            .setPositiveButton("YES", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    cameraintentbefore();
                                }
                            })
                            .setNegativeButton("NO", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    dialog.cancel();
                                }
                            })
                            .create().show();
                }
                else
                    cameraintentbefore();
                break;
            case R.id.iv_after:
                if (after) {
                    new AlertDialog.Builder(activity, R.style.DialogTheme)
                            .setMessage("Are you sure to upload again? This will result to delete the already uploaded one.")
                            .setPositiveButton("YES", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    cameraintentafter();
                                }
                            })
                            .setNegativeButton("NO", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    dialog.cancel();
                                }
                            })
                            .create().show();
                }
                else
                    cameraintentafter();
                break;
            default:
                break;
        }

    }

    private void cancelrequest() {

        if (!AndyUtils.isNetworkAvailable(activity)) {

            return;
        }
        AndyUtils.showSimpleProgressDialog(activity, activity.getResources().getString(R.string.txt_ratingy), false);
        HashMap<String, String> map = new HashMap<String, String>();
        map.put(Const.Params.URL, Const.ServiceType.CANCEl_BID_REQUEST);
        map.put(Const.Params.ID, new PreferenceHelper(activity).getUserId());
        map.put(Const.Params.TOKEN, new PreferenceHelper(activity).getSessionToken());
        map.put(Const.Params.REQUEST_ID, String.valueOf(requestDetails.getRequestId()));
        map.put("provider_reason", "non");
        new HttpRequester(activity, Const.POST, map,
                Const.ServiceCode.CANCEl_BID_REQUEST, this);

    }

    private void giverate() {

        if (!AndyUtils.isNetworkAvailable(activity)) {

            return;
        }
        AndyUtils.showSimpleProgressDialog(activity, activity.getResources().getString(R.string.txt_ratingy), false);
        HashMap<String, String> map = new HashMap<String, String>();
        map.put(Const.Params.URL, Const.ServiceType.PROVIDER_RATING);
        map.put(Const.Params.ID, new PreferenceHelper(activity).getUserId());
        map.put(Const.Params.TOKEN, new PreferenceHelper(activity).getSessionToken());
        map.put(Const.Params.REQUEST_ID, String.valueOf(requestDetails.getRequestId()));
        map.put(Const.Params.COMMENT, et_comment.getText().toString());
        map.put(Const.Params.RATE, String.valueOf(give_rating.getRating()));

        new HttpRequester(activity, Const.POST, map,
                Const.ServiceCode.PROVIDER_RATING, this);
    }

    private void confirmpayment() {

        if (!AndyUtils.isNetworkAvailable(activity)) {

            return;
        }
        AndyUtils.showSimpleProgressDialog(activity, activity.getResources().getString(R.string.txt_confirm_pay), false);
        HashMap<String, String> map = new HashMap<String, String>();
        map.put(Const.Params.URL, Const.ServiceType.PROVIDER_CONFIRM_PAYMENT_URL);
        map.put(Const.Params.ID, new PreferenceHelper(activity).getUserId());
        map.put(Const.Params.TOKEN, new PreferenceHelper(activity).getSessionToken());
        map.put(Const.Params.REQUEST_ID, String.valueOf(requestDetails.getRequestId()));

        new HttpRequester(activity, Const.POST, map,
                Const.ServiceCode.PROVIDER_CONFIRM_PAYMENT_URL, this);
    }

    private void providerServiceCompleted() {
        if (!AndyUtils.isNetworkAvailable(activity)) {

            return;
        }
        AndyUtils.showSimpleProgressDialog(activity, activity.getResources().getString(R.string.txt_respod), false);
        HashMap<String, String> map = new HashMap<String, String>();
        map.put(Const.Params.URL, Const.ServiceType.PROVIDER_SERVICE_COMPLETED_URL);
        map.put(Const.Params.ID, new PreferenceHelper(activity).getUserId());
        map.put(Const.Params.TOKEN, new PreferenceHelper(activity).getSessionToken());
        map.put(Const.Params.REQUEST_ID, String.valueOf(requestDetails.getRequestId()));
        map.put(Const.Params.AFTER_IMG, imagepath2);
        if (imagepath2.equals("") || null == imagepath2) {
            new HttpRequester(activity, Const.POST, map,
                    Const.ServiceCode.PROVIDER_SERVICE_COMPLETED, this);
        } else {
            new MultiPartRequester(activity, map,
                    Const.ServiceCode.PROVIDER_SERVICE_COMPLETED, this);
        }

    }

    private void providerServiceStarted() {
        if (!AndyUtils.isNetworkAvailable(activity)) {

            return;
        }
        AndyUtils.showSimpleProgressDialog(activity, activity.getResources().getString(R.string.txt_respod), false);
        HashMap<String, String> map = new HashMap<String, String>();
        map.put(Const.Params.URL, Const.ServiceType.PROVIDER_SERVICE_STARTED_URL);
        map.put(Const.Params.ID, new PreferenceHelper(activity).getUserId());
        map.put(Const.Params.TOKEN, new PreferenceHelper(activity).getSessionToken());
        map.put(Const.Params.REQUEST_ID, String.valueOf(requestDetails.getRequestId()));
        map.put(Const.Params.BEFORE_IMG, imagepath);
        Log.d("mahi", "map 3" + map.toString());
        if (imagepath.equals("") || null == imagepath) {
            new HttpRequester(activity, Const.POST, map,
                    Const.ServiceCode.PROVIDER_SERVICE_STARTED, this);
        } else {
            new MultiPartRequester(activity, map,
                    Const.ServiceCode.PROVIDER_SERVICE_STARTED, this);
        }

    }

    private void providerArrived() {
        if (!AndyUtils.isNetworkAvailable(activity)) {

            return;
        }
        AndyUtils.showSimpleProgressDialog(activity, activity.getResources().getString(R.string.txt_respod), false);
        HashMap<String, String> map = new HashMap<String, String>();
        map.put(Const.Params.URL, Const.ServiceType.PROVIDER_ARRIVED_URL);
        map.put(Const.Params.ID, new PreferenceHelper(activity).getUserId());
        map.put(Const.Params.TOKEN, new PreferenceHelper(activity).getSessionToken());
        map.put(Const.Params.REQUEST_ID, String.valueOf(requestDetails.getRequestId()));
        Log.d("mahi", "map 2" + map.toString());
        new HttpRequester(activity, Const.POST, map,
                Const.ServiceCode.PROVIDER_ARRIVED, this);
    }

    private void providerStarted() {
        if (!AndyUtils.isNetworkAvailable(activity)) {

            return;
        }
        AndyUtils.showSimpleProgressDialog(activity, activity.getResources().getString(R.string.txt_respod), false);
        HashMap<String, String> map = new HashMap<String, String>();
        map.put(Const.Params.URL, Const.ServiceType.PROVIDER_STARTED_URL);
        map.put(Const.Params.ID, new PreferenceHelper(activity).getUserId());
        map.put(Const.Params.TOKEN, new PreferenceHelper(activity).getSessionToken());
        map.put(Const.Params.REQUEST_ID, String.valueOf(requestDetails.getRequestId()));
        Log.d("mahi", "map 1" + map.toString());
        new HttpRequester(activity, Const.POST, map,
                Const.ServiceCode.PROVIDER_STARTED, this);
    }

    @Override
    public void onMapReady(GoogleMap mgoogleMap) {
        googleMap = mgoogleMap;
        if (googleMap != null) {
            googleMap.getUiSettings().setMyLocationButtonEnabled(false);
            googleMap.getUiSettings().setMapToolbarEnabled(true);


            if (ActivityCompat.checkSelfPermission(activity, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(activity, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                //    ActivityCompat#requestPermissions
                // here to request the missing permissions, and then overriding
                //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
                //                                          int[] grantResults)
                // to handle the case where the user grants the permission. See the documentation
                // for ActivityCompat#requestPermissions for more details.
                return;
            }

            googleMap.setMyLocationEnabled(true);

            LatLng latlng = new LatLng(Double.valueOf(requestDetails.getsLatitude()), Double.valueOf(requestDetails.getsLongitude()));
            MarkerOptions opt2 = new MarkerOptions();
            opt2.position(latlng);
            opt2.title(activity.getResources().getString(R.string.txt_client_location));
            opt2.icon(BitmapDescriptorFactory.fromResource(R.drawable.user_pin));
            client_location = googleMap.addMarker(opt2);
            googleMap.animateCamera(CameraUpdateFactory.newLatLngZoom(latlng,
                    13));
        }
    }

    @Override
    public void onTaskCompleted(String response, int serviceCode) {
        switch (serviceCode) {
            case Const.ServiceCode.PROVIDER_STARTED:

                try {

                    JSONObject job1 = new JSONObject(response);
                    if (job1.getString("success").equals("true")) {
                        AndyUtils.removeProgressDialog();
                        jobStatus = Const.IS_PROVIDER_STARTED;
                        setJobStatus(jobStatus);
                    } else {
                        AndyUtils.removeProgressDialog();
                    }


                } catch (JSONException e) {
                    e.printStackTrace();
                }
                break;
            case Const.ServiceCode.PROVIDER_ARRIVED:

                try {

                    JSONObject job1 = new JSONObject(response);
                    if (job1.getString("success").equals("true")) {
                        AndyUtils.removeProgressDialog();

                        jobStatus = Const.IS_PROVIDER_ARRIVED;
                        setJobStatus(jobStatus);
                    } else {
                        AndyUtils.removeProgressDialog();
                    }


                } catch (JSONException e) {
                    e.printStackTrace();
                }

                break;
            case Const.ServiceCode.PROVIDER_SERVICE_STARTED:

                try {

                    JSONObject job1 = new JSONObject(response);
                    if (job1.getString("success").equals("true")) {
                        AndyUtils.removeProgressDialog();
                        jobStatus = Const.IS_PROVIDER_SERVICE_STARTED;
                        setJobStatus(jobStatus);

                    } else {
                        AndyUtils.removeProgressDialog();
                    }


                } catch (JSONException e) {
                    e.printStackTrace();
                }

                break;
            case Const.ServiceCode.PROVIDER_SERVICE_COMPLETED:
                Log.d("mahi", "walk completed" + response);
                try {

                    JSONObject job1 = new JSONObject(response);
                    if (job1.getString("success").equals("true")) {
                        AndyUtils.removeProgressDialog();
                        jobStatus = Const.IS_PROVIDER_SERVICE_COMPLETED;
                        setJobStatus(jobStatus);
                        requestDetails = new ParseContent(activity).parseRequestArrayStatus(response);

                        tv_priceperhour.setText(requestDetails.getCurrency() + " " + requestDetails.getBaseprice());
                        tv_time.setText(requestDetails.getTime()+ "hrs");
                        tv_tax_price.setText(requestDetails.getCurrency() + " " + requestDetails.getTaxprice());
                        tv_total_price.setText(requestDetails.getCurrency() + " " + requestDetails.getTotal());
                        tv_payment_type.setText("Pay Via -" + " " + requestDetails.getPayment_type());
                    } else {
                        AndyUtils.removeProgressDialog();
                    }


                } catch (JSONException e) {
                    e.printStackTrace();
                }

                break;
            case Const.ServiceCode.PROVIDER_RATING:
                Log.d("mahi", "walker rate" + response);
                AndyUtils.removeProgressDialog();
                try {

                    JSONObject job1 = new JSONObject(response);
                    if (job1.getString("success").equals("true")) {
                        AndyUtils.showLongToast("Rated Successfully!", activity);
                        new PreferenceHelper(activity).clearRequestData();
                        Intent i = new Intent(activity, MainActivity.class);
                        startActivity(i);

                    } else {

                    }


                } catch (JSONException e) {
                    e.printStackTrace();
                }

                break;
            case Const.ServiceCode.CANCEl_BID_REQUEST:
                Log.d("mahi", "walker cancel" + response);
                AndyUtils.removeProgressDialog();
                try {

                    JSONObject job1 = new JSONObject(response);
                    if (job1.getString("success").equals("true")) {
                        AndyUtils.showLongToast("Request cancelled Successfully!", activity);

                        new PreferenceHelper(activity).clearRequestData();
                        Intent i = new Intent(activity, MainActivity.class);
                        startActivity(i);

                    } else {

                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                }

                break;
            case Const.ServiceCode.PROVIDER_CONFIRM_PAYMENT_URL:
                Log.d("mahi", "pay completed" + response);
                AndyUtils.removeProgressDialog();
                try {

                    JSONObject job1 = new JSONObject(response);
                    if (job1.getString("success").equals("true")) {

                        invoice_layout.setVisibility(View.GONE);
                        rate_lay.setVisibility(View.VISIBLE);

                    } else {
                        AndyUtils.removeProgressDialog();
                        AndyUtils.showLongToast("Waiting for Payment from Customer!", activity);
                    }


                } catch (JSONException e) {
                    e.printStackTrace();
                }

                break;
            case Const.ServiceCode.STATUS_CHECK:
                AndyUtils.appLog("Ashutosh", "TravelCheckStatusResponse" + response);
                JSONObject jsonObject = null;
                try {
                    jsonObject = new JSONObject(response);
                    JSONObject dataObjectArray = jsonObject.getJSONObject("data");

                    if (dataObjectArray == null) {

                    } else {
                        requestDetails = new ParseContent(activity).parseRequestArrayStatus(response);
                        if (requestDetails.getStatus().equals("5") && requestDetails.getPayment_type().equals("cod")) {
                            btn_update_payment.setText("Waiting for Payment");

                        } else {
                            btn_update_payment.setText("Payment Received");
                            btn_update_payment.setEnabled(true);
                        }
                    }


                } catch (JSONException e) {
                    e.printStackTrace();
                    if (!isShown) {
                        if (isAdded()) {
                            AlertDialog.Builder builder = new AlertDialog.Builder(activity);
                            builder.setMessage("Request got cancelled by User..!!")
                                    .setCancelable(false)
                                    .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                                        public void onClick(DialogInterface dialog, int id) {
                                            new PreferenceHelper(activity).clearRequestData();
                                            dialog.dismiss();
                                            stopCheckingUpcomingRequests();
                                            Intent intent = new Intent(activity, MainActivity.class);
                                            activity.startActivity(intent);
                                            activity.finish();
                                        }
                                    });

                            AlertDialog alert = builder.create();
                            alert.show();

                        }
                        isShown = true;
                    }
                }
                break;
            default:
                break;
        }
    }

    @Override
    public void onLocationReceived(LatLng latlong) {

    }

    @Override
    public void onLocationReceived(Location location) {
        if (location != null) {
            LatLng latLng = new LatLng(location.getLatitude(), location.getLongitude());

            if (mymarker == null) {
                MarkerOptions opt = new MarkerOptions();
                opt.position(latLng);
                opt.title(activity.getResources().getString(R.string.txt_location));
                opt.icon(BitmapDescriptorFactory.fromResource(R.drawable.provider_pin));
                mymarker = googleMap.addMarker(opt);

                googleMap.animateCamera(CameraUpdateFactory.newLatLngZoom(latLng,
                        13));
            } else {
                mymarker.setPosition(latLng);
            }
        }
    }

    @Override
    public void onConntected(Bundle bundle) {

    }

    @Override
    public void onConntected(Location location) {

    }

    @Override
    public void onSaveInstanceState(Bundle outState) {
        //No call for super(). Bug on API Level > 11.
        mMapView.onSaveInstanceState(outState);
    }

    @Override
    public void onPause() {
        super.onPause();

        mMapView.onPause();
    }

    @Override
    public void onStop() {
        super.onStop();

    }

    @Override
    public void onResume() {
        super.onResume();
        activity.currentFragment = Const.Params.JOBMAP_FRAGMENT;
        mMapView.onResume();

    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (mMapView != null) {
            mMapView.onDestroy();
        }

    }

    @Override
    public void onActivityResult(int requestCode, final int resultCode, final Intent data) {
        Log.d("mahi", "req code" + requestCode);
        switch (requestCode) {

            case Const.TAKE_PHOTO:
                if (resultCode == Activity.RESULT_OK) {
                    iv_before.post(new Runnable() {
                        @Override
                        public void run() {
                            Glide.with(activity).load(imagepath).into(iv_before);
                        }
                    });
                    before = true;
                }
                else {
                    before = false;
                    imagepath = "";
                    iv_before.post(new Runnable() {
                        @Override
                        public void run() {
                            Glide.with(activity).load(R.drawable.before_img).into(iv_before);
                        }
                    });
                }
                break;
            case Const.TAKE_PHOTO2:
                if (resultCode == Activity.RESULT_OK) {
                    iv_after.post(new Runnable() {
                        @Override
                        public void run() {
                            Glide.with(activity).load(imagepath2).into(iv_after);
                        }
                    });
                    after = true;
                }
                else {
                    after = false;
                    imagepath2 = "";
                    iv_after.post(new Runnable() {
                        @Override
                        public void run() {
                            Glide.with(activity).load(R.drawable.after_img).into(iv_after);
                        }
                    });
                }
                break;

        }
    }

    private void cameraintentbefore() {
        Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        if (takePictureIntent.resolveActivity(activity.getPackageManager()) != null) {
            File photoFile = null;
            try {
                photoFile = createImageFile(1);
            } catch (IOException ex) {
                ex.printStackTrace();
            }

            if (photoFile != null) {
                Uri photoUri = FileProvider.getUriForFile(activity,
                                        "com.provider.gentack.fileprovider",
                                                photoFile);
                takePictureIntent.putExtra(MediaStore.EXTRA_OUTPUT, photoUri);
                startActivityForResult(takePictureIntent, Const.TAKE_PHOTO);
            }
        }
    }

    private void cameraintentafter() {
        Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        if (takePictureIntent.resolveActivity(activity.getPackageManager()) != null) {
            File photoFile = null;
            try {
                photoFile = createImageFile(2);
            } catch (IOException ex) {
                ex.printStackTrace();
            }

            if (photoFile != null) {
                Uri photoUri = FileProvider.getUriForFile(activity,
                         "com.provider.gentack.fileprovider",
                        photoFile);
                takePictureIntent.putExtra(MediaStore.EXTRA_OUTPUT, photoUri);
                startActivityForResult(takePictureIntent, Const.TAKE_PHOTO2);
            }
        }
    }

    private File createImageFile(int type) throws IOException {
        // Create an image file name
        String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(new Date());
        String imageFileName = "JPEG_" + timeStamp + "_";
        File storageDir = activity.getExternalFilesDir(Environment.DIRECTORY_PICTURES);
        File image = File.createTempFile(
                imageFileName,  /* prefix */
                ".jpg",         /* suffix */
                storageDir      /* directory */
        );

        // Save a file: path for use with ACTION_VIEW intents
        if (type == 1)
            imagepath = image.getAbsolutePath();
        else
            imagepath2 = image.getAbsolutePath();
        return image;
    }
}
