package com.provider.gentack.model;

/**
 * Created by root on 2/3/16.
 */
public class SubCategory {

    private String subcatimg;
    private String subcatName;
    private String price;
    private String subcatid;
    private boolean ischecked;



    public String getSubcatimg() {
        return subcatimg;
    }

    public void setSubcatimg(String subcatimg) {
        this.subcatimg = subcatimg;
    }

    public String getSubcatName() {
        return subcatName;
    }

    public void setSubcatName(String subcatName) {
        this.subcatName = subcatName;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public String getSubcatid() {
        return subcatid;
    }

    public void setSubcatid(String subcatid) {
        this.subcatid = subcatid;
    }

    public boolean ischecked() {
        return ischecked;
    }

    public void setIschecked(boolean ischecked) {
        this.ischecked = ischecked;
    }
}
