package com.provider.gentack.fragment;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ExpandableListView;

import com.provider.gentack.R;
import com.provider.gentack.activity.LoginRegisterActivity;
import com.provider.gentack.activity.MainActivity;
import com.provider.gentack.adapter.ExpandElementsAdapter;
import com.provider.gentack.custom_interface.AsyncTaskCompleteListener;
import com.provider.gentack.model.Category;
import com.provider.gentack.model.SubCategory;
import com.provider.gentack.networking.HttpRequester;
import com.provider.gentack.utils.AndyUtils;
import com.provider.gentack.utils.Const;
import com.provider.gentack.utils.PreferenceHelper;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;

/**
 * Created by Mahesh on 4/9/2017.
 */

public class SelectServiceAfterReg  extends Fragment implements View.OnClickListener, AsyncTaskCompleteListener, ExpandElementsAdapter.AdapterCallback, ExpandElementsAdapter.AdapterRemoveCallback {
    private ExpandableListView expandableListView;

    private ExpandElementsAdapter mservicesAdapter;
    private Button btn_save_service;
    ArrayList<String> pricelst = new ArrayList<String>();
    ArrayList<String> service_idlst = new ArrayList<String>();
    private LoginRegisterActivity activity;


    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        activity = (LoginRegisterActivity) getActivity();

    }

    private void getService() {
        if (!AndyUtils.isNetworkAvailable(getActivity())) {
            AndyUtils.showShortToast(getString(R.string.no_internet), getActivity());
            return;
        }
        AndyUtils.showSimpleProgressDialog(getActivity(), getString(R.string.loading_services), false);
        HashMap<String, String> map = new HashMap<String, String>();
        map.put(Const.Params.URL, Const.ServiceType.GET_SERVICES);
        map.put(Const.Params.ID, new PreferenceHelper(getActivity()).getUserId());
        map.put(Const.Params.TOKEN, new PreferenceHelper(getActivity()).getSessionToken());

        AndyUtils.appLog("Ashutosh", "RegisterMap" + map);
        new HttpRequester(getActivity(), Const.POST, map, Const.ServiceCode.GET_SERVICES, this);
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.select_service_reg, container, false);
        expandableListView = (ExpandableListView) view.findViewById(R.id.expandableListView);
        btn_save_service = (Button) view.findViewById(R.id.btn_save_service);
        btn_save_service.setOnClickListener(this);

        getService();
        /*list_services.setOnGroupExpandListener(new ExpandableListView.OnGroupExpandListener() {
            int previousGroup = -1;

            @Override
            public void onGroupExpand(int groupPosition) {
                if ((previousGroup != -1) && (groupPosition != previousGroup)) {
                    list_services.collapseGroup(previousGroup);
                }
                previousGroup = groupPosition;
            }
        });*/

       /* list_services.setOnChildClickListener(new ExpandableListView.OnChildClickListener() {
            @Override
            public boolean onChildClick(ExpandableListView expandableListView, View view, int groupPosition, int childPosition, long id) {

                return true;
            }
        });*/

        return view;
    }


    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.btn_save_service:
                sendatatoserver();
                break;
            default:
                break;
        }

    }

    private void sendatatoserver() {
        if(service_idlst.size()==0){
            AndyUtils.showLongToast("Please select services to save",getActivity());
        } else{
            setService(pricelst, service_idlst);
        }

    }

    @Override
    public void onResume() {
        super.onResume();
        activity.currentRegFragment = Const.Params.SERVICE_FRAGMENT;
    }

    private void setService(ArrayList<String> selected_prices, ArrayList<String> selected_service) {

        if (!AndyUtils.isNetworkAvailable(getActivity())) {
            AndyUtils.showShortToast(getString(R.string.no_internet), getActivity());
            return;
        }
        AndyUtils.showSimpleProgressDialog(getActivity(), getString(R.string.please_wait), false);

        HashMap<String, String> map = new HashMap<String, String>();
        map.put(Const.Params.URL, Const.ServiceType.SAVE_SERVICES);
        map.put(Const.Params.ID, new PreferenceHelper(getActivity()).getUserId());
        map.put(Const.Params.TOKEN, new PreferenceHelper(getActivity()).getSessionToken());
        for(int i=0;i<selected_service.size();i++){
            map.put(selected_service.get(i), selected_prices.get(i));
        }
        AndyUtils.appLog("Ashutosh", "RegisterMap" + map);
        new HttpRequester(getActivity(), Const.POST, map, Const.ServiceCode.SAVE_SERVICES, this);
    }

    @Override
    public void onTaskCompleted(String response, int serviceCode) {
        switch (serviceCode) {
            case Const.ServiceCode.GET_SERVICES:
                AndyUtils.removeProgressDialog();

                try {
                    JSONObject job = new JSONObject(response);
                    ArrayList<Category> services = new ArrayList<Category>();
                    if (job.optString("success").equals("true")) {
                        JSONArray dataArray = job.getJSONArray("data");

                        for (int i = 0; i < dataArray.length(); i++) {
                            JSONObject jcat = dataArray.getJSONObject(i);

                            JSONArray subArray = jcat.getJSONArray("sub_category");
                            ArrayList<SubCategory> subcatlst = new ArrayList<SubCategory>();
                            Category serdata = null;
                            for (int j = 0; j < subArray.length(); j++) {
                                JSONObject sub = subArray.getJSONObject(j);
                                SubCategory subcat = new SubCategory();
                                serdata = new Category();
                                subcat.setSubcatid(sub.getString("sub_category_id"));
                                subcat.setSubcatimg(sub.getString("sub_category_picture"));
                                subcat.setPrice(sub.getString("price_per_hour"));
                                subcat.setSubcatName(sub.getString("sub_category_name"));
                                subcatlst.add(subcat);

                                serdata.setCategory_title(jcat.getString("category_name"));
                                serdata.setSubcat(subcatlst);

                            }

                            services.add(serdata);

                        }
                        if (services != null) {

                            mservicesAdapter = new ExpandElementsAdapter(getActivity(), services, this, this);
                            expandableListView.setAdapter(mservicesAdapter);
                        }
                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                    AndyUtils.removeProgressDialog();
                }


                break;
            case Const.ServiceCode.SAVE_SERVICES:
                AndyUtils.removeProgressDialog();
                try {
                    JSONObject job = new JSONObject(response);
                    if (job.optString("success").equals("true")) {
                        AndyUtils.showShortToast("Service Saved Successfully!", getActivity());
                        pricelst.clear();
                        service_idlst.clear();
                        Intent i = new Intent(activity, MainActivity.class);
                        startActivity(i);
                        activity.finish();
                    } else {
                        AndyUtils.showShortToast("Failed to save services!", getActivity());
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                break;

        }

    }


    @Override
    public void onMethodCallback(ArrayList<String> prices, ArrayList<String> service_id) {
        pricelst = prices;
        service_idlst = service_id;

    }

    @Override
    public void onMethodRemoveCallback(ArrayList<String> subelement_price, ArrayList<String> subelement_id) {
        pricelst = subelement_price;
        service_idlst = subelement_id;
    }
}