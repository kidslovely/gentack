package com.provider.gentack.utils;

/**
 * Created by user on 2/28/2017.
 */

public class Const {


    public static final String PREF_NAME = "JobRabbit_User";
    public static final String ANDROID = "android";
    public static final String MANUAL = "manual";
    public static final String FACEBOOK = "facebook";
    public static final String GOOGLE = "google";
    public static final String SUCCESS = "success";
    public static final String TRUE = "true";
    public static final String TYPE_AUTOCOMPLETE = "/autocomplete";
    public static final String TYPE_NEAR_BY = "/nearbysearch";
    public static final String OUT_JSON = "/json";
    public static final String FIRST_TIME = "first_time";
    public static final String PARKING_TYPE = "parking_type";
    public static final int TIMEOUT = 20000;
    public static final int MAX_RETRY = 3;
    public static final float DEFAULT_BACKOFF_MULT = 1f;
    public static final int CHOOSE_PHOTO = 151;
    public static final int TAKE_PHOTO = 152;
    public static final int TAKE_PHOTO2 = 153;
    public static int GET = 0;
    public static int POST = 1;
    public static final int NO_REQUEST = -1;


    // error code
    public static final int INVALID_TOKEN = 104;
    public static final int REQUEST_ID_NOT_FOUND = 408;
    public static final int INVALID_REQUEST_ID = 101;

    //Provider status

    public static final int IS_PROVIDER_ACCEPTED = 2;
    public static final int IS_PROVIDER_STARTED = 3;
    public static final int IS_PROVIDER_ARRIVED = 4;
    public static final int IS_PROVIDER_SERVICE_STARTED = 5;
    public static final int IS_PROVIDER_SERVICE_COMPLETED = 6;
    public static final int IS_USER_RATED = 7;

    public static final String REQUEST_DETAIL = "requestDetails";
    public static final String PROVIDER_STATUS = "provider_status";
    public static final String STATUS = "status";


    public class Params {

        public static final String PICTURE = "picture";
        public static final String URL = "url";
        public static final String SINGIN_SIGNUP = "signin_signup";
        public static final String LOGIN_FRAGMENT = "login_fragment";
        public static final String SIGNUP_FRAGMENT = "signup_fragment";
        public static final String SERVICE_FRAGMENT = "service_fragment";
        public static final String HOMEMAP_FRAGMENT = "homemap_fragment";
        public static final String JOBMAP_FRAGMENT = "jobmap_fragment";
        public static final String FRAGMENT_TYPE = "fragment_type";
        public static final String AVAILABLE_FRAGMENT = "available_fragment";
        public static final String ONGOING_FRAGMENT = "ongoing_fragment";
        public static final String CONFIRM_FRAGMENT = "confirm_fragment";
        public static final String BIDDED_FRAGMENT = "bidded_fragment";
        public static final String DIRECT_FRAGMENT = "direct_fragment";

        public static final String DEVICE_TYPE = "device_type";
        public static final String DEVICE_TOKEN = "device_token";
        public static final String LOGIN_BY = "login_by";
        public static final String EMAIL = "email";
        public static final String PASSWORD = "password";
        public static final String TIMEZONE = "timezone";
        public static final String ID = "id";
        public static final String USER_ID = "user_id";
        public static final String NAME = "name";
        public static final String MOBILE = "mobile";
        public static final String TOKEN = "token";
        public static final String STATUS = "status";
        public static final String GATEWAY = "gateway";
        public static final String ACCESS_TOKEN = "access_token";
        public static final String ADDRESS = "address";
        public static final String FROM = "from";
        public static final String LATITUDE = "lat";
        public static final String LIMIT = "limit";
        public static final String LATTITUDE = "latitude";
        public static final String LONGITUDE = "longitude";

        public static final String PROVIDER_ID = "provider_id";
        public static final String PROVIDER_NAME = "provider_name";

        public static final String REQUEST_ID = "request_id";
        public static final String AFTER_IMG = "after_image";
        public static final String BEFORE_IMG = "before_image";
        public static final String RATE = "rating";
        public static final String COMMENT = "comment";
        public static final String SOCIAL_ID = "social_unique_id";
    }

    public class ServiceType {
        public static final String HOST_URL = "http://gentack.info";
        public static final String SOCKET_URL = "http://gentack.info:3001";
        public static final String BASE_URL = HOST_URL + "/api/provider/";
        public static final String POST_REGISTRATION_URL = BASE_URL + "register";
        public static final String POST_LOGIN_URL = BASE_URL + "login";
        public static final String GET_SERVICES = BASE_URL + "services";
        public static final String SAVE_SERVICES = BASE_URL + "services_save";
        public static final String GET_CATEGORY = HOST_URL + "categories";
        public static final String GET_SUBCATEGORY = HOST_URL + "sub_categories";
        public static final String POST_SOCIAL_LOGIN_URL = BASE_URL + "login/social";
        public static final String POST_FORGOT_PASSWORD_URL = BASE_URL + "forgot_password";
        public static final String CHANGE_PASSWORD = BASE_URL + "change_password";

        public static final String CHECK_AVAILABILITY = BASE_URL + "check_available";
        public static final String SET_AVAILABILITY = BASE_URL + "available_update";
        public static final String STATUS_CHECK = BASE_URL + "request_status_check";
        public static final String INCOMING_REQUEST = BASE_URL + "incoming_request";
        public static final String UPDATE_LOCATION_URL = BASE_URL + "location_update";
        public static final String ACCEPT_REQUEST = BASE_URL + "request_accept";
        public static final String REJECT_REQUEST = BASE_URL + "request_reject";
        public static final String PROVIDER_STARTED_URL = BASE_URL + "provider_started";
        public static final String PROVIDER_ARRIVED_URL = BASE_URL + "provider_arrived";
        public static final String PROVIDER_SERVICE_STARTED_URL = BASE_URL + "request_started";
        public static final String PROVIDER_SERVICE_COMPLETED_URL = BASE_URL + "request_completed";
        public static final String PROVIDER_CONFIRM_PAYMENT_URL = BASE_URL + "request_payment_confirm";
        public static final String GET_PROFILE = BASE_URL + "profile";
        public static final String SAVE_PROFILE = BASE_URL + "update_profile";
        public static final String PROVIDER_RATING = BASE_URL + "request_rating";
        public static final String GET_HISTORY = BASE_URL + "history";
        public static final String AVAILABLE_JOBS = BASE_URL + "available_requests";
        public static final String ONGOING_JOBS = BASE_URL + "ongoing_requests";
        public static final String BIDDED_JOBS = BASE_URL + "bidded_requests";
        public static final String CONFIRMED_JOBS = BASE_URL + "confirmed_requests";
        public static final String SINGLE_REQUEST = BASE_URL + "single_request";
        public static final String SEND_BIDDING = BASE_URL +"send_bid_request";
        public static final String CONFIRM_BID_REQUEST = BASE_URL +"confirm_request";
        public static final String CANCEl_BID_REQUEST = BASE_URL +"cancel_request";
        public static final String DIRECT_JOBS = BASE_URL + "direct_requests";
        public static final String GET_MESSAGES = BASE_URL + "message/get?";
        public static final String POST_USER_PROFIFLE = BASE_URL + "user_profile";

        public static final String REDEEMS_LIST = BASE_URL + "redeems/list";
        public static final String SEND_REDEEM = BASE_URL + "redeems/send_request";
        public static final String CANCEL_REDEEM = BASE_URL + "redeems/request/cancel";
        public static final String LOGOUT = BASE_URL + "logout";
    }


    public class ServiceCode {
        public static final int POST_REGISTRATION = 1;
        public static final int POST_LOGIN = 2;
        public static final int POST_SOCIAL_LOGIN = 3;
        public static final int POST_FORGOT_PASSWORD = 4;
        public static final int GET_CATEGORY = 5;
        public static final int GET_SUBCATEGORY = 6;
        public static final int GET_SERVICES = 7;
        public static final int SAVE_SERVICES = 8;
        public static final int CHECK_AVAILABILITY = 9;
        public static final int SET_AVAILABILITY = 10;
        public static final int STATUS_CHECK = 11;
        public static final int INCOMING_REQUEST = 12;
        public static final int UPDATE_LOCATION_URL = 13;
        public static final int ACCEPT_REQUEST = 14;
        public static final int REJECT_REQUEST = 15;
        public static final int PROVIDER_STARTED = 16;
        public static final int PROVIDER_ARRIVED = 17;
        public static final int PROVIDER_SERVICE_STARTED = 18;
        public static final int PROVIDER_SERVICE_COMPLETED = 19;
        public static final int GET_PROFILE = 20;
        public static final int SAVE_PROFILE = 21;
        public static final int PROVIDER_CONFIRM_PAYMENT_URL = 22;
        public static final int PROVIDER_RATING = 23;
        public static final int GET_HISTORY = 24;
        public static final int AVAILABLE_JOBS = 25;
        public static final int ONGOING_JOBS = 26;
        public static final int BIDDED_JOBS = 27;
        public static final int CONFIRMED_JOBS = 28;
        public static final int SINGLE_REQUEST = 29;
        public static final int SEND_BIDDING = 30;
        public static final int CONFIRM_BID_REQUEST = 31;
        public static final int CANCEl_BID_REQUEST = 32;
        public static final int CHANGE_PASSWORD = 33;
        public static final int DIRECT_JOBS=34;
        public static final int GET_MESSAGES_CODE = 35;
        public static final int POST_USER_PROFILE_CODE = 36;

        public static final int REDEEMS_LIST_CODE = 37;
        public static final int SEND_REDEEM_CODE = 38;
        public static final int CANCEL_REDEEM_CODE = 39;
        public static final int LOGOUT_CODE = 40;
    }


}
