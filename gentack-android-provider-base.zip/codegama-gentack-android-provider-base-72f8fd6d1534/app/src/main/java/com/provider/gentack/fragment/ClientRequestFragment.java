package com.provider.gentack.fragment;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Handler;
import android.support.annotation.Nullable;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.aurelhubert.simpleratingbar.SimpleRatingBar;
import com.bumptech.glide.Glide;
import com.provider.gentack.activity.DetailProfileActivity;
import com.provider.gentack.activity.InfoActivity;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapView;
import com.google.android.gms.maps.MapsInitializer;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.provider.gentack.R;
import com.provider.gentack.activity.MainActivity;
import com.provider.gentack.activity.SplashActivity;
import com.provider.gentack.custom_interface.AsyncTaskCompleteListener;
import com.provider.gentack.location.LocationHelper;
import com.provider.gentack.model.RequestDetails;
import com.provider.gentack.networking.HttpRequester;
import com.provider.gentack.utils.AndyUtils;
import com.provider.gentack.utils.Const;
import com.provider.gentack.utils.ParseContent;
import com.provider.gentack.utils.PreferenceHelper;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;

import de.hdodenhof.circleimageview.CircleImageView;

/**
 * Created by Mahesh on 3/11/2017.
 */

public class ClientRequestFragment extends Fragment implements View.OnClickListener,
        LocationHelper.OnLocationReceived, AsyncTaskCompleteListener, OnMapReadyCallback {

    private MainActivity activity;
    private MapView mMapView;
    private GoogleMap googleMap;
    View view;
    private Marker mymarker,clcint_marker;
    private TextView btn_go_online;
    private Handler reqhandler;
    private ParseContent pContent;
    private LinearLayout cleint_img_lay;
    private RelativeLayout req_layout;
    private Button btn_reject, btn_accept;
    private String request_id = "", user_id;
    private SimpleRatingBar rating_bar;
    private CircleImageView iv_client_img;
    private boolean ishowing = false;
    private final long interval = 1 * 1000;
    private MyCountDownTimer countDownTimer;
    private FloatingActionButton info;
    private LocationHelper lhelper;
    private TextView tv_client_name, tv_client_type, tv_req_date, tv_job_type, tv_job_category, tv_job_title, tv_job_Description, tv_timer;
    Runnable runnable = new Runnable() {
        public void run() {
            getIncomingRequests();
            reqhandler.postDelayed(this, 4000);
        }
    };

    private void getIncomingRequests() {
        if (!AndyUtils.isNetworkAvailable(activity)) {

            return;
        }

        HashMap<String, String> map = new HashMap<String, String>();
        map.put(Const.Params.URL, Const.ServiceType.INCOMING_REQUEST);
        map.put(Const.Params.ID, new PreferenceHelper(activity).getUserId());
        map.put(Const.Params.TOKEN, new PreferenceHelper(activity).getSessionToken());
        new HttpRequester(activity, Const.POST, map,
                Const.ServiceCode.INCOMING_REQUEST, this);
    }


    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        activity = (MainActivity) getActivity();
        lhelper = new LocationHelper(activity);
        lhelper.setLocationReceivedLister(this);
        reqhandler = new Handler();
        pContent = new ParseContent(activity);
        try {
            MapsInitializer.initialize(activity);
        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.request_screen, container, false);
        mMapView = (MapView) view.findViewById(R.id.homeMap);
        btn_go_online = (TextView) view.findViewById(R.id.btn_go_online);
        req_layout = (RelativeLayout) view.findViewById(R.id.req_layout);
        cleint_img_lay = (LinearLayout) view.findViewById(R.id.cleint_img_lay);
        btn_reject = (Button) view.findViewById(R.id.btn_reject);
        btn_accept = (Button) view.findViewById(R.id.btn_accept);
        tv_client_name = (TextView) view.findViewById(R.id.tv_client_name);
        iv_client_img = (CircleImageView) view.findViewById(R.id.iv_client_img);
        tv_req_date = (TextView) view.findViewById(R.id.tv_req_date);
        info = (FloatingActionButton) view.findViewById(R.id.btn_floating_info);
        tv_timer = (TextView) view.findViewById(R.id.tv_timer);
        tv_job_category = (TextView) view.findViewById(R.id.tv_job_category);
        tv_job_Description = (TextView) view.findViewById(R.id.tv_job_Description);
        tv_job_title = (TextView) view.findViewById(R.id.tv_job_title);
        tv_job_type = (TextView) view.findViewById(R.id.tv_job_type);

        rating_bar = (SimpleRatingBar) view.findViewById(R.id.rating_bar);
        tv_client_type = (TextView) view.findViewById(R.id.tv_client_type);

        btn_reject.setOnClickListener(this);
        btn_accept.setOnClickListener(this);

        mMapView.onCreate(savedInstanceState);
        mMapView.getMapAsync(this);
        btn_go_online.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (btn_go_online.getText().toString().equals(activity.getString(R.string.btn_online))) {
                    setAvailability("1");
                } else {
                    setAvailability("0");
                }

            }
        });
        info.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (!request_id.equals("")){
                    Intent inttent = new Intent(activity, InfoActivity.class);
                    inttent.putExtra(Const.Params.REQUEST_ID, request_id);
                    startActivity(inttent);
                }
            }
        });
        iv_client_img.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Log.d("IMAGECLICK", "YES");
                Intent intent = new Intent(activity, DetailProfileActivity.class);
                intent.putExtra(Const.Params.USER_ID, user_id);
                startActivity(intent);
            }
        });
        getavailability();
        return view;
    }

    private void setAvailability(String status) {

        if (!AndyUtils.isNetworkAvailable(activity)) {
            AndyUtils.showShortToast(getString(R.string.no_internet), activity);
            return;
        }
        AndyUtils.showSimpleProgressDialog(activity, getString(R.string.please_wait), false);
        HashMap<String, String> map = new HashMap<String, String>();
        map.put(Const.Params.URL, Const.ServiceType.SET_AVAILABILITY);
        map.put(Const.Params.ID, new PreferenceHelper(activity).getUserId());
        map.put(Const.Params.TOKEN, new PreferenceHelper(activity).getSessionToken());
        map.put(Const.Params.STATUS, status);
        AndyUtils.appLog("Ashutosh", "RegisterMap" + map);
        new HttpRequester(activity, Const.POST, map, Const.ServiceCode.SET_AVAILABILITY, this);
    }

    private void getavailability() {
        if (!AndyUtils.isNetworkAvailable(activity)) {
            AndyUtils.showShortToast(getString(R.string.no_internet), activity);
            return;
        }
        // AndyUtils.showSimpleProgressDialog(activity, getString(R.string.please_wait), false);
        HashMap<String, String> map = new HashMap<String, String>();
        map.put(Const.Params.URL, Const.ServiceType.CHECK_AVAILABILITY);
        map.put(Const.Params.ID, new PreferenceHelper(activity).getUserId());
        map.put(Const.Params.TOKEN, new PreferenceHelper(activity).getSessionToken());

        AndyUtils.appLog("Ashutosh", "RegisterMap" + map);
        new HttpRequester(activity, Const.POST, map, Const.ServiceCode.CHECK_AVAILABILITY, this);
    }

    public void startCheckRegTimer() {
        reqhandler.postDelayed(runnable, 4000);
    }

    private void startCheckingUpcomingRequests() {
        startCheckRegTimer();
    }

    public void stopCheckingUpcomingRequests() {
        if (reqhandler != null) {
            reqhandler.removeCallbacks(runnable);

            Log.d("mahi", "stop handler");
        }
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.btn_accept:

                acceptrequest();
                break;
            case R.id.btn_reject:

                rejectrequest();
                break;
            default:
                break;
        }

    }

    private void rejectrequest() {


        if (!AndyUtils.isNetworkAvailable(activity)) {
            AndyUtils.showShortToast(getString(R.string.no_internet), activity);
            return;
        }
        AndyUtils.showSimpleProgressDialog(activity, getString(R.string.please_wait), false);
        HashMap<String, String> map = new HashMap<String, String>();
        map.put(Const.Params.URL, Const.ServiceType.REJECT_REQUEST);
        map.put(Const.Params.ID, new PreferenceHelper(activity).getUserId());
        map.put(Const.Params.TOKEN, new PreferenceHelper(activity).getSessionToken());
        map.put(Const.Params.REQUEST_ID, request_id);
        AndyUtils.appLog("Ashutosh", "RegisterMap" + map);
        new HttpRequester(activity, Const.POST, map, Const.ServiceCode.REJECT_REQUEST, this);
    }

    private void acceptrequest() {

        if (!AndyUtils.isNetworkAvailable(activity)) {
            AndyUtils.showShortToast(getString(R.string.no_internet), activity);
            return;
        }
        AndyUtils.showSimpleProgressDialog(activity, getString(R.string.please_wait), false);
        HashMap<String, String> map = new HashMap<String, String>();
        map.put(Const.Params.URL, Const.ServiceType.ACCEPT_REQUEST);
        map.put(Const.Params.ID, new PreferenceHelper(activity).getUserId());
        map.put(Const.Params.TOKEN, new PreferenceHelper(activity).getSessionToken());
        map.put(Const.Params.REQUEST_ID, request_id);
        AndyUtils.appLog("Ashutosh", "RegisterMap" + map);
        new HttpRequester(activity, Const.POST, map, Const.ServiceCode.ACCEPT_REQUEST, this);

    }

    @Override
    public void onTaskCompleted(String response, int serviceCode) {
        switch (serviceCode) {
            case Const.ServiceCode.CHECK_AVAILABILITY:
                try {
                    JSONObject job = new JSONObject(response);
                    if (job.optString("success").equals("true")) {
                        if (job.optString("active").equals("1")) {
                            btn_go_online.setText(activity.getString(R.string.btn_offline));
                        } else {
                            btn_go_online.setText(activity.getString(R.string.btn_online));
                        }
                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                }
                break;

            case Const.ServiceCode.SET_AVAILABILITY:
                AndyUtils.removeProgressDialog();
                try {
                    JSONObject job = new JSONObject(response);
                    if (job.optString("success").equals("true")) {
                        if (job.optString("active").equals("1")) {
                            btn_go_online.setText(activity.getString(R.string.btn_offline));
                        } else {
                            btn_go_online.setText(activity.getString(R.string.btn_online));
                        }
                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                }
                break;
            case Const.ServiceCode.INCOMING_REQUEST:
                Log.d("mahi", "InComingRequestResponse" + response);

                if (!pContent.isSuccess(response)) {
                    if (pContent.getErrorCode(response) == Const.REQUEST_ID_NOT_FOUND) {

                        new PreferenceHelper(activity).clearRequestData();

                    } else if (pContent.getErrorCode(response) == Const.INVALID_TOKEN) {

//                        if (mDialog != null && mDialog.isShowing()) {
//                            if (!isFinishing()) {
//                                mDialog.dismiss();
//                                isApprovedCheck = true;
//                            }
//                        }

                        new PreferenceHelper(activity).clearRequestData();
                        stopCheckingUpcomingRequests();
                        new PreferenceHelper(activity).Logout();
                        Intent i = new Intent(activity, SplashActivity.class);
                        startActivity(i);
                        activity.finish();
                        AndyUtils.showShortToast(getResources().getString(R.string.login_errror), activity);

                    }
                    return;
                }
                int requestId = pContent.parseRequestInProgress(response);

                if (requestId == Const.NO_REQUEST) {
                    req_layout.setVisibility(View.GONE);
                    cleint_img_lay.setVisibility(View.GONE);
                    btn_go_online.setVisibility(View.VISIBLE);
                    if(null!= clcint_marker){
                        clcint_marker.remove();
                    }
                    //AndyUtils.showLongToast("Customer Cancelled Request",activity);
                    ishowing = false;
                } else {

                    try {
                        JSONObject jsonObject = new JSONObject(response);
                        JSONArray jarray = jsonObject.getJSONArray("data");
                        JSONObject Jobj = jarray.getJSONObject(0);

                        String picture = Jobj.optString("user_picture");
                        user_id = Jobj.optString("user_id");
                        String name = Jobj.optString("user_name");
                        request_id = Jobj.optString("request_id");
                        String address = Jobj.optString("s_address");
                        String s_lat = Jobj.optString("s_latitude");
                        String s_lan = Jobj.optString("s_longitude");
                        String request_status_type = Jobj.optString("request_status_type");
                        String currency = Jobj.optString("currency");
                        String price = Jobj.optString("user_price");
                        String type = Jobj.optString("sub_category_name");
                        String rate = String.valueOf(Jobj.optString("user_rating").charAt(0));
                        String request_type = Jobj.getString("request_type");
                        String category_name = Jobj.getString("category_name");
                        String title = Jobj.getString("name");
                        String description = Jobj.getString("description");
                        String job_type = Jobj.getString("job_type");
                        long countDowntime = Long.parseLong(Jobj.optString("time_left_to_respond"));
                        LatLng service_latLng = new LatLng(Double.valueOf(s_lat),Double.valueOf(s_lan));

                        if (isAdded() && ishowing == false) {
                            ishowing = true;
                            mMapView.setLayoutParams(new RelativeLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 600));
                            req_layout.setVisibility(View.VISIBLE);
                            cleint_img_lay.setVisibility(View.VISIBLE);
                            btn_go_online.setVisibility(View.GONE);
                            countDownTimer = new MyCountDownTimer(countDowntime * 1000, interval);
                            countDownTimer.start();
                            Glide.with(activity)
                                    .load(picture)
                                    .error(R.drawable.default_user)
                                    .into(iv_client_img);
                            tv_client_name.setText(name);
                            tv_client_type.setText("Sub Category:  " + type + " " + "/" + " " + currency + price);
                            tv_job_category.setText("Category:    " + category_name);
                            tv_job_title.setText("Title:   " + title);
                            tv_job_Description.setText("Description:  " + description);
                            if (job_type.equals("1")) {
                                tv_job_type.setText("Job Type:  Request Now");
                            } else {
                                tv_job_type.setText("Job Type:  Later Request");
                            }
                            rating_bar.setRating(Integer.valueOf(rate));
                            info.setVisibility(View.VISIBLE);
                            MarkerOptions opt = new MarkerOptions();
                            opt.position(service_latLng);
                            opt.title("Service Location");
                            opt.icon(BitmapDescriptorFactory.fromResource(R.drawable.user_pin));
                            clcint_marker = googleMap.addMarker(opt);
                            googleMap.animateCamera(CameraUpdateFactory.newLatLngZoom(service_latLng,
                                    13));
                            //Log.e("mahi","rating"+rate);
                            //showRequestDialog(picture, name, String.valueOf(request_id), address, countDown,staticMapUrl,request_status_type,number_hours);

                        }


//                            if (!status.equals("0") && checkreq_status == false) {
//                                checkreq_status = true;
//                                Log.d("mahi", "check status in log");
//                                checkRequestStatus(Integer.valueOf(request_id));
//                                stopCheckingUpcomingRequests();
//                            }


                    } catch (JSONException e) {
                        e.printStackTrace();
                        ishowing = false;
                        req_layout.setVisibility(View.GONE);
                        cleint_img_lay.setVisibility(View.GONE);
                        btn_go_online.setVisibility(View.VISIBLE);
                        AndyUtils.showLongToast("Customer Cancelled Request", activity);
                    }

                }


                break;
            case Const.ServiceCode.ACCEPT_REQUEST:
                mMapView.setLayoutParams(new RelativeLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
                info.setVisibility(View.VISIBLE);
                try {
                    JSONObject job = new JSONObject(response);
                    if (job.optString("success").equals("true")) {
                        stopCheckingUpcomingRequests();
                        AndyUtils.removeProgressDialog();
                        ishowing = false;
                        countDownTimer.cancel();
                        JSONObject datj = job.getJSONObject("data");
                        String request_id = datj.getString("request_id");
                        new PreferenceHelper(activity).putRequestId(Integer.valueOf(request_id));
                        clcint_marker.remove();
                        RequestDetails reqDetail = pContent
                                .parseRequestStatus(response);
                        if (reqDetail != null) {
                            Bundle bundle2 = new Bundle();
                            JobMapFragment tripFragment = new JobMapFragment();
                            bundle2.putInt(Const.PROVIDER_STATUS,
                                    Const.IS_PROVIDER_ACCEPTED);
                            bundle2.putSerializable(Const.REQUEST_DETAIL,
                                    reqDetail);
                            tripFragment.setArguments(bundle2);
                            activity.addFragment(tripFragment, false, "HOME", Const.Params.JOBMAP_FRAGMENT);
                        }


                    } else {
                        AndyUtils.removeProgressDialog();
                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                }
                break;
            case Const.ServiceCode.REJECT_REQUEST:
                mMapView.setLayoutParams(new RelativeLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
                info.setVisibility(View.VISIBLE);
                AndyUtils.removeProgressDialog();
                try {
                    JSONObject job = new JSONObject(response);
                    if (job.optString("success").equals("true")) {
                        ishowing = false;
                        countDownTimer.cancel();
                        req_layout.setVisibility(View.GONE);
                        cleint_img_lay.setVisibility(View.GONE);
                        btn_go_online.setVisibility(View.VISIBLE);
                        startCheckingUpcomingRequests();
                        request_id = "";
                        clcint_marker.remove();
                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                }

                break;
            default:
                break;
        }


    }


    @Override
    public void onMapReady(GoogleMap mgoogleMap) {
        googleMap = mgoogleMap;
        if (googleMap != null) {
            googleMap.getUiSettings().setMyLocationButtonEnabled(false);
            googleMap.getUiSettings().setMapToolbarEnabled(true);


            if (ActivityCompat.checkSelfPermission(activity, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(activity, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                //    ActivityCompat#requestPermissions
                // here to request the missing permissions, and then overriding
                //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
                //                                          int[] grantResults)
                // to handle the case where the user grants the permission. See the documentation
                // for ActivityCompat#requestPermissions for more details.
                return;
            }

            googleMap.setMyLocationEnabled(true);
        }
    }

    @Override
    public void onSaveInstanceState(Bundle outState) {
        //No call for super(). Bug on API Level > 11.
        mMapView.onSaveInstanceState(outState);
    }

    @Override
    public void onPause() {
        super.onPause();

        mMapView.onPause();
    }

    @Override
    public void onStop() {
        super.onStop();

    }

    @Override
    public void onResume() {
        super.onResume();

        mMapView.onResume();
        if (new PreferenceHelper(activity).getRequestId() == Const.NO_REQUEST) {
            startCheckingUpcomingRequests();
        }

        activity.currentFragment = Const.Params.HOMEMAP_FRAGMENT;

    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (mMapView != null) {
            mMapView.onDestroy();
            lhelper.onStop();
        }
        stopCheckingUpcomingRequests();
    }

    @Override
    public void onLocationReceived(LatLng latlong) {


    }

    @Override
    public void onLocationReceived(Location location) {

        if (location != null) {
            LatLng latLng = new LatLng(location.getLatitude(), location.getLongitude());

            if (mymarker == null) {
                MarkerOptions opt = new MarkerOptions();
                opt.position(latLng);
                opt.title(activity.getResources().getString(R.string.txt_location));
                opt.icon(BitmapDescriptorFactory.fromResource(R.drawable.provider_pin));
                mymarker = googleMap.addMarker(opt);

                googleMap.animateCamera(CameraUpdateFactory.newLatLngZoom(latLng,
                        15));
            } else {
                mymarker.setPosition(latLng);
            }
        }

    }

    @Override
    public void onConntected(Bundle bundle) {

    }

    @Override
    public void onConntected(Location location) {

    }

    class MyCountDownTimer extends CountDownTimer {
        public MyCountDownTimer(long millisInFuture, long countDownInterval) {
            super(millisInFuture, countDownInterval);
        }

        @Override
        public void onTick(long l) {
            tv_timer.setText("" + (l / 1000));
        }

        @Override
        public void onFinish() {
            new PreferenceHelper(activity).clearRequestData();
            mMapView.setLayoutParams(new RelativeLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
            info.setVisibility(View.GONE);
            req_layout.setVisibility(View.GONE);
            cleint_img_lay.setVisibility(View.GONE);
            btn_go_online.setVisibility(View.VISIBLE);
            startCheckingUpcomingRequests();
            ishowing = false;
            clcint_marker.remove();
        }
    }
}
