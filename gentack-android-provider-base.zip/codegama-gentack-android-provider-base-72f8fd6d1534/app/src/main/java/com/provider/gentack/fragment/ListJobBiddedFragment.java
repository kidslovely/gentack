package com.provider.gentack.fragment;

import android.app.Dialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.app.Fragment;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.aurelhubert.simpleratingbar.SimpleRatingBar;
import com.bumptech.glide.Glide;
import com.provider.gentack.R;
import com.provider.gentack.activity.ChatActivity;
import com.provider.gentack.activity.DetailProfileActivity;
import com.provider.gentack.activity.InfoActivity;
import com.provider.gentack.activity.ListJobsActivity;
import com.provider.gentack.adapter.JobAdapter;
import com.provider.gentack.custom_interface.AsyncTaskCompleteListener;
import com.provider.gentack.model.BiddingRequestDetails;
import com.provider.gentack.networking.HttpRequester;
import com.provider.gentack.utils.AndyUtils;
import com.provider.gentack.utils.Const;
import com.provider.gentack.utils.PreferenceHelper;
import com.provider.gentack.utils.RecyclerLongPressClickListener;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;

/**
 * Created by Mahesh on 4/2/2017.
 */

public class ListJobBiddedFragment extends Fragment implements View.OnClickListener, AsyncTaskCompleteListener {
    private ListJobsActivity activity;
    private PreferenceHelper pHelper;
    ArrayList<BiddingRequestDetails> biddedlst;
    private JobAdapter jobsAdapter;
    private RecyclerView recycel_bidded_jobs;
    private TextView empty_lst_txt;
    private Bundle bundle;
    private String request_id;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        activity = (ListJobsActivity) getActivity();
        pHelper = new PreferenceHelper(activity);
        biddedlst = new ArrayList<BiddingRequestDetails>();
        bundle = getArguments();
        if (bundle != null){
            request_id = bundle.getString(Const.Params.REQUEST_ID);
        }
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_bidded_jobs, container, false);
        recycel_bidded_jobs = (RecyclerView) view.findViewById(R.id.recycel_bidded_jobs);

        RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(activity);
        recycel_bidded_jobs.setLayoutManager(mLayoutManager);
        recycel_bidded_jobs.setItemAnimator(new DefaultItemAnimator());
        empty_lst_txt = (TextView) view.findViewById(R.id.empty_lst_txt);
        if (request_id != null){
            getSinglejob_details(request_id);
        }
        recycel_bidded_jobs.addOnItemTouchListener(new RecyclerLongPressClickListener(activity, recycel_bidded_jobs, new RecyclerLongPressClickListener.OnItemClickListener() {
            @Override
            public void onItemClick(View view, int position) {

                getSinglejob_details(biddedlst.get(position).getRequestId());
            }

            @Override
            public void onLongItemClick(View view, int position) {

            }
        }));

        return view;
    }


    private void getSinglejob_details(String requestId) {
        if (!AndyUtils.isNetworkAvailable(activity)) {

            return;
        }
        AndyUtils.showSimpleProgressDialog(activity, "Loading...", false);
        HashMap<String, String> map = new HashMap<String, String>();
        map.put(Const.Params.URL, Const.ServiceType.SINGLE_REQUEST);
        map.put(Const.Params.ID, new PreferenceHelper(activity).getUserId());
        map.put(Const.Params.TOKEN, new PreferenceHelper(activity).getSessionToken());
        map.put(Const.Params.REQUEST_ID, requestId);
        new HttpRequester(activity, Const.POST, map,
                Const.ServiceCode.SINGLE_REQUEST, this);
    }

    private void showdetailedfullview(final String request_id, String user_name, final String user_picture, final String user_mobile, String description, String note, String request_date, String category_name, String s_latitude, String s_longitude, String s_address, String user_price, String user_rating, String google_img_url, final String user_id, final String bid_status, String bid_amount, String price_per_hour, String chat_status) {
        final Dialog _dialog = new Dialog(activity, R.style.DialogThemeforview);
        _dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        _dialog.setCancelable(true);
        _dialog.setContentView(R.layout.job_detailed_screen);
        ImageView iv_userIcon = (ImageView) _dialog.findViewById(R.id.iv_userIcon);
        ImageView jobdetailedMapView = (ImageView) _dialog.findViewById(R.id.jobdetailedMapView);
        TextView tv_user_name = (TextView) _dialog.findViewById(R.id.tv_user_name);
        TextView tv_service_requested = (TextView) _dialog.findViewById(R.id.tv_service_requested);
        SimpleRatingBar rating = (SimpleRatingBar) _dialog.findViewById(R.id.rating);
        FloatingActionButton btn_floating_call = (FloatingActionButton) _dialog.findViewById(R.id.btn_floating_call);
        FloatingActionButton btn_floating_info = (FloatingActionButton) _dialog.findViewById(R.id.btn_floating_info);
        final FloatingActionButton btn_floating_message = (FloatingActionButton) _dialog.findViewById(R.id.btn_floating_message);
        TextView tv_date = (TextView) _dialog.findViewById(R.id.tv_date);
        TextView tv_provider_bidded = (TextView) _dialog.findViewById(R.id.tv_provider_bidded);
        TextView tv_location = (TextView) _dialog.findViewById(R.id.tv_location);
        TextView tv_user_bidded = (TextView) _dialog.findViewById(R.id.tv_user_bidded);
        TextView tv_user_description = (TextView) _dialog.findViewById(R.id.tv_user_description);
        TextView tv_user_note = (TextView) _dialog.findViewById(R.id.tv_user_note);
        final Button bn_cancel = (Button) _dialog.findViewById(R.id.bn_cancel);
        ImageView btn_back_fullview = (ImageView) _dialog.findViewById(R.id.btn_back_fullview);
        if (chat_status.equals("1")) {
            btn_floating_message.setVisibility(View.VISIBLE);
        } else {
            btn_floating_message.setVisibility(View.GONE);
        }
        Button bn_bid = (Button) _dialog.findViewById(R.id.bn_bid);
        btn_back_fullview.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                _dialog.dismiss();
            }
        });
        tv_provider_bidded.setVisibility(View.VISIBLE);
        if (!iv_userIcon.equals("") && iv_userIcon != null) {
            Glide.with(activity).load(user_picture).error(R.drawable.default_user).into(iv_userIcon);
        }
        iv_userIcon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(activity, DetailProfileActivity.class);
                intent.putExtra(Const.Params.USER_ID, user_id);
                startActivity(intent);
            }
        });
        if (bid_status.equals("2")) {
            tv_provider_bidded.setVisibility(View.VISIBLE);
            tv_provider_bidded.setText("Your Bid: " + "$" + bid_amount);
            bn_cancel.setText("Back");
            bn_bid.setVisibility(View.GONE);
        } else if (bid_status.equals("3")) {
            tv_provider_bidded.setText("Final Bid: " + "$" + price_per_hour);
            bn_bid.setVisibility(View.VISIBLE);
            bn_cancel.setText("Cancel");
            bn_bid.setText("Confirm");
        }
        tv_user_name.setText(user_name);
        tv_service_requested.setText(category_name);
        tv_date.setText(request_date);
        tv_location.setText(s_address);
        tv_user_bidded.setText("$" + " " + user_price);
        tv_user_description.setText(description);
        tv_user_note.setText(note);
        Glide.with(activity).load(google_img_url).into(jobdetailedMapView);
        if (!user_rating.equals("")) {
            int rate = user_rating.charAt(0);
            rating.setRating(rate);
        }
        if (user_mobile.equals("")) {
            btn_floating_call.setVisibility(View.GONE);
        }
        else {
            btn_floating_call.setVisibility(View.VISIBLE);
        }
        btn_floating_call.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Intent.ACTION_DIAL, Uri.fromParts("tel", user_mobile, null));
                startActivity(intent);
            }
        });
        btn_floating_info.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(activity, InfoActivity.class);
                intent.putExtra(Const.Params.REQUEST_ID, request_id);
                startActivity(intent);
            }
        });
        bn_cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (bid_status.equals("2")) {
                    _dialog.dismiss();

                } else if (bid_status.equals("3")) {
                    _dialog.dismiss();
                    cancelbid(request_id);
                }

            }
        });
        bn_bid.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (bid_status.equals("2")) {
                    _dialog.dismiss();
                } else if (bid_status.equals("3")) {
                    _dialog.dismiss();
                    confirm(request_id);
                }
            }
        });
        btn_floating_message.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Bundle mbundle = new Bundle();
                mbundle.putString("request_id", request_id);
                mbundle.putString("user_picture", user_picture);
                mbundle.putString("reciver_id", user_id);
                Intent i = new Intent(activity, ChatActivity.class);
                i.putExtras(mbundle);
                activity.startActivity(i);
            }
        });

        _dialog.show();

    }

    private void confirm(String request_id) {

        if (!AndyUtils.isNetworkAvailable(activity)) {

            return;
        }
        AndyUtils.showSimpleProgressDialog(activity, "Responding...", false);
        HashMap<String, String> map = new HashMap<String, String>();
        map.put(Const.Params.URL, Const.ServiceType.CONFIRM_BID_REQUEST);
        map.put(Const.Params.ID, new PreferenceHelper(activity).getUserId());
        map.put(Const.Params.TOKEN, new PreferenceHelper(activity).getSessionToken());
        map.put(Const.Params.REQUEST_ID, request_id);
        new HttpRequester(activity, Const.POST, map,
                Const.ServiceCode.CONFIRM_BID_REQUEST, this);
    }

    private void cancelbid(String request_id) {

        if (!AndyUtils.isNetworkAvailable(activity)) {

            return;
        }
        AndyUtils.showSimpleProgressDialog(activity, "Responding...", false);
        HashMap<String, String> map = new HashMap<String, String>();
        map.put(Const.Params.URL, Const.ServiceType.CANCEl_BID_REQUEST);
        map.put(Const.Params.ID, new PreferenceHelper(activity).getUserId());
        map.put(Const.Params.TOKEN, new PreferenceHelper(activity).getSessionToken());
        map.put(Const.Params.REQUEST_ID, request_id);
        map.put("provider_reason", "");
        new HttpRequester(activity, Const.POST, map,
                Const.ServiceCode.CANCEl_BID_REQUEST, this);
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        getBiddedjobs();
    }

    private void getBiddedjobs() {

        if (!AndyUtils.isNetworkAvailable(activity)) {

            return;
        }
        HashMap<String, String> map = new HashMap<String, String>();
        map.put(Const.Params.URL, Const.ServiceType.BIDDED_JOBS);
        map.put(Const.Params.ID, new PreferenceHelper(activity).getUserId());
        map.put(Const.Params.TOKEN, new PreferenceHelper(activity).getSessionToken());

        new HttpRequester(activity, Const.POST, map,
                Const.ServiceCode.BIDDED_JOBS, this);
    }

    @Override
    public void onClick(View view) {

    }

    @Override
    public void onTaskCompleted(String response, int serviceCode) {
        switch (serviceCode) {
            case Const.ServiceCode.BIDDED_JOBS:
                try {
                    JSONObject job = new JSONObject(response);
                    biddedlst.clear();
                    if (job.getString("success").equals("true")) {
                        JSONArray jsonArray = job.getJSONArray("data");
                        for (int i = 0; i < jsonArray.length(); i++) {
                            JSONObject jsonObject = jsonArray.getJSONObject(i);
                            BiddingRequestDetails biddingRequestDetails = new BiddingRequestDetails();
                            biddingRequestDetails.setRequestId(jsonObject.optString("request_id"));
                            biddingRequestDetails.setJobTitle(jsonObject.optString("name"));
                            biddingRequestDetails.setDescription(jsonObject.optString("description"));
                            biddingRequestDetails.setServiceType(jsonObject.optString("sub_category_name"));
                            biddingRequestDetails.setPrice(jsonObject.optString("user_price"));
                            biddingRequestDetails.setServicePicture(jsonObject.optString("service_picture"));
                            biddingRequestDetails.setCurrency(jsonObject.optString("currency"));
                            biddingRequestDetails.setUser_id(jsonObject.optString("user_id"));
                            biddingRequestDetails.setBid_status(jsonObject.optString("bid_status"));
                            biddingRequestDetails.setBidded_price(jsonObject.optString("bid_amount"));
                            biddingRequestDetails.setFinal_price(jsonObject.optString("price_per_hour"));

                            biddingRequestDetails.setRequestDateTime(jsonObject.optString("request_date"));
                            biddedlst.add(biddingRequestDetails);
                        }
                        if (biddedlst != null) {
                            jobsAdapter = new JobAdapter(activity, biddedlst);
                            recycel_bidded_jobs.setAdapter(jobsAdapter);
                        }
                        if (biddedlst.size() == 0) {
                            empty_lst_txt.setVisibility(View.VISIBLE);
                        } else {
                            empty_lst_txt.setVisibility(View.GONE);
                        }
                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                    empty_lst_txt.setVisibility(View.VISIBLE);
                }
                break;
            case Const.ServiceCode.SINGLE_REQUEST:
                AndyUtils.removeProgressDialog();
                try {
                    JSONObject job = new JSONObject(response);
                    if (job.getString("success").equals("true")) {
                        JSONObject dataObj = job.getJSONObject("data");
                        String request_id = dataObj.getString("request_id");
                        String user_name = dataObj.getString("user_name");
                        String user_picture = dataObj.getString("user_picture");
                        String user_mobile = dataObj.getString("user_mobile");
                        String description = dataObj.getString("description");
                        String note = dataObj.getString("note");
                        String request_date = dataObj.getString("request_date");
                        String category_name = dataObj.getString("sub_category_name");
                        String s_latitude = dataObj.getString("s_latitude");
                        String s_longitude = dataObj.getString("s_longitude");
                        String s_address = dataObj.getString("s_address");
                        String user_price = dataObj.getString("user_price");
                        String user_rating = dataObj.getString("user_rating");
                        String user_id = dataObj.getString("user_id");
                        String bid_status = dataObj.optString("bid_status");
                        String bid_amount = dataObj.optString("bid_amount");
                        String price_per_hour = dataObj.optString("price_per_hour");
                        String chat_status = dataObj.getString("chat_status");
                        String google_img_url = getGoogleMapThumbnail(Double.valueOf(s_latitude), Double.valueOf(s_longitude));
                        showdetailedfullview(request_id, user_name, user_picture, user_mobile, description, note, request_date, category_name, s_latitude, s_longitude, s_address, user_price, user_rating, google_img_url, user_id, bid_status, bid_amount, price_per_hour, chat_status);
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }

                break;
            case Const.ServiceCode.CANCEl_BID_REQUEST:
                AndyUtils.removeProgressDialog();
                try {
                    JSONObject job = new JSONObject(response);
                    if (job.getString("success").equals("true")) {
                        AndyUtils.showShortToast("Bid Rejected!", activity);
                        getBiddedjobs();
                    } else {

                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                }

                break;
            case Const.ServiceCode.CONFIRM_BID_REQUEST:
                AndyUtils.removeProgressDialog();
                try {
                    JSONObject job = new JSONObject(response);
                    if (job.getString("success").equals("true")) {
                        AndyUtils.showShortToast("Bid Accepted!", activity);
                        getBiddedjobs();
                    } else {

                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                }

                break;
        }

    }

    public static String getGoogleMapThumbnail(double lati, double longi) {
        String staticMapUrl = "http://maps.google.com/maps/api/staticmap?center=" + lati + "," + longi + "&markers=" + lati + "," + longi + "&zoom=10&size=350x150&&sensor=false";
        return staticMapUrl;
    }
}
