package com.provider.gentack.adapter;

import android.content.Context;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Pair;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseExpandableListAdapter;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.provider.gentack.R;
import com.provider.gentack.model.Category;
import com.provider.gentack.utils.AndyUtils;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

/**
 * Created by Mahesh on 4/3/2017.
 */

public class ExpandElementsAdapter extends BaseExpandableListAdapter {

    private Context _context;
    private ArrayList<Category> elementstDataHeader;
    private AdapterCallback mAdapterCallback;
    private AdapterRemoveCallback mAdapterremoveCallback;
    private final Set<Pair<Long, Long>> mCheckedItems = new HashSet<Pair<Long, Long>>();
    private ArrayList<String> prices;
    private ArrayList<String> service_id;
    private String[] dataSet;

    public ExpandElementsAdapter(Context context, ArrayList<Category> elementstDataHeader, AdapterRemoveCallback mAdapterremoveCallback, AdapterCallback mAdapterCallback) {
        this._context = context;
        this.elementstDataHeader = elementstDataHeader;
        this.mAdapterCallback = mAdapterCallback;
        this.mAdapterremoveCallback = mAdapterremoveCallback;
        prices = new ArrayList<String>();
        service_id = new ArrayList<String>();
    }

    @Override
    public Object getChild(int groupPosition, int childPosititon) {
        return elementstDataHeader.get(groupPosition);
    }

    @Override
    public long getChildId(int groupPosition, int childPosition) {
        return childPosition;
    }

    @Override
    public View getChildView(final int groupPosition, final int childPosition,
                             boolean isLastChild, View convertView, ViewGroup parent) {

        final String childText = elementstDataHeader.get(groupPosition).getSubcat().get(childPosition).getSubcatName();

        if (convertView == null) {
            LayoutInflater infalInflater = (LayoutInflater) this._context
                    .getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView = infalInflater.inflate(R.layout.item_child, null);
        }

        TextView text_mobile_model = (TextView) convertView
                .findViewById(R.id.text_mobile_model);
        final EditText text_mobile_price = (EditText) convertView
                .findViewById(R.id.text_mobile_price);
        ImageView image_subcat = (ImageView) convertView.findViewById(R.id.image_subcat);
        CheckBox check_service = (CheckBox) convertView.findViewById(R.id.check_service);
        final Pair<Long, Long> tag = new Pair<Long, Long>(
                getGroupId(groupPosition),
                getChildId(groupPosition, childPosition));
        check_service.setTag(tag);
        text_mobile_price.setTag(tag);
        check_service.setChecked(mCheckedItems.contains(tag));
       /* check_service.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean isChecked) {
                if (isChecked) {
                    mCheckedItems.add(tag);
                    elementstDataHeader.get(groupPosition).getSubcat().get(childPosition).setPrice(text_mobile_price.getText().toString());
                    prices.add(elementstDataHeader.get(groupPosition).getSubcat().get(childPosition).getPrice());
                    service_id.add(elementstDataHeader.get(groupPosition).getSubcat().get(childPosition).getSubcatid());
                    mAdapterCallback.onMethodCallback(prices, service_id);
                    elementstDataHeader.get(groupPosition).getSubcat().get(childPosition).setIschecked(true);
                    notifyDataSetChanged();
                } else {
                    mCheckedItems.remove(tag);
                    elementstDataHeader.get(groupPosition).getSubcat().get(childPosition).setIschecked(false);
                    prices.remove(elementstDataHeader.get(groupPosition).getSubcat().get(childPosition).getPrice());
                    service_id.remove(elementstDataHeader.get(groupPosition).getSubcat().get(childPosition).getSubcatid());
                    mAdapterremoveCallback.onMethodRemoveCallback(prices, service_id);
                    notifyDataSetChanged();
                }
            }
        });*/




        check_service.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                final CheckBox cb = (CheckBox) view;
                final Pair<Long, Long> tag = (Pair<Long, Long>) view.getTag();
                if (cb.isChecked())
                {
                    mCheckedItems.add(tag);
                    prices.add(text_mobile_price.getText().toString());
                    service_id.add(elementstDataHeader.get(groupPosition).getSubcat().get(childPosition).getSubcatid());
                    mAdapterCallback.onMethodCallback(prices, service_id);
                    elementstDataHeader.get(groupPosition).getSubcat().get(childPosition).setIschecked(true);
                    text_mobile_price.setEnabled( false);
                    AndyUtils.showShortToast("Please Uncheck to edit price",_context);
//                   notifyDataSetChanged();
                } else {
                    mCheckedItems.remove(tag);
                    elementstDataHeader.get(groupPosition).getSubcat().get(childPosition).setIschecked(false);
                    prices.remove(text_mobile_price.getText().toString());
                    service_id.remove(elementstDataHeader.get(groupPosition).getSubcat().get(childPosition).getSubcatid());
                    mAdapterremoveCallback.onMethodRemoveCallback(prices, service_id);
                    text_mobile_price.setEnabled( true);
                   // notifyDataSetChanged();
                }


            }
        });

        text_mobile_model.setText(childText);
        Glide.with(_context)
                .load(elementstDataHeader.get(groupPosition).getSubcat().get(childPosition).getSubcatimg())
                .into(image_subcat);
        text_mobile_price.setText(elementstDataHeader.get(groupPosition).getSubcat().get(childPosition).getPrice());
       // elementstDataHeader.get(groupPosition).getSubcat().get(childPosition).setPrice(text_mobile_price.getText().toString());
        return convertView;
    }

    @Override
    public int getChildrenCount(int groupPosition) {
        return elementstDataHeader.get(groupPosition).getSubcat().size();
    }

    @Override
    public Object getGroup(int groupPosition) {
        return elementstDataHeader.get(groupPosition);
    }

    @Override
    public int getGroupCount() {
        return elementstDataHeader.size();
    }

    @Override
    public long getGroupId(int groupPosition) {
        return groupPosition;
    }


    @Override
    public View getGroupView(final int groupPosition, boolean isExpanded,
                             View convertView, ViewGroup parent) {

        if (convertView == null) {
            LayoutInflater infalInflater = (LayoutInflater) _context
                    .getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView = infalInflater.inflate(R.layout.group_cat_item, null);
        }

        TextView category_title = (TextView) convertView
                .findViewById(R.id.category_title);
        ImageView image_indicator = (ImageView)
                convertView
                        .findViewById(R.id.image_indicator);
        if (isExpanded) {
            image_indicator.setImageResource(R.mipmap.ic_keyboard_arrow_up_black_18dp);
        } else {
            image_indicator.setImageResource(R.mipmap.ic_keyboard_arrow_down_black_18dp);
        }

        category_title.setText(elementstDataHeader.get(groupPosition).getCategory_title());


        return convertView;
    }


    @Override
    public boolean hasStableIds() {
        return true;
    }

    @Override
    public boolean isChildSelectable(int groupPosition, int childPosition) {
        return true;
    }

    public Set<Pair<Long, Long>> getCheckedItems() {
        return mCheckedItems;
    }

    public interface AdapterCallback {
        void onMethodCallback(ArrayList<String> prices, ArrayList<String> service_id);
    }

    public interface AdapterRemoveCallback {
        void onMethodRemoveCallback(ArrayList<String> subelement_price, ArrayList<String> subelement_id);
    }

}
