package com.provider.gentack.utils;


import android.app.Activity;
import android.text.TextUtils;
import android.util.Log;

import com.provider.gentack.model.RequestDetails;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/**
 * Created by user on 2/1/2017.
 */

public class ParseContent {

    private Activity activity;

    private PreferenceHelper preferenceHelper;
    private final String KEY_SUCCESS = "success";
    private final String KEY_ERROR = "error";
    private final String KEY_ERROR_CODE = "error_code";


    public ParseContent(Activity activity) {
        this.activity = activity;
        preferenceHelper = new PreferenceHelper(activity);
    }

    public void saveIdAndToken(String response) {
        try {
            JSONObject jsonObject = new JSONObject(response);
            if (jsonObject.optString(Const.SUCCESS).equals(Const.TRUE)) {
                JSONObject data = jsonObject.getJSONObject("data");
                new PreferenceHelper(activity).putUserId(data.optString(Const.Params.PROVIDER_ID));
                new PreferenceHelper(activity).putSessionToken(data.optString(Const.Params.TOKEN));
                new PreferenceHelper(activity).putUser_name(data.optString(Const.Params.PROVIDER_NAME));
                new PreferenceHelper(activity).putEmail(data.optString(Const.Params.EMAIL));
                new PreferenceHelper(activity).putPicture(data.optString("provider_picture"));
                new PreferenceHelper(activity).putLoginType(data.optString("login_by"));

            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    public boolean isSuccess(String response) {
        if (TextUtils.isEmpty(response))
            return false;
        try {
            JSONObject jsonObject = new JSONObject(response);
            if (jsonObject.getBoolean(KEY_SUCCESS)) {
                return true;
            } else {

                return false;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    public int getErrorCode(String response) {
        if (TextUtils.isEmpty(response))
            return 0;
        try {

            JSONObject jsonObject = new JSONObject(response);
            return jsonObject.getInt(KEY_ERROR_CODE);

        } catch (JSONException e) {
            e.printStackTrace();
        }
        return 0;
    }

    public int parseRequestInProgress(String response) {
        if (TextUtils.isEmpty(response)) {
            return Const.NO_REQUEST;
        }
        try {
            JSONObject jsonObject = new JSONObject(response);
            if (jsonObject.getBoolean(KEY_SUCCESS)) {
                JSONArray jarray = jsonObject.optJSONArray("data");
                if (jarray != null && jarray.length() > 0) {
                    JSONObject Jobj = jarray.getJSONObject(0);
                    if (Jobj.has("request_id")) {
                        int requestId = Jobj
                                .getInt(Const.Params.REQUEST_ID);

                        return requestId;
                    }
                } else {

                }
            }
        } catch (JSONException e) {
            e.printStackTrace();

        }
        return Const.NO_REQUEST;
    }

    public RequestDetails parseRequestArrayStatus(String response) {
        Log.d("mahi", "coming to parse");
        RequestDetails requestDetails = null;
        try {
            JSONObject jsonObject = new JSONObject(response);
            JSONObject dataObject = jsonObject.optJSONObject("data");

                //JSONObject dataObject = dataarray.optJSONObject(0);
                requestDetails = new RequestDetails();
            if(null!= dataObject) {
                requestDetails.setClientId(dataObject.optString("user_id"));
                new PreferenceHelper(activity).putRequestId(Integer.valueOf(dataObject.optString("request_id")));
                requestDetails.setClientName(dataObject.optString("user_name"));
                requestDetails.setClientProfile(dataObject.optString("user_picture"));
                requestDetails.setRequest_type(dataObject.optString("request_status_type"));
                requestDetails.setClientPhoneNumber(dataObject.optString("user_mobile"));
                requestDetails.setsLatitude(dataObject.optString("s_latitude"));
                requestDetails.setsLongitude(dataObject.optString("s_longitude"));
                requestDetails.setdLatitude(dataObject.optString("d_latitude"));
                requestDetails.setdLongitude(dataObject.optString("d_longitude"));
                requestDetails.setSourceAddress(dataObject.optString("s_address"));
                requestDetails.setDestinationAddress(dataObject.optString("d_address"));
                requestDetails.setServiceType(dataObject.optString("service_type_name"));
                requestDetails.setUserRating(String.valueOf(dataObject.optString("user_rating").charAt(0)));
                requestDetails.setRequestId(Integer.parseInt(dataObject.optString("request_id")));
                requestDetails.setStatus(dataObject.optString("status"));
                requestDetails.setProviderStatus(dataObject.optString("provider_status"));
                requestDetails.setTypePicture(dataObject.optString("type_picture"));
                requestDetails.setUser_price(dataObject.optString("user_price"));
                requestDetails.setSub_category_name(dataObject.optString("sub_category_name"));
                requestDetails.setCurrency(dataObject.optString("currency"));
                requestDetails.setBefore_image(dataObject.optString("before_image"));
                requestDetails.setAfter_image(dataObject.optString("after_image"));
                requestDetails.setJob_type(dataObject.optString("job_type"));
                requestDetails.setPrice_per_hour(dataObject.optString("price_per_hour"));
            }

                JSONArray invoiceArray = jsonObject.optJSONArray("invoice");
                if (invoiceArray != null && invoiceArray.length() > 0) {
                    JSONObject invoiceObject = invoiceArray.getJSONObject(0);
                    requestDetails.setTotal(invoiceObject.optString("total"));
                    requestDetails.setDistance(invoiceObject.optString("distance_travel"));
                    requestDetails.setTime(invoiceObject.optString("total_time"));
                    requestDetails.setPayment_type(invoiceObject.optString("payment_mode"));
                    requestDetails.setBaseprice(invoiceObject.optString("price_per_hour"));
                    requestDetails.setTaxprice(invoiceObject.optString("tax_price"));


            }

        } catch (JSONException e) {
            e.printStackTrace();
        }

        return requestDetails;
    }

    public RequestDetails parseRequestStatus(String response) {
        RequestDetails requestDetails = null;
        try {
            JSONObject jsonObject = new JSONObject(response);
            JSONObject dataObject = jsonObject.getJSONObject("data");
            if (dataObject != null) {
                requestDetails = new RequestDetails();
                requestDetails.setClientId(dataObject.optString("user_id"));
                requestDetails.setRequest_type(dataObject.optString("request_status_type"));
                requestDetails.setClientName(dataObject.optString("user_name"));
                requestDetails.setClientProfile(dataObject.optString("user_picture"));
                requestDetails.setClientPhoneNumber(dataObject.optString("user_mobile"));
                requestDetails.setsLatitude(dataObject.optString("s_latitude"));
                requestDetails.setsLongitude(dataObject.optString("s_longitude"));
                requestDetails.setdLatitude(dataObject.optString("d_latitude"));
                requestDetails.setdLongitude(dataObject.optString("d_longitude"));
                requestDetails.setSourceAddress(dataObject.optString("s_address"));
                requestDetails.setDestinationAddress(dataObject.optString("d_address"));
                requestDetails.setServiceType(dataObject.optString("service_type_name"));
                requestDetails.setUserRating(String.valueOf(dataObject.optString("user_rating").charAt(0)));
                requestDetails.setRequestId(Integer.parseInt(dataObject.optString("request_id")));
                requestDetails.setStatus(dataObject.optString("status"));
                requestDetails.setProviderStatus(dataObject.optString("provider_status"));
                requestDetails.setUser_price(dataObject.optString("user_price"));
                requestDetails.setSub_category_name(dataObject.optString("sub_category_name"));
                requestDetails.setCurrency(dataObject.optString("currency"));
                requestDetails.setBefore_image(dataObject.optString("before_image"));
                requestDetails.setAfter_image(dataObject.optString("after_image"));
                requestDetails.setJob_type(dataObject.optString("job_type"));
                requestDetails.setPrice_per_hour(dataObject.optString("price_per_hour"));
                return requestDetails;
            }

        } catch (JSONException e) {
            e.printStackTrace();
        }

        return requestDetails;
    }
}
