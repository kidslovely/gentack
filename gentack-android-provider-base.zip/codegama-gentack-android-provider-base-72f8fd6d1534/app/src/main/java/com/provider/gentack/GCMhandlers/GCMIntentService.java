package com.provider.gentack.GCMhandlers;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.provider.Settings;
import android.support.v4.app.NotificationCompat;
import android.support.v4.content.LocalBroadcastManager;
import android.util.Log;

import com.provider.gentack.activity.ChatActivity;
import com.provider.gentack.activity.ListJobsActivity;
import com.provider.gentack.utils.Const;
import com.google.android.gms.gcm.GcmListenerService;
import com.google.android.gms.gcm.GoogleCloudMessaging;
import com.provider.gentack.R;
import com.provider.gentack.activity.MainActivity;
import com.provider.gentack.utils.PreferenceHelper;

import org.json.JSONException;
import org.json.JSONObject;


/**
 * Created by user on 6/29/2015.
 */
public class GCMIntentService extends GcmListenerService {

    public static final int NOTIFICATION_ID = 2;
    private NotificationManager mNotificationManager;
    NotificationCompat.Builder builder;
    private PreferenceHelper preferenceHelper;
    private String date = "";

    private static final String PUSH_PROVIDER_HOME = "6";
    private static final String PUSH_PROVIDER_ONGOING = "7";
    private static final String PUSH_PROVIDER_SINGLE = "8";
    private static final String PUSH_PROVIDER_JOB_DASHBOARD = "9";
    private static final String PUSH_PROVIDER_CHAT = "10";

    @Override
    public void onMessageReceived(final String from, final Bundle bundle) {

        Bundle extras = bundle;
        GoogleCloudMessaging gcm = GoogleCloudMessaging.getInstance(this);
        preferenceHelper = new PreferenceHelper(this);

        // The getMessageType() intent parameter must be the intent you received
        // in your BroadcastReceiver.
        // String messageType = gcm.getMessageType(intent);


        if (!extras.isEmpty()) {  // has effect of unparcelling Bundle
            /*
             * Filter messages based on message type. Since it is likely that GCM
             * will be extended in the future with new message types, just ignore
             * any message types you're not interested in, or that you don't
             * recognize.
             */


            String recieved_message = extras.getString("message");
            Log.e("mahi", "rec push" + recieved_message);
            try {
                JSONObject responsobj = new JSONObject(recieved_message);
                /*JSONObject dataobj =responsobj.getJSONObject(recieved_message);
                JSONObject msgObj = dataobj.getJSONObject("message");*/
                String success = responsobj.getString("success");
                String title = responsobj.getString("title");
                String type = responsobj.getString("type");
                JSONObject data = responsobj.getJSONObject("data");

                Intent pushIntent = new Intent("New Bid");
                pushIntent.putExtra("New Bid", recieved_message);

                if (preferenceHelper.getUserId() != null) {
                    sendNotification(success, title ,type, data);
                    LocalBroadcastManager.getInstance(this).sendBroadcast(pushIntent);
                }



            } catch (JSONException e) {
                e.printStackTrace();
            }




        }
    }

    private void sendNotification(String success, String message, String type, JSONObject data) {
        Log.e("GCM", success + message + type + data.toString());
        Intent intent;
        if(success.equalsIgnoreCase("true")){
            switch (type){
                case PUSH_PROVIDER_HOME:
                    intent = new Intent(this, MainActivity.class);
                    break;
                case PUSH_PROVIDER_JOB_DASHBOARD:
                    intent = new Intent(this, ListJobsActivity.class);
                    break;
                case PUSH_PROVIDER_ONGOING:
                    intent = new Intent(this, MainActivity.class);
                    break;
                case PUSH_PROVIDER_SINGLE:
                    intent = new Intent(this, ListJobsActivity.class);
                    intent.putExtra(Const.Params.REQUEST_ID, data.optString(Const.Params.REQUEST_ID));
                    intent.putExtra(Const.Params.FRAGMENT_TYPE, data.optString("page_type"));
                    intent.putExtra("fromPush", true);
                    break;
                case PUSH_PROVIDER_CHAT:
                    intent = new Intent(this, ChatActivity.class);
                    Bundle mbundle = new Bundle();
                    mbundle.putString("request_id", data.optString(Const.Params.REQUEST_ID));
                    mbundle.putString("reciver_id", Const.Params.USER_ID);
                    intent.putExtras(mbundle);
                    break;
                default:
                    intent = new Intent(this, MainActivity.class);
                    break;
            }
            int icon = R.mipmap.ic_launcher;
            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
            PendingIntent contentIntent = PendingIntent.getActivity(this, (int) System.currentTimeMillis(), intent, PendingIntent.FLAG_CANCEL_CURRENT);
            builder = new NotificationCompat.Builder(this);
            showNotification(builder, icon, getResources().getString(R.string.app_name), message,contentIntent);
        }
    }


    private void showNotification(NotificationCompat.Builder builder, int icon, String title,
                                  String message, PendingIntent intent){
        NotificationCompat.InboxStyle inboxStyle = new NotificationCompat.InboxStyle();

        inboxStyle.addLine(message);

        Notification notification = builder.setSmallIcon(icon).setTicker(title).setWhen(0)
                .setAutoCancel(true)
                .setContentTitle(title)
                .setContentIntent(intent)
                .setStyle(inboxStyle)
                .setSmallIcon(icon)
                .setLargeIcon(BitmapFactory.decodeResource(getResources(), icon))
                .setContentText(message)
                .setSound(Settings.System.DEFAULT_NOTIFICATION_URI)
                .build();
        mNotificationManager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        mNotificationManager.notify(NOTIFICATION_ID, notification);

    }

    private void sendNotification(String msg,String type) {
        mNotificationManager = (NotificationManager)
                this.getSystemService(Context.NOTIFICATION_SERVICE);
        Intent chat_intent = null;
        if(type.equals("2")){
            chat_intent = new Intent(this, MainActivity.class);
            chat_intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
            chat_intent.putExtra("newques", "new_quest");
        } else {
            chat_intent = new Intent(this, MainActivity.class);
            chat_intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
            chat_intent.putExtra("newques", "new_quest");
        }

        PendingIntent contentIntent = PendingIntent.getActivity(this, (int) System.currentTimeMillis(),
                chat_intent, 0);

        Notification.Builder mBuilder =
                new Notification.Builder(this)
                        .setSmallIcon(R.mipmap.ic_launcher)
                        .setContentTitle(getResources().getString(R.string.app_name))
                        .setStyle(new Notification.BigTextStyle()
                                .bigText(msg))
                        .setVibrate(new long[]{100, 500})
                        .setSound(Settings.System.DEFAULT_NOTIFICATION_URI)
                        .setAutoCancel(true)
                        .setContentText(msg);

        mBuilder.setContentIntent(contentIntent);
        mNotificationManager.notify(NOTIFICATION_ID, mBuilder.build());


    }


}
