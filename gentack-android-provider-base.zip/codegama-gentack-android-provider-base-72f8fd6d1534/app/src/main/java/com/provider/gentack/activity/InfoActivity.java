package com.provider.gentack.activity;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.provider.gentack.R;
import com.provider.gentack.custom_interface.AsyncTaskCompleteListener;
import com.provider.gentack.networking.HttpRequester;
import com.provider.gentack.utils.AndyUtils;
import com.provider.gentack.utils.Const;
import com.provider.gentack.utils.PreferenceHelper;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;

public class InfoActivity extends AppCompatActivity implements AsyncTaskCompleteListener{
    private Toolbar chatToolbar;
    private ImageView chat_back, jobMapView;
    private String request_id;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
        setContentView(R.layout.activity_info);
        chatToolbar = (Toolbar) findViewById(R.id.toolbar_chat);
        chat_back = (ImageView) findViewById(R.id.btn_back_chat);
        jobMapView = (ImageView) findViewById(R.id.jobdetailedMapView);
        setSupportActionBar(chatToolbar);
        getSupportActionBar().setTitle(null);
        request_id = getIntent().getStringExtra(Const.Params.REQUEST_ID);
        getInfo();
        chat_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });
    }

    private void getInfo(){
        AndyUtils.showSimpleProgressDialog(this, "Loading...", true);
        HashMap<String, String> map = new HashMap<>();
        map.put(Const.Params.URL, Const.ServiceType.SINGLE_REQUEST);
        map.put(Const.Params.ID, PreferenceHelper.getInstance().getUserId());
        map.put(Const.Params.TOKEN, PreferenceHelper.getInstance().getSessionToken());
        map.put(Const.Params.REQUEST_ID, request_id);
        AndyUtils.appLog("Ashutosh", "GetInfo" + map);
        new HttpRequester(this, Const.POST, map, Const.ServiceCode.SINGLE_REQUEST, this);
    }

    @Override
    public void onTaskCompleted(String response, int serviceCode) {
        switch (serviceCode){
            case Const.ServiceCode.SINGLE_REQUEST:
                AndyUtils.appLog("Info", response);
                try {
                    JSONObject res = new JSONObject(response);
                    if (res.optString("success").equalsIgnoreCase("true")){
                        JSONObject data = res.getJSONObject("data");
                        ((TextView)findViewById(R.id.tv_job_title)).setText(data.optString("name").toUpperCase());
                        ((TextView)findViewById(R.id.tv_category_type)).setText(data.optString("category_name"));
                        ((TextView)findViewById(R.id.tv_sub_category)).setText(data.optString("sub_category_name"));
                        ((TextView)findViewById(R.id.tv_req_date)).setText(data.optString("request_date"));
                        ((TextView)findViewById(R.id.tv_req_date)).setText(data.optString("request_date"));
                        ((TextView)findViewById(R.id.tv_job_desc)).setText(data.optString("description"));
                        ((TextView)findViewById(R.id.tv_job_note)).setText(data.optString("note"));
                        ((TextView)findViewById(R.id.tv_user_name)).setText(data.optString("user_name"));
                        ((TextView)findViewById(R.id.tv_base_price)).setText(data.optString("currency") + "" +data.optString("price_per_hour"));
                        ((TextView)findViewById(R.id.tv_base_price)).setText(data.optString("currency") + "" +data.optString("price_per_hour"));
                        ((TextView)findViewById(R.id.tv_payment_mode)).setText(data.optString("payment_mode"));
                        String map = HistoryActivity.getGoogleMapThumbnail(Double.valueOf(data.optString("s_latitude")),
                                Double.valueOf(data.optString("s_longitude")));
                        Glide.with(this).load(map).into(jobMapView);
                    }
                    AndyUtils.removeProgressDialog();
                }
                catch (JSONException e){
                    e.printStackTrace();
                }
        }
    }
}
