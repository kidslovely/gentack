package com.provider.gentack.activity;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;

import com.provider.gentack.R;
import com.provider.gentack.adapter.ChatAdapter;
import com.provider.gentack.custom_interface.AsyncTaskCompleteListener;
import com.provider.gentack.model.ChatObject;
import com.provider.gentack.networking.HttpRequester;
import com.provider.gentack.utils.AndyUtils;
import com.provider.gentack.utils.Const;
import com.provider.gentack.utils.PreferenceHelper;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import io.socket.client.IO;
import io.socket.client.Socket;
import io.socket.emitter.Emitter;

/**
 * Created by user on 2/18/2017.
 */

public class ChatActivity extends AppCompatActivity implements AsyncTaskCompleteListener {
    private Toolbar chatToolbar;
    private ListView chat_lv;
    private ImageView btn_send, chat_back;
    ChatAdapter messageAdapter;
//    DatabaseHandler db;
    private List<ChatObject> messages;
    private Socket mSocket;
    private Boolean isConnected = true;
    private EditText et_message;
    private String reciver_id = "";
    private String request_id = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
        setContentView(R.layout.chat_layout);

//        db = new DatabaseHandler(this);
        chatToolbar = (Toolbar) findViewById(R.id.toolbar_chat);

        setSupportActionBar(chatToolbar);
        getSupportActionBar().setTitle(null);

        chat_back = (ImageView) findViewById(R.id.btn_back_chat);
        chat_lv = (ListView) findViewById(R.id.chat_lv);
        et_message = (EditText) findViewById(R.id.et_message);
        btn_send = (ImageView) findViewById(R.id.btn_send);

        btn_send.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (et_message.getText().toString().length() == 0) {
                    AndyUtils.showShortToast("Please Enter Message before send", getApplicationContext());
                    et_message.requestFocus();
                } else {
                    if (mSocket.connected()) {
                        attemptSend(et_message.getText().toString());
                        // AndyUtils.hideKeyBoard(getApplicationContext());
                        et_message.setText("");

                    }
                }

            }
        });
        chat_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });

        Bundle bundle = getIntent().getExtras();
        if(bundle!=null){
            reciver_id = bundle.getString("reciver_id");
            request_id = bundle.getString("request_id");
            Log.d("mahi", "re_id" + request_id);
            initiateSokect();
        }
        loadMessages();
        messages = new ArrayList<>();
        messageAdapter = new ChatAdapter(this, R.layout.list_item_chat_message, messages);
        chat_lv.setAdapter(messageAdapter);
    }

    private void loadMessages(){
        HashMap<String, String> map = new HashMap<>();
        map.put(Const.Params.URL, Const.ServiceType.GET_MESSAGES + "id=" + PreferenceHelper.getInstance().getUserId() + "&" +
                                        "token=" + PreferenceHelper.getInstance().getSessionToken() + "&" +
                                        "request_id=" + request_id);
//        map.put(Const.Params.ID, PreferenceHelper.getInstance().getUserId());
//        map.put(Const.Params.TOKEN, PreferenceHelper.getInstance().getSessionToken());
//        map.put(Const.Params.REQUEST_ID, request_id);
//        map.put(Const.Params.USER_ID, reciver_id);
        AndyUtils.showSimpleProgressDialog(this, "Loading", true);
        new HttpRequester(this, Const.GET, map, Const.ServiceCode.GET_MESSAGES_CODE, this);
    }

    private void attemptSend(String message) {
        if (!mSocket.connected()) return;

        JSONObject messageObj = new JSONObject();
        try {
            messageObj.put("message", message);
            messageObj.put("provider_id", new PreferenceHelper(this).getUserId());

            messageObj.put("user_id", reciver_id);
            messageObj.put("type", "pu");
            messageObj.put("data_type", "TEXT");
            messageObj.put("status", "sent");
            messageObj.put("reqid", request_id);

            Log.e("mahi", "message socket in chat" + messageObj.toString());
            showChat("sent", "TEXT", message);
            mSocket.emit("send message", messageObj);

        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    private void pingCall( String provider_id, String user_id, String type, String request_id){
        HashMap<String, String > map = new HashMap<String, String>();
        map.put(Const.Params.URL, Const.ServiceType.HOST_URL + "/message/update/status");
        map.put(Const.Params.USER_ID, user_id);
        map.put(Const.Params.PROVIDER_ID, provider_id);
        map.put("type", type);
        map.put(Const.Params.REQUEST_ID, request_id);
        Log.e("PING CALL", map.toString());
        new HttpRequester(ChatActivity.this, Const.POST, map, 100, this);
    }

    private void initiateSokect() {

        try {
            mSocket = IO.socket(Const.ServiceType.SOCKET_URL);
        } catch (URISyntaxException e) {
            throw new RuntimeException(e);
        }

        mSocket.on(Socket.EVENT_CONNECT, onConnect);
        mSocket.on(Socket.EVENT_DISCONNECT, onDisconnect);
        mSocket.on(Socket.EVENT_CONNECT_ERROR, onConnectError);
        mSocket.on(Socket.EVENT_CONNECT_TIMEOUT, onConnectError);
        mSocket.on("message", onNewMessage);
        mSocket.on("user joined", onUserJoined);
        mSocket.on("user left", onUserLeft);
        mSocket.on("typing", onTyping);
        mSocket.on("stop typing", onStopTyping);
        mSocket.connect();
    }

    @Override
    public void onTaskCompleted(String response, int serviceCode) {
        switch (serviceCode) {
            case Const.ServiceCode.GET_MESSAGES_CODE:
                AndyUtils.removeProgressDialog();
                AndyUtils.appLog("CHAT_MESSAGES", response);
                try {
                    JSONObject object = new JSONObject(response);
                    if (object.optString("success").equalsIgnoreCase("true")){
                        JSONArray data = object.getJSONArray("data");
                        if (data.length() > 0) {
                            for (int i = 0 ; i < data.length(); i++){
                                JSONObject chatObj = data.optJSONObject(i);
                                ChatObject chat = new ChatObject(
                                        chatObj.optString("message"),
                                        chatObj.optString("type").equals("pu") ? "sent" : "receive",
                                        "TEXT",
                                        request_id,
                                        PreferenceHelper.getInstance().getUserId(),
                                        reciver_id
                                );
                                messages.add(chat);
                            }
                            messageAdapter.notifyDataSetChanged();
                        }
                    }
                }
                catch (JSONException e){
                    e.printStackTrace();
                }
        }
    }

    private void showChat(String type, String data_type, String message) {

//        if (messages == null || messages.size() == 0) {
//
//            messages = new ArrayList<ChatObject>();
//        }

        messages.add(new ChatObject(message, type, data_type, ""
                + request_id, new PreferenceHelper(this).getUserId(), reciver_id));

        ChatAdapter chatAdabter = new ChatAdapter(ChatActivity.this, R.layout.list_item_chat_message, messages);

        chat_lv.setAdapter(chatAdabter);
        // chatAdabter.notifyDataSetChanged();
        //if (type.equals("sent")) {
//        ChatObject chat = new ChatObject(message, type, data_type, ""
//                + request_id, new PreferenceHelper(this).getUserId(), reciver_id);
//
//        db.insertChat(chat);
        // }

        // chatAdabter.notifyDataSetChanged();

    }

    private Emitter.Listener onConnect = new Emitter.Listener() {
        @Override
        public void call(Object... args) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    if (!isConnected) {

                        try {

                            JSONObject object = new JSONObject();
                            object.put("myid", "pu" + new PreferenceHelper(getApplicationContext()).getUserId());
                            object.put("reqid", request_id);
                            Log.e("update_sender", "" + object);
                            mSocket.emit("update sender", object);

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }


                        isConnected = true;
                    }
                    if (isConnected) {


                        try {

                            JSONObject object = new JSONObject();
                            object.put("myid", "pu" + new PreferenceHelper(getApplicationContext()).getUserId());
                            object.put("reqid", request_id);
                            Log.e("update_sender", "" + object);
                            mSocket.emit("update sender", object);

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }


                    }
                }
            });
        }
    };

    private Emitter.Listener onDisconnect = new Emitter.Listener() {
        @Override
        public void call(Object... args) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    isConnected = false;

                }
            });
        }
    };

    private Emitter.Listener onConnectError = new Emitter.Listener() {
        @Override
        public void call(Object... args) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {

                }
            });
        }
    };

    private Emitter.Listener onNewMessage = new Emitter.Listener() {
        @Override
        public void call(final Object... args) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    JSONObject data = (JSONObject) args[0];
                    Log.e("onNewMessage", "new message recive" + data.toString());
                    String type, stat;
                    String data_type;
                    String message;
                    try {

                        type = data.getString("status");
                        stat = data.getString("type");
                        data_type = data.getString("data_type");
                        message = data.getString("message");
                        showChat("receive", data_type, message);
                        pingCall(PreferenceHelper.getInstance().getUserId(), data.getString("user_id") , stat, request_id);

                    } catch (JSONException e) {
                        return;
                    }


                }
            });
        }
    };

    private Emitter.Listener onUserJoined = new Emitter.Listener() {
        @Override
        public void call(final Object... args) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    JSONObject data = (JSONObject) args[0];
                    String username;
                    int numUsers;
                    try {
                        username = data.getString("username");
                        numUsers = data.getInt("numUsers");
                    } catch (JSONException e) {
                        return;
                    }
/*
                    addLog(getResources().getString(R.string.message_user_joined, username));
                    addParticipantsLog(numUsers);*/
                }
            });
        }
    };

    private Emitter.Listener onUserLeft = new Emitter.Listener() {
        @Override
        public void call(final Object... args) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    JSONObject data = (JSONObject) args[0];
                    String username;
                    int numUsers;
                    try {
                        username = data.getString("username");
                        numUsers = data.getInt("numUsers");
                    } catch (JSONException e) {
                        return;
                    }

                }
            });
        }
    };

    private Emitter.Listener onTyping = new Emitter.Listener() {
        @Override
        public void call(final Object... args) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    JSONObject data = (JSONObject) args[0];
                    String username;
                    try {
                        username = data.getString("username");
                    } catch (JSONException e) {
                        return;
                    }

                }
            });
        }
    };

    private Emitter.Listener onStopTyping = new Emitter.Listener() {
        @Override
        public void call(final Object... args) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    JSONObject data = (JSONObject) args[0];
                    String username;
                    try {
                        username = data.getString("username");
                    } catch (JSONException e) {
                        return;
                    }

                }
            });
        }
    };

  /*  private Runnable onTypingTimeout = new Runnable() {
        @Override
        public void run() {
            if (!mTyping) return;

            mTyping = false;
            mSocket.emit("stop typing");
        }
    };*/

    @Override
    public void onPause() {
        super.onPause();

    }

    @Override
    public void onStop() {
        super.onStop();

    }

    @Override
    public void onDestroy() {
        super.onDestroy();

        mSocket.disconnect();

        mSocket.off(Socket.EVENT_CONNECT, onConnect);
        mSocket.off(Socket.EVENT_DISCONNECT, onDisconnect);
        mSocket.off(Socket.EVENT_CONNECT_ERROR, onConnectError);
        mSocket.off(Socket.EVENT_CONNECT_TIMEOUT, onConnectError);
        mSocket.off("message", onNewMessage);
        mSocket.off("user joined", onUserJoined);
        mSocket.off("user left", onUserLeft);
        mSocket.off("typing", onTyping);
        mSocket.off("stop typing", onStopTyping);
    }
}
