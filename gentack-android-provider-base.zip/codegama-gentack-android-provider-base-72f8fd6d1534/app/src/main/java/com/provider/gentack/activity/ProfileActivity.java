package com.provider.gentack.activity;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.androidquery.AQuery;
import com.androidquery.callback.AjaxStatus;
import com.androidquery.callback.BitmapAjaxCallback;
import com.bumptech.glide.Glide;
import com.provider.gentack.R;
import com.provider.gentack.custom_interface.AsyncTaskCompleteListener;
import com.provider.gentack.networking.HttpRequester;
import com.provider.gentack.networking.MultiPartRequester;
import com.provider.gentack.utils.AndyUtils;
import com.provider.gentack.utils.Const;
import com.provider.gentack.utils.PreferenceHelper;
import com.soundcloud.android.crop.Crop;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.util.Calendar;
import java.util.HashMap;

import de.hdodenhof.circleimageview.CircleImageView;

/**
 * Created by Mahesh on 3/12/2017.
 */

public class ProfileActivity extends Activity implements View.OnClickListener, AsyncTaskCompleteListener {

    private ImageView btn_back_profile;
    private EditText et_profile_name, et_profile_email, et_profile_phone;
    private TextView et_profile_dob;
    private Button btn_edit_profile;
    private CircleImageView iv_profile;
    private Uri uri = null;
    private String filepath = "";
    private AQuery aQuery;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
        setContentView(R.layout.myprofile);
        aQuery = new AQuery(this);
        btn_back_profile = (ImageView) findViewById(R.id.btn_back_profile);
        btn_back_profile.setOnClickListener(this);
        et_profile_name = (EditText) findViewById(R.id.et_profile_name);
        et_profile_email = (EditText) findViewById(R.id.et_profile_email);
        et_profile_phone = (EditText) findViewById(R.id.et_profile_phone);
        btn_edit_profile = (Button) findViewById(R.id.btn_edit_profile);
        et_profile_dob = (TextView) findViewById(R.id.et_profile_dob);
        iv_profile = (CircleImageView) findViewById(R.id.iv_profile);
        iv_profile.setOnClickListener(this);
        btn_edit_profile.setOnClickListener(this);

        setdisabel();

        getprofile();
    }

    private void getprofile() {
        if (!AndyUtils.isNetworkAvailable(this)) {

            return;
        }
        HashMap<String, String> map = new HashMap<String, String>();
        map.put(Const.Params.URL, Const.ServiceType.GET_PROFILE);
        map.put(Const.Params.ID, new PreferenceHelper(this).getUserId());
        map.put(Const.Params.TOKEN, new PreferenceHelper(this).getSessionToken());

        new HttpRequester(this, Const.POST, map,
                Const.ServiceCode.GET_PROFILE, this);

    }

    private void setdisabel() {
        et_profile_name.setEnabled(false);
        et_profile_email.setEnabled(false);
        et_profile_phone.setEnabled(false);
        iv_profile.setEnabled(false);
    }

    private void enableView() {
        et_profile_name.setEnabled(true);
        et_profile_email.setEnabled(true);
        et_profile_phone.setEnabled(true);
        iv_profile.setEnabled(true);
    }

    @Override
    public void onBackPressed() {
        startActivity(new Intent(this,MainActivity.class));
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.btn_back_profile:
                onBackPressed();
                break;
            case R.id.btn_edit_profile:
                if (btn_edit_profile.getText().equals(getString(R.string.edit))) {
                    btn_edit_profile.setText(getString(R.string.save));
                    enableView();
                } else {
                    setdisabel();
                    btn_edit_profile.setText(getString(R.string.edit));
                    saveprofile();
                }

                break;
            case R.id.iv_profile:
                showPictureDialog();
                break;
            default:
                break;
        }

    }

    private void saveprofile() {
        if (!AndyUtils.isNetworkAvailable(this)) {

            return;
        }
        AndyUtils.showSimpleProgressDialog(this, getString(R.string.saving), false);
        HashMap<String, String> map = new HashMap<String, String>();
        map.put(Const.Params.URL, Const.ServiceType.SAVE_PROFILE);
        map.put(Const.Params.ID, new PreferenceHelper(this).getUserId());
        map.put(Const.Params.TOKEN, new PreferenceHelper(this).getSessionToken());
        map.put(Const.Params.NAME, et_profile_name.getText().toString());
        map.put(Const.Params.MOBILE, et_profile_phone.getText().toString());
        map.put(Const.Params.EMAIL, et_profile_email.getText().toString());
        map.put(Const.Params.PICTURE, filepath);
        new MultiPartRequester(this, map,
                Const.ServiceCode.SAVE_PROFILE, this);
    }

    private void showPictureDialog() {
        AlertDialog.Builder pictureDialog = new AlertDialog.Builder(
                this);
        pictureDialog.setTitle(getResources().getString(
                R.string.txt_slct_option));
        String[] pictureDialogItems = {
                getResources().getString(R.string.txt_gellery),
                getResources().getString(R.string.txt_cameray)};

        pictureDialog.setItems(pictureDialogItems,
                new DialogInterface.OnClickListener() {

                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        switch (which) {

                            case 0:
                                choosePhotoFromGallary();
                                break;

                            case 1:
                                takePhotoFromCamera();
                                break;

                        }
                    }
                });
        pictureDialog.show();
    }

    private void choosePhotoFromGallary() {

        Intent galleryIntent = new Intent(Intent.ACTION_PICK,
                android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        startActivityForResult(galleryIntent,
                Const.CHOOSE_PHOTO);
    }

    private void takePhotoFromCamera() {
        Calendar cal = Calendar.getInstance();
        File file = new File(Environment.getExternalStorageDirectory(),
                (cal.getTimeInMillis() + ".jpg"));


        uri = Uri.fromFile(file);
        Intent cameraIntent = new Intent(
                android.provider.MediaStore.ACTION_IMAGE_CAPTURE);
        cameraIntent.putExtra(MediaStore.EXTRA_OUTPUT, uri);
        startActivityForResult(cameraIntent,
                Const.TAKE_PHOTO);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {

        switch (requestCode) {

            case Const.CHOOSE_PHOTO:
                if (data != null) {

                    uri = data.getData();
                    if (uri != null) {

                        beginCrop(uri);

                    } else {
                        Toast.makeText(this, getResources().getString(R.string.txt_img_error),
                                Toast.LENGTH_LONG).show();
                    }
                }
                break;
            case Const.TAKE_PHOTO:


                if (uri != null) {
                    beginCrop(uri);
                } else {
                    Toast.makeText(this, getResources().getString(R.string.txt_img_error),
                            Toast.LENGTH_LONG).show();
                }

                break;
            case Crop.REQUEST_CROP:


                if (data != null)
                    handleCrop(resultCode, data);

                break;
        }
    }

    private void beginCrop(Uri source) {

        Uri outputUri = Uri.fromFile(new File(Environment
                .getExternalStorageDirectory(), (Calendar.getInstance()
                .getTimeInMillis() + ".jpg")));
        Crop.of(source, outputUri).asSquare().start(this);
    }

    private void handleCrop(int resultCode, Intent result) {
        if (resultCode == RESULT_OK) {

            filepath = getRealPathFromURI(Crop.getOutput(result));

            //.setImageURI(Crop.getOutput(result));

            //Picasso.with(this).load("file:" + filePath).into(iv_register_user_icon);
            Glide.with(this)
                    .load(filepath)
                    .into(iv_profile);

        } else if (resultCode == Crop.RESULT_ERROR) {
            Toast.makeText(this, Crop.getError(result).getMessage(),
                    Toast.LENGTH_SHORT).show();
        }
    }

    private String getRealPathFromURI(Uri contentURI) {
        String result;
        Cursor cursor = getContentResolver().query(contentURI, null,
                null, null, null);

        if (cursor == null) { // Source is Dropbox or other similar local file
            // path
            result = contentURI.getPath();
        } else {
            cursor.moveToFirst();
            int idx = cursor
                    .getColumnIndex(MediaStore.Images.ImageColumns.DATA);
            result = cursor.getString(idx);
            cursor.close();
        }
        return result;
    }

    @Override
    public void onTaskCompleted(String response, int serviceCode) {
        switch (serviceCode) {
            case Const.ServiceCode.GET_PROFILE:
                Log.d("mahi", "profile response" + response);
                try {
                    JSONObject job = new JSONObject(response);
                    if (job.optString("success").equals("true")) {
                        JSONObject data = job.optJSONObject("data");
                        et_profile_email.setText(data.optString("email"));
                        et_profile_name.setText(data.optString("provider_name"));
                        et_profile_phone.setText(data.optString("mobile"));
                        et_profile_dob.setText(data.optString("DOB"));
                        new PreferenceHelper(this).putPicture(data.optString("provider_picture"));
                        new PreferenceHelper(this).putUser_name(data.optString("provider_name"));
                        Glide.with(this)
                                .load(data.optString("provider_picture"))
                                .into(iv_profile);
                        aQuery.id(R.id.iv_profile).image(data.optString("provider_picture"), true, true,
                                200, 0, new BitmapAjaxCallback() {

                                    @Override
                                    public void callback(String url, ImageView iv, Bitmap bm,
                                                         AjaxStatus status) {

                                        if (url != null && !url.equals("")) {
                                            filepath = aQuery.getCachedFile(url).getPath();

                                        }

                                    }

                                });
                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                }

                break;
            case Const.ServiceCode.SAVE_PROFILE:
                Log.d("mahi","response"+response);
                AndyUtils.removeProgressDialog();
                try {
                    JSONObject job = new JSONObject(response);
                    if (job.optString("success").equals("true")) {
                        AndyUtils.showLongToast("Profile Updated Successfully!", this);
                    } else {
                        AndyUtils.showLongToast("Failed to update!", this);
                        enableView();
                        btn_edit_profile.setText(getString(R.string.save));
                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                }
                break;
            default:
                break;

        }

    }
}
