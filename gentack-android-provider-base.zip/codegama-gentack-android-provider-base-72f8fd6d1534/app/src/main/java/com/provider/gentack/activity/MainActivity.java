package com.provider.gentack.activity;

import android.content.BroadcastReceiver;
import android.content.Intent;
import android.content.res.Configuration;
import android.location.Location;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.TextView;

import com.facebook.AccessToken;
import com.facebook.FacebookSdk;
import com.facebook.GraphRequest;
import com.facebook.GraphResponse;
import com.facebook.HttpMethod;
import com.facebook.login.LoginManager;
import com.provider.gentack.model.ResponseHandler;
import com.google.android.gms.auth.api.Auth;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.ResultCallback;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.maps.model.LatLng;
import com.provider.gentack.GCMhandlers.GCMRegisterHandler;
import com.provider.gentack.GCMhandlers.GcmBroadcastReceiver;
import com.provider.gentack.R;
import com.provider.gentack.custom_interface.AsyncTaskCompleteListener;
import com.provider.gentack.fragment.ClientRequestFragment;
import com.provider.gentack.fragment.JobMapFragment;
import com.provider.gentack.location.LocationHelper;
import com.provider.gentack.model.RequestDetails;
import com.provider.gentack.networking.HttpRequester;
import com.provider.gentack.utils.AndyUtils;
import com.provider.gentack.utils.Const;
import com.provider.gentack.utils.ParseContent;
import com.provider.gentack.utils.PreferenceHelper;

import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;

import java.util.HashMap;

public class MainActivity extends AppCompatActivity implements AsyncTaskCompleteListener,
        GoogleApiClient.OnConnectionFailedListener{


    public Toolbar mainToolbar;
    public DrawerLayout drawerLayout;
    public TextView autoCompleteTextView;
    public String currentFragment = "";
    public ActionBarDrawerToggle drawerToggle;
    public View navigationFragment;
    private Intent intent;
    private Fragment fragment;
    public TextView headerText;
    private ParseContent pContent;
    private PreferenceHelper pHelper;
    private int mFragmentId = 0;
    private String mFragmentTag = null;
    private GoogleApiClient googleApiClient;

    @Override
    protected void onStart() {
        super.onStart();
        if (!EventBus.getDefault().isRegistered(this)) {
            EventBus.getDefault().register(this);
        }
    }

    @Override
    protected void onStop() {
        super.onStop();
        EventBus.getDefault().unregister(this);
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onEvent(ResponseHandler handler) {
        if (handler.isFlag()) {
            AndyUtils.showLongToast(handler.getMessage(), this);
        }
        PreferenceHelper.getInstance().putFirstTimeLogin(false);
        logout();
        switch (PreferenceHelper.getInstance().getLoginType()) {
            case Const.GOOGLE:
                signOutGoogle();
                break;
            case Const.FACEBOOK:
                logoutfromFacebook();
                break;
        }
        PreferenceHelper.getInstance().Logout();
        if (fragment instanceof ClientRequestFragment) {
            ((ClientRequestFragment) fragment).stopCheckingUpcomingRequests();
        }
        Intent intent = new Intent(this, SplashActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
        this.finish();
    }

    private void logout(){
        HashMap<String, String> map = new HashMap<String, String>();
        map.put(Const.Params.URL, Const.ServiceType.LOGOUT);
        map.put(Const.Params.ID, PreferenceHelper.getInstance().getUserId());
        map.put(Const.Params.TOKEN, PreferenceHelper.getInstance().getSessionToken());
        new HttpRequester(this, Const.POST, map, Const.ServiceCode.LOGOUT_CODE, this);

    }

    public void signOutGoogle(){
        Auth.GoogleSignInApi.revokeAccess(googleApiClient).setResultCallback(new ResultCallback<Status>() {
            @Override
            public void onResult(@NonNull Status status) {
                Log.d("GOOGLESTATUS", status.toString());
            }
        });
    }

    public void logoutfromFacebook() {

        if (AccessToken.getCurrentAccessToken() == null) {
            return; // already logged out
        }

        new GraphRequest(AccessToken.getCurrentAccessToken(), "/me/permissions/", null, HttpMethod.DELETE, new GraphRequest
                .Callback() {
            @Override
            public void onCompleted(GraphResponse graphResponse) {

                LoginManager.getInstance().logOut();

            }
        }).executeAsync();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (TextUtils.isEmpty(new PreferenceHelper(this).getDeviceToken())) {

            registerGcmReceiver(new GcmBroadcastReceiver());

        }
        setContentView(R.layout.activity_main);
        FacebookSdk.sdkInitialize(this);
        mainToolbar = (Toolbar) findViewById(R.id.tb_main);
        setSupportActionBar(mainToolbar);
        getSupportActionBar().setTitle("");
        pContent = new ParseContent(this);
        pHelper = new PreferenceHelper(this);
        drawerLayout = (DrawerLayout) findViewById(R.id.drawer_layout);
        navigationFragment = findViewById(R.id.navigation_drawer);
        GoogleSignInOptions gso = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestEmail()
                .build();

        googleApiClient = new GoogleApiClient.Builder(this)
                .enableAutoManage(this /* FragmentActivity */, this /* OnConnectionFailedListener */)
                .addApi(Auth.GOOGLE_SIGN_IN_API, gso)
                .build();

        headerText = (TextView) findViewById(R.id.toolbar_header);
        initDrawer();
        if (AndyUtils.isNetworkAvailable(this)) {
            checkStatus();
            Log.d("Ashutosh", "onresume main activity");
        }
        //addFragment(new ClientRequestFragment(), false, "Home", Const.Params.HOMEMAP_FRAGMENT);
        Log.d("ID", PreferenceHelper.getInstance().getUserId());
        Log.d("TOKEN", PreferenceHelper.getInstance().getSessionToken());
    }

    public void registerGcmReceiver(BroadcastReceiver mHandleMessageReceiver) {
        if (mHandleMessageReceiver != null) {
            new GCMRegisterHandler(this, mHandleMessageReceiver);
        }
    }

    public void checkStatus() {
        checkRequestStatus();
    }

    public void checkRequestStatus() {
        if (!AndyUtils.isNetworkAvailable(this)) {

            return;
        }
        HashMap<String, String> map = new HashMap<String, String>();
        map.put(Const.Params.URL, Const.ServiceType.STATUS_CHECK);
        map.put(Const.Params.ID, new PreferenceHelper(this).getUserId());
        map.put(Const.Params.TOKEN, new PreferenceHelper(this).getSessionToken());
        //  map.put(Const.Params.REQUEST_ID, String.valueOf(req_id));
        Log.d("mahi", "check req status no calling" + map.toString());
        new HttpRequester(this, Const.POST, map,
                Const.ServiceCode.STATUS_CHECK, this);

    }

    private void initDrawer() {
        drawerToggle = new ActionBarDrawerToggle(this, drawerLayout,
                mainToolbar, R.string.drawer_open, R.string.drawer_close) {

            public void onDrawerClosed(View view) {
                super.onDrawerClosed(view);
                invalidateOptionsMenu();
            }

            public void onDrawerOpened(View drawerView) {
                super.onDrawerOpened(drawerView);
//                invalidateOptionsMenu();
            }
        };

        drawerLayout.addDrawerListener(drawerToggle);
        drawerLayout.post(new Runnable() {
            @Override
            public void run() {

                drawerToggle.syncState();
            }
        });


    }

    public void closeDrawer() {
        drawerLayout.closeDrawers();
    }


    @Override
    protected void onPostCreate(Bundle savedInstanceState) {
        super.onPostCreate(savedInstanceState);
        drawerToggle.syncState();
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        drawerToggle.onConfigurationChanged(newConfig);
    }


    public void addFragment(Fragment fragment, boolean addToBackStack, String fragmentTitle,
                            String tag) {
        FragmentManager manager = getSupportFragmentManager();
        FragmentTransaction ft = manager.beginTransaction();
        this.fragment = fragment;
        headerText.setText(fragmentTitle);
//        if (fragmentTitle.equals(Const.Params.SIGNIN_FRAGMENT)) {
//        } else if (fragmentTitle.equals(Const.Params.SIGNUP_FRAGMENT)) {
//        }
        if (addToBackStack) {
            ft.addToBackStack(tag);
        }
        ft.replace(R.id.container, fragment, tag);
        ft.commitAllowingStateLoss();
    }

    @Override
    public void onBackPressed() {
        if (currentFragment.equals(Const.Params.SERVICE_FRAGMENT)) {
            startActivity(new Intent(this, MainActivity.class));
        } else if (currentFragment.equals(Const.Params.JOBMAP_FRAGMENT)) {

        } else {
            this.finish();
        }
    }

    public void startActivityForResult(Intent intent, int requestCode,
                                       String fragmentTag) {

        mFragmentTag = fragmentTag;
        mFragmentId = 0;
        super.startActivityForResult(intent, requestCode);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        Log.d("Activity Res", "" + requestCode);

        Fragment fragment = null;

        if (mFragmentId > 0) {
            fragment = getSupportFragmentManager().findFragmentById(
                    mFragmentId);
        } else if (mFragmentTag != null
                && !mFragmentTag.equalsIgnoreCase("")) {
            fragment = getSupportFragmentManager().findFragmentByTag(
                    mFragmentTag);
        }
        if (fragment != null) {
            fragment.onActivityResult(requestCode, resultCode, data);
        }
    }


    @Override
    public void onTaskCompleted(String response, int serviceCode) {
        switch (serviceCode) {

            case Const.ServiceCode.STATUS_CHECK:
                AndyUtils.appLog("mahi", "CheckRequestStatusResponse :" + response);
                if (!pContent.isSuccess(response)) {
                    if (pContent.getErrorCode(response) == Const.INVALID_TOKEN) {
                        Log.e("mahi", "coming here Response ");
                        pHelper.clearRequestData();
                        new PreferenceHelper(this).Logout();
                        Intent i = new Intent(this, SplashActivity.class);
                        this.startActivity(i);
                        this.finish();
                        AndyUtils.showShortToast(getResources().getString(R.string.login_errror), this);

                    } else if (pContent.getErrorCode(response) == Const.REQUEST_ID_NOT_FOUND) {
                        pHelper.clearRequestData();
                    } else if (pContent.getErrorCode(response) == Const.INVALID_TOKEN) {

                    } else if (pContent.getErrorCode(response) == Const.INVALID_REQUEST_ID) {

                        pHelper.clearRequestData();
                        // startCheckingUpcomingRequests();

                    }

                    return;
                }


                Bundle bundle = new Bundle();
                JobMapFragment travelMapFragment = new JobMapFragment();
                RequestDetails requestDetail = null;

                requestDetail = pContent.parseRequestArrayStatus(response);
                if (requestDetail != null && null != requestDetail.getProviderStatus()) {

                    switch (Integer.parseInt(requestDetail.getProviderStatus())) {

                        case Const.NO_REQUEST:
                            pHelper.clearRequestData();

                            break;

                        case Const.IS_PROVIDER_ACCEPTED:

                            if (requestDetail != null) {
                                bundle.putSerializable(Const.REQUEST_DETAIL,
                                        requestDetail);
                                bundle.putInt(Const.PROVIDER_STATUS,
                                        Const.IS_PROVIDER_ACCEPTED);
                                travelMapFragment.setArguments(bundle);
                                addFragment(travelMapFragment, false, "HOME", Const.Params.JOBMAP_FRAGMENT
                                );
                            } else {
                                return;
                            }

                            break;
                        case Const.IS_PROVIDER_STARTED:
                            if (requestDetail != null) {
                                bundle.putSerializable(Const.REQUEST_DETAIL,
                                        requestDetail);
                                bundle.putInt(Const.PROVIDER_STATUS,
                                        Const.IS_PROVIDER_STARTED);
                                travelMapFragment.setArguments(bundle);

                                addFragment(travelMapFragment, false, "HOME", Const.Params.JOBMAP_FRAGMENT
                                );
                            } else {
                                return;
                            }
                            break;
                        case Const.IS_PROVIDER_ARRIVED:
                            if (requestDetail != null) {
                                bundle.putSerializable(Const.REQUEST_DETAIL,
                                        requestDetail);
                                bundle.putInt(Const.PROVIDER_STATUS,
                                        Const.IS_PROVIDER_ARRIVED);
                                travelMapFragment.setArguments(bundle);
                                addFragment(travelMapFragment, false, "HOME", Const.Params.JOBMAP_FRAGMENT
                                );
                            } else {
                                return;
                            }
                            break;
                        case Const.IS_PROVIDER_SERVICE_STARTED:
                            if (requestDetail != null) {
                                bundle.putSerializable(Const.REQUEST_DETAIL,
                                        requestDetail);
                                bundle.putInt(Const.PROVIDER_STATUS,
                                        Const.IS_PROVIDER_SERVICE_STARTED);
                                travelMapFragment.setArguments(bundle);
                                addFragment(travelMapFragment, false, "HOME", Const.Params.JOBMAP_FRAGMENT);
                            } else {
                                return;
                            }

                            break;
                        case Const.IS_PROVIDER_SERVICE_COMPLETED:
                            if (requestDetail != null) {
                                bundle.putSerializable(Const.REQUEST_DETAIL,
                                        requestDetail);
                                bundle.putInt(Const.PROVIDER_STATUS,
                                        Const.IS_PROVIDER_SERVICE_COMPLETED);

                                travelMapFragment.setArguments(bundle);
                                addFragment(travelMapFragment, false, "HOME", Const.Params.JOBMAP_FRAGMENT
                                );
                            } else {
                                return;
                            }
                            break;

                        case Const.IS_USER_RATED:

                            break;
                        default:
                            break;
                    }
                } else {

                    addFragment(new ClientRequestFragment(), false, "HOME", Const.Params.HOMEMAP_FRAGMENT);
                }
                break;

            default:
                break;
        }
    }

    @Override
    public void onConnectionFailed(@NonNull ConnectionResult connectionResult) {

    }
}

