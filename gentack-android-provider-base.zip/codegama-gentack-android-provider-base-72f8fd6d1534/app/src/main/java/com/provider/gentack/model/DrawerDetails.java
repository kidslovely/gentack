package com.provider.gentack.model;

/**
 * Created by user on 2/9/2017.
 */

public class DrawerDetails
{

    private String title;

    public DrawerDetails(String title) {

        this.title = title;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }
}
