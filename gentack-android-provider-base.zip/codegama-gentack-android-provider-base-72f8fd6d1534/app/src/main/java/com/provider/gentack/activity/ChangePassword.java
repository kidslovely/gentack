package com.provider.gentack.activity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;

import com.provider.gentack.R;
import com.provider.gentack.custom_interface.AsyncTaskCompleteListener;
import com.provider.gentack.networking.HttpRequester;
import com.provider.gentack.utils.AndyUtils;
import com.provider.gentack.utils.Const;
import com.provider.gentack.utils.PreferenceHelper;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;

/**
 * Created by Mahesh on 3/13/2017.
 */

public class ChangePassword extends Activity implements View.OnClickListener, AsyncTaskCompleteListener {
    private ImageView btn_back_password;
    private EditText et_old_pass,et_new_pass,et_confirm_pass;
    private Button btn_change_pass;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
        setContentView(R.layout.change_password);
        et_old_pass= (EditText) findViewById(R.id.et_old_pass);
        et_new_pass= (EditText) findViewById(R.id.et_new_pass);
        et_confirm_pass= (EditText) findViewById(R.id.et_confirm_pass);
        btn_back_password = (ImageView) findViewById(R.id.btn_back_password);
        btn_change_pass = (Button) findViewById(R.id.btn_change_pass);
        btn_back_password.setOnClickListener(this);
        btn_change_pass.setOnClickListener(this);
    }

    @Override
    public void onBackPressed() {
        startActivity(new Intent(this,MainActivity.class));
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.btn_back_password:
                onBackPressed();
                break;
            case R.id.btn_change_pass:
                if(et_old_pass.getText().toString().length()==0){
                    AndyUtils.showShortToast("Please enter Old Password!",this);
                    et_old_pass.requestFocus();
                } else if(et_new_pass.getText().toString().length()==0){
                    AndyUtils.showShortToast("Please enter new Password!",this);
                    et_new_pass.requestFocus();
                } else if(et_new_pass.getText().toString().length()< 6) {
                    AndyUtils.showShortToast("New Password must contain 6 characters", this);
                    et_new_pass.requestFocus();
                } else if(et_confirm_pass.getText().toString().length()==0){
                    AndyUtils.showShortToast("Please Confirm Password!",this);
                    et_confirm_pass.requestFocus();
                } else if(et_confirm_pass.getText().toString().length()< 6) {
                    AndyUtils.showShortToast("Confirm Password must contain 6 characters", this);
                    et_confirm_pass.requestFocus();
                } else if(!et_new_pass.getText().toString().equals(et_confirm_pass.getText().toString())){
                    AndyUtils.showShortToast("Confirm password not matching!",this);
                } else {
                    changePassword();
                }
                break;
            default:
                break;
        }

    }

    private void changePassword() {
        if (!AndyUtils.isNetworkAvailable(this)) {

            return;
        }
        AndyUtils.showSimpleProgressDialog(this,"changing password....",false);
        HashMap<String, String> map = new HashMap<String, String>();
        map.put(Const.Params.URL, Const.ServiceType.CHANGE_PASSWORD);
        map.put(Const.Params.ID, new PreferenceHelper(this).getUserId());
        map.put(Const.Params.TOKEN, new PreferenceHelper(this).getSessionToken());
        map.put("old_password", et_old_pass.getText().toString());
        map.put("password", et_new_pass.getText().toString());
        map.put("password_confirmation", et_confirm_pass.getText().toString());

        new HttpRequester(this, Const.POST, map,
                Const.ServiceCode.CHANGE_PASSWORD, this);

    }


    @Override
    public void onTaskCompleted(String response, int serviceCode) {
        switch (serviceCode){
            case Const.ServiceCode.CHANGE_PASSWORD:
                AndyUtils.removeProgressDialog();
                try {
                    JSONObject job = new JSONObject(response);
                    if(job.getString("success").equals("true")){
                        AndyUtils.showShortToast("Password changed successfully!",this);
                        PreferenceHelper.getInstance().putFirstTimeLogin(false);
                        new PreferenceHelper(this).Logout();
                        Intent intent = new Intent(this, SplashActivity.class);
                        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                        startActivity(intent);
                        finish();
                    } else {
                        AndyUtils.showShortToast("Failed to change password!",this);
                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                }
                break;
        }

    }
}
